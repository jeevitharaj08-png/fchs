# Complaint Handling System (CHS) POC in C
### Production-Grade Linux Multithreaded Complaint Handling Engine

[![Standard: C11](https://img.shields.io/badge/standard-C11-blue.svg)](https://en.wikipedia.org/wiki/C11_(C_standard_revision))
[![Tests: 76 Passed](https://img.shields.io/badge/tests-76%20passed-brightgreen.svg)](tests/)
[![Coverage: 88.2%](https://img.shields.io/badge/coverage-88.2%25-green.svg)](docs/TESTING_AND_COVERAGE.md)
[![Static Analysis: Cppcheck Clean](https://img.shields.io/badge/cppcheck-clean-success.svg)](docs/MISRA_COMPLIANCE.md)

---

## 1. Project Overview

The **Complaint Handling System (CHS)** is a complete, modular, console-based POC developed in ANSI C (C11) for Linux environments. It demonstrates:
- **Modular C architecture** with clean separation of concerns across 15 production files.
- **Role-based portals** for Customers, Agents, and Managers with secure salted credential hashing.
- **Deterministic auto-assignment** of incoming complaints to active agents using a least-workload algorithm ($O(A)$ complexity) with lowest-agent-ID tie-breaking.
- **Strict state machine** validating all complaint transitions (`OPEN`, `ASSIGNED`, `IN_PROGRESS`, `ESCALATED`, `RESOLVED`, `CLOSED`).
- **Comprehensive timestamp management**: Tracks 11 mandatory lifecycle timestamps, wall-clock UTC representations, ISO 8601 formatting, monotonic waits, and an injectable clock abstraction.
- **Automated background escalation thread**: Monitored via POSIX pthreads for CRITICAL complaints and complaints remaining unresolved for $\ge 24$ hours ($86,400$ seconds).
- **Dedicated Manager Escalation Hub**: Prominent visibility for pending and acknowledged escalations with management audit logging.
- **Persistent text-file storage**: Atomic writes ensuring data preservation across restarts without databases.
- **Google Test C++ test harness**: 76 executed and passed test cases covering normal, boundary, concurrency, and timestamp scenarios.
- **Static analysis & MISRA compliance**: Zero Cppcheck errors and documented MISRA deviations.

---

## 2. Directory Structure

```text
final_chs/
├── Makefile                 # Linux-native Makefile with 15 targets
├── README.md                # Comprehensive documentation & quickstart
├── .gitignore               # Ignored build objects, coverage, and test dumps
├── include/                 # Modular API headers
│   ├── chs_common.h         # Core domain structures, enums, constants
│   ├── chs_time.h           # Timestamp management & injectable mock clock
│   ├── chs_security.h       # PBKDF2-HMAC-SHA256, unique salts, input validation
│   ├── chs_auth.h           # Login & customer registration
│   ├── chs_customer.h       # Customer portal queries & data isolation
│   ├── chs_agent.h          # 10 initial agents, workloads, notes, resolutions
│   ├── chs_manager.h        # Agent provisioning, reassignment, closures
│   ├── chs_complaint.h      # Complaint registration & state transitions
│   ├── chs_assignment.h     # Lowest-workload auto-assignment algorithm
│   ├── chs_escalation.h     # Background pthread monitor & 24h rule
│   ├── chs_history.h        # Append-only persistent history & audit trail
│   ├── chs_storage.h        # Text-file atomic save & restart reload
│   ├── chs_search.h         # In-memory multi-attribute search indexing
│   ├── chs_reports.h        # 6 dynamic business intelligence reports
│   └── chs.h                # Unified master header
├── src/                     # Modular C implementations
│   ├── main.c               # Interactive console portals orchestrator
│   ├── utils.c              # String conversions, transition validation, cleanup
│   ├── time.c               # Real-time clock, ISO8601 formatting, difference checks
│   ├── security.c           # SHA-256, HMAC, PBKDF2, constant-time compare
│   ├── storage.c            # Text-file persistence engine (data/*.txt)
│   ├── auth.c               # Credential verification & RBAC
│   ├── customer.c           # Customer operations & isolation guards
│   ├── agent.c              # Agent operations, workload recalculation, resolution
│   ├── manager.c            # Management controls & escalation acknowledgment
│   ├── complaint.c          # Lifecycle state machine & registration
│   ├── assignment.c         # Deterministic auto-assignment
│   ├── escalation.c         # Background monitoring thread & timed wait
│   ├── history.c            # Chronological audit event logger
│   ├── search.c             # Multi-filter search engine
│   └── reports.c            # Summary, Priority, Workload, Escalation reports
├── tests/                   # Google Test automated test harness (<gtest/gtest.h>)
│   ├── test_main.cpp        # Test suite entry point
│   ├── test_timestamps.cpp  # 25 mandatory timestamp verification tests
│   ├── test_auth.cpp        # 18 authentication & security tests
│   ├── test_complaint.cpp   # 10 complaint lifecycle & transition tests
│   ├── test_assignment.cpp  # 8 workload balancing & tie-breaking tests
│   └── test_reports_search.cpp # 15 reports, search, & concurrency tests
├── data/                    # Persistent storage text files
└── docs/                    # Detailed technical documentation
    ├── ARCHITECTURE.md
    ├── SECURITY.md
    ├── TIMESTAMP_DESIGN.md
    ├── TESTING_AND_COVERAGE.md
    ├── MISRA_COMPLIANCE.md
    ├── THREAD_SYNCHRONIZATION.md
    └── LINUX_SETUP.md
```

---

## 3. Quickstart: Build & Run

### Build Application & Test Suite
```bash
make all
```

### Launch Interactive Console Application
```bash
make run
```

### Execute Google Test Harness (76 Tests)
```bash
make test
```

### Run gcov Code Coverage Analysis
```bash
make coverage
```

### Run Cppcheck Static Analysis
```bash
make cppcheck
```

---

## 4. Default Demo Accounts

- **Manager**: Username `manager` | Password `ManagerPass123!`
- **Agents 1 to 10**: Username `agent1` to `agent10` | Password `AgentPass123!`
- **Customers**: Self-register directly via Option 1 in the Main Menu.

---

## 5. Verification Summary

- **Production Functions**: 28 core functions across 14 modules.
- **Executed Unit & Integration Tests**: 76 tests (100% pass rate).
- **Mandatory Timestamp Tests**: 25 tests covering all 25 specific criteria from Section 16.
- **gcov Code Coverage**: 88.20% line coverage across the production codebase.
- **Static Analysis**: 0 errors, 0 warnings, 0 memory leaks reported by Cppcheck.
