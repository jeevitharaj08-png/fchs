# Timestamp Architecture & Design Guide

## 1. Overview & Importance

Timestamp management is one of the most critical architectural requirements of the Complaint Handling System. Event timestamps govern SLA enforcement, customer transparency, agent accountability, and manager oversight.

---

## 2. Mandatory Tracked Timestamps

The application tracks discrete timestamps across the entire domain model:
1. `Customer.created_at`: Account registration time.
2. `Agent.created_at`: Agent provisioning time.
3. `Agent.deactivated_at`: Time when an agent account was suspended.
4. `Complaint.created_at`: **Immutable** complaint registration time. Never reset or modified across updates, notes, or reassignments.
5. `Complaint.updated_at`: Last modification time.
6. `Complaint.assigned_at`: Initial or latest agent assignment time.
7. `Complaint.escalated_at`: Exact moment when escalation conditions were triggered.
8. `Complaint.acknowledged_at`: Timestamp when the manager reviewed and logged notes on an escalation.
9. `Complaint.resolved_at`: Timestamp when the handling agent successfully marked the issue resolved.
10. `Complaint.closed_at`: Timestamp when management formally verified resolution details and archived the ticket.
11. `HistoryEvent.timestamp`: Append-only chronological sequence timestamp for every state change.

---

## 3. Representation & Time APIs

- **Storage Representation**: Persistent wall-clock time is stored as standard 64-bit UTC epoch seconds (`time_t`).
- **Real-Time Sampling**: Retrieved via `clock_gettime(CLOCK_REALTIME, &ts)` or `time(NULL)`.
- **Elapsed-Time Calculations**: Evaluated using `difftime(end, start)`.
- **Thread-Safe Conversions**: Rendered into human-readable ISO 8601 UTC strings (`YYYY-MM-DDTHH:MM:SSZ`) using POSIX `gmtime_r()`.
- **Monotonic Waiting**: Thread sleeping utilizes `clock_gettime(CLOCK_REALTIME, &ts)` with `pthread_cond_timedwait()` to prevent timer drift.

---

## 4. Accurate 24-Hour SLA Escalation Threshold

The threshold for age-based escalation is exactly:
$$86,400\text{ seconds } (24\text{ hours})$$

### Boundary Rules:
- If $(\text{now} - \text{created\_at}) < 86,400\text{ seconds}$ (e.g. 86,399s): Ticket remains normal.
- If $(\text{now} - \text{created\_at}) \ge 86,400\text{ seconds}$: Ticket is automatically transitioned to `STATUS_ESCALATED`.
- **Exclusion**: Resolved (`STATUS_RESOLVED`) and closed (`STATUS_CLOSED`) complaints are strictly excluded from age-based escalation regardless of age.
- **Timer Invariance**: Reassigning a complaint, updating its description, or adding notes **never** resets `created_at`.

---

## 5. Injectable Mock Clock for Automated Testing

To test 24-hour SLA conditions without waiting in real time, CHS provides an injectable clock abstraction:
```c
time_t chs_get_time(AppState *state) {
    if (state && state->get_time_fn) {
        return state->get_time_fn();
    }
    if (g_use_mock_time) {
        return g_mock_time;
    }
    struct timespec ts;
    if (clock_gettime(CLOCK_REALTIME, &ts) == 0) {
        return ts.tv_sec;
    }
    return time(NULL);
}
```
Test cases call `chs_set_mock_time(t)` and `chs_advance_mock_time(seconds)` to test boundaries (86,399s vs 86,400s vs 86,401s) deterministically.
