# Architecture Documentation: Complaint Handling System (CHS)

## 1. System Overview

The **Complaint Handling System (CHS)** is a high-performance, modular, console-based Linux POC application written in ANSI C (C11) with POSIX multithreading, text-file persistence, and a C++ Google Test automated verification harness.

The system manages the full complaint lifecycle across three primary stakeholder portals:
1. **Customer Portal**: Account registration, complaint filing, tracking, personal history, and resolution reviews.
2. **Agent Portal**: Workload tracking, ticket triage, note logging, priority modification, and complaint resolution.
3. **Manager Portal**: Enterprise oversight, agent roster management, workload balancing, complaint reassignment, ticket closure, dedicated escalation management hub, and dynamic audit reports.

---

## 2. Component Architecture

```
+-------------------------------------------------------------------------------+
|                             Complaint Handling System                         |
+-------------------------------------------------------------------------------+
|   Customer Portal      |      Agent Portal       |       Manager Portal       |
+------------------------+-------------------------+----------------------------+
| - Register Account     | - Assigned Complaints   | - System-wide Complaints   |
| - File Complaint       | - Progress Notes        | - Agent Roster & Status    |
| - View Own Complaints  | - Priority Elevation    | - Ticket Reassignment      |
| - Review Resolutions   | - Resolution Records    | - Escalation Mgmt Hub      |
+-------------------------------------------------------------------------------+
                                        |
+-------------------------------------------------------------------------------+
|                            Core Engine & Modules                              |
+-------------------------------------------------------------------------------+
|  chs_auth.c       : Multi-role authentication & credential verification       |
|  chs_complaint.c  : Lifecycle state machine & transition validator            |
|  chs_assignment.c : Deterministic lowest-workload auto-assignment (O(A))      |
|  chs_escalation.c : POSIX pthread background monitor & SLA trigger           |
|  chs_history.c    : Append-only persistent event history & audit trail        |
|  chs_storage.c    : Atomic file persistence & restart deserializer            |
|  chs_search.c     : In-memory dynamic multi-attribute search indexing        |
|  chs_reports.c    : Real-time dynamic business intelligence reports           |
|  chs_security.c   : Salt generation, PBKDF2-SHA256, constant-time compare     |
|  chs_time.c       : Wall-clock UTC time, ISO 8601, and mock clock provider   |
+-------------------------------------------------------------------------------+
                                        |
+-------------------------------------------------------------------------------+
|                           Data Structures & Storage                           |
+-------------------------------------------------------------------------------+
| In-Memory Linked Lists : Customers, Agents, Complaints, HistoryEvents         |
| Synchronization        : pthread_mutex_t (State Lock), pthread_cond_t (Signal)|
| Persistent Store       : data/{customers,agents,complaints,history,manager}.txt|
+-------------------------------------------------------------------------------+
```

---

## 3. Data Structures

The system employs singly-linked lists with controlled pointer ownership and explicit cleanup:
- `Customer`: Contains ID, username, salted password hash, salt, name, email, phone, and registration timestamp.
- `Agent`: Contains ID (1..10 initial), username, salted password hash, salt, name, active flag, creation timestamp, and deactivation timestamp.
- `Complaint`: Contains ID, customer ID, category, description, priority, status, assigned agent ID, and 7 discrete lifecycle timestamps (`created_at`, `updated_at`, `assigned_at`, `escalated_at`, `acknowledged_at`, `resolved_at`, `closed_at`).
- `HistoryEvent`: Append-only audit record containing sequence number, complaint ID, timestamp, event type, previous value, new value, acting user, and notes.

---

## 4. Automatic Agent Assignment Algorithm

### Algorithm Description:
When a customer registers a complaint:
1. The system locks `state->lock`.
2. It iterates through the roster of active agents (`agent->is_active == true`).
3. For each active agent, it computes their current workload $W$:
   $$W = \sum [(\text{assigned\_agent\_id} == A) \land (\text{status} \neq \text{RESOLVED}) \land (\text{status} \neq \text{CLOSED})]$$
4. It selects the active agent with minimum $W$.
5. **Deterministic Tie-Breaker**: If multiple agents have the same minimum workload, the agent with the lowest integer `agent->id` is chosen.
6. If no active agents are available, the complaint remains in `OPEN` status with `assigned_agent_id = 0`.
7. The complaint status is updated to `ASSIGNED`, `assigned_at` is stamped, and an append-only history event is recorded.

### Time & Space Complexity:
- **Time Complexity**: $O(A \times C)$ worst-case unindexed, or $O(A)$ when evaluating active agent rosters. With $A=10$ initial agents, this operates in effectively constant time $O(1)$ without latency.
- **Space Complexity**: $O(1)$ auxiliary memory.

---

## 5. Complaint State Machine

```
              +--------------------------+
              |           OPEN           |
              +--------------------------+
                           | Auto-Assign
                           v
              +--------------------------+
              |         ASSIGNED         |
              +--------------------------+
                /          |           \
               /           |            \
       Priority / 24h      | Triage      \ Direct Fix
             v             v              v
     +------------+  +-------------+  +------------+
     | ESCALATED  |  | IN_PROGRESS |  |  RESOLVED  |
     +------------+  +-------------+  +------------+
           \               |                 |
            \ Manager Ack  | Resolve         | Close (Requires details)
             v             v                 v
          +-------------------+       +------------+
          |     RESOLVED      | ----> |   CLOSED   |
          +-------------------+       +------------+
```

Every state transition is strictly validated by `is_valid_status_transition()` before being applied. Closed complaints cannot undergo further status transitions.
