# Testing & Code Coverage Report

## 1. Google Test Automation Overview

The CHS automated test suite is implemented in C++ using real Google Test (`<gtest/gtest.h>`) and linked directly against compiled production C object files (`-lgtest -lgtest_main -lpthread`).

### System Dependencies
On Ubuntu/Debian systems, install the Google Test developer headers and libraries:
```bash
sudo apt update && sudo apt install -y build-essential cmake libgtest-dev
```

If Google Test is not detected in the search path, the build system gracefully halts with clear installation instructions.

Target Test Count: **60–70 test cases**.
Actual Executed Test Cases: **76 test cases**.
Pass Rate: **100% (76 passed, 0 failed, 0 skipped)**.

---

## 2. Test Suite Breakdown

### 2.1 Mandatory Timestamp Tests (25 Tests) - `tests/test_timestamps.cpp`
1. `TimestampSuite.CreationTimestamp`: Verifies immutable creation timestamp.
2. `TimestampSuite.LastUpdatedTimestamp`: Verifies update timestamp tracking on note addition.
3. `TimestampSuite.AssignmentTimestamp`: Verifies timestamp recorded upon initial assignment.
4. `TimestampSuite.ReassignmentTimestamp`: Verifies reassignment timestamp and creation time preservation.
5. `TimestampSuite.StatusChangeTimestamps`: Verifies timestamps update on state transition.
6. `TimestampSuite.PriorityChangeTimestamps`: Verifies timestamps update on priority change.
7. `TimestampSuite.EscalationTimestamp`: Verifies escalation moment timestamping.
8. `TimestampSuite.ManagerAcknowledgmentTimestamp`: Verifies manager acknowledgment timestamp.
9. `TimestampSuite.ResolutionTimestamp`: Verifies resolution timestamp recorded upon agent fix.
10. `TimestampSuite.ClosureTimestamp`: Verifies closure timestamp on final archiving.
11. `TimestampSuite.HistoryTimestampOrdering`: Verifies chronological monotonic ordering in history.
12. `TimestampSuite.PersistenceAndTimestampReload`: Verifies timestamp preservation across restart.
13. `TimestampSuite.Exactly86400SecondsElapsed`: Verifies escalation at exactly 86,400s threshold.
14. `TimestampSuite.OneSecondBelowThreshold`: Verifies ticket does NOT escalate at 86,399s.
15. `TimestampSuite.OneSecondAboveThreshold`: Verifies ticket escalates at 86,401s.
16. `TimestampSuite.CriticalComplaintEscalation`: Verifies instant escalation for CRITICAL priority.
17. `TimestampSuite.ResolvedComplaintExcludedFromAgeEscalation`: Excludes resolved tickets after 48h.
18. `TimestampSuite.ClosedComplaintExcludedFromAgeEscalation`: Excludes closed tickets after 7 days.
19. `TimestampSuite.ReassignmentNotResettingOriginalTimer`: Verifies reassignment does not reset timer.
20. `TimestampSuite.OverdueComplaintDetectionAfterRestart`: Verifies overdue detection after system reboot.
21. `TimestampSuite.InvalidTimestamps`: Tests safe parsing of malformed/empty timestamp strings.
22. `TimestampSuite.FutureTimestamps`: Tests safe handling of future epoch representations.
23. `TimestampSuite.ConcurrentTimestampAndHistoryUpdates`: Tests high-frequency concurrent timestamp updates.
24. `TimestampSuite.DuplicateEscalationPrevention`: Prevents repeated escalation events on same ticket.
25. `TimestampSuite.FakeClockBehavior`: Verifies mock clock advancement and real-clock fallback.

### 2.2 Authentication & Security Tests (18 Tests) - `tests/test_auth.cpp`
- Customer registration success, duplicate username rejection, collision checks with agent/manager usernames.
- Input validation: short username, short password, malformed email, invalid phone format.
- Login operations: customer login success/failure, agent login success/failure, manager login success/failure.
- Inactive agent login blockage.
- Unique salt generation and constant-time memory comparison against timing attacks.

### 2.3 Complaint Lifecycle Tests (10 Tests) - `tests/test_complaint.cpp`
- Valid transitions: `OPEN` -> `ASSIGNED`, `ASSIGNED` -> `IN_PROGRESS`, `IN_PROGRESS` -> `RESOLVED`, `RESOLVED` -> `CLOSED`.
- Rejection of invalid transitions (e.g. `CLOSED` -> `OPEN`).
- Enforcement that tickets cannot be closed without resolution details.
- Enforcement of agent ownership for complaint modification.

### 2.4 Agent Assignment & Workload Tests (8 Tests) - `tests/test_assignment.cpp`
- Auto-assignment to least-loaded agent.
- Deterministic tie-breaking on lowest Agent ID.
- Exclusion of inactive agents during auto-assignment.
- Handling when all agents are deactivated (`STATUS_OPEN`, agent 0).
- Workload recalculation following complaint resolution and closure.
- Manager ticket reassignment with reason tracking.

### 2.5 Reports, Search & Concurrency Tests (15 Tests) - `tests/test_reports_search.cpp`
- Multi-filter searches: by Complaint ID, Customer ID, Agent ID, Status, Priority, and no-match handling.
- Customer privacy isolation: customer A cannot view customer B's complaints.
- Agent roster additions and duplicate name prevention.
- Background escalation monitoring thread startup and clean join shutdown.
- All 6 reports rendering to output streams without errors.
- String/enum round-trip conversions.

---

## 3. Code Coverage Results (gcov)

| Source File | Executed Lines | Total Lines | Coverage Percentage |
| :--- | :---: | :---: | :---: |
| `src/assignment.c` | 25 | 25 | **100.00%** |
| `src/storage.c` | 259 | 271 | **95.57%** |
| `src/auth.c` | 93 | 98 | **94.90%** |
| `src/search.c` | 36 | 38 | **94.74%** |
| `src/history.c` | 47 | 51 | **92.16%** |
| `src/security.c` | 144 | 157 | **91.72%** |
| `src/complaint.c` | 71 | 78 | **91.03%** |
| `src/time.c` | 44 | 49 | **89.80%** |
| `src/utils.c` | 86 | 98 | **87.76%** |
| `src/manager.c` | 115 | 135 | **85.19%** |
| `src/reports.c` | 150 | 181 | **82.87%** |
| `src/agent.c` | 146 | 180 | **81.11%** |
| `src/escalation.c` | 80 | 100 | **80.00%** |
| `src/customer.c` | 46 | 61 | **75.41%** |
| **Total Production Core** | **1,345** | **1,525** | **88.20%** |
