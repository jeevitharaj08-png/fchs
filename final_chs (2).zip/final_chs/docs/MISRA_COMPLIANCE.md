# MISRA C:2012 Compliance & Secure Coding Assessment

## 1. MISRA C Standard Adopted

This project follows the principles of **MISRA C:2012 (Guidelines for the use of the C language in critical systems)**, tailored for POSIX application-level software.

---

## 2. Secure Coding Practices Implemented

1. **Defined Behavior & Bounded Arithmetic**:
   - Explicit sizing using `<stdint.h>` (`uint8_t`, `uint32_t`, `uint64_t`).
   - Bounds-checked string manipulation using `snprintf` exclusively (banning unsafe `strcpy`, `sprintf`, `gets`).
2. **Explicit Conversions**:
   - Casts between integer types and pointer types are minimized and strictly typed.
3. **Pointer Validation & Memory Safety**:
   - Defensive `NULL` pointer checks at the entry of every public API function.
   - Pointers set to `NULL` immediately after `free()` in cleanup routines to eliminate dangling pointers.
4. **Const Correctness**:
   - Pointers to un-mutated read-only parameters and strings are qualified as `const`.
5. **Initialization**:
   - All structures allocated via `calloc` or initialized with `memset(..., 0, ...)` prior to use.
6. **Thread Safety**:
   - Mutex synchronization (`pthread_mutex_lock` / `pthread_mutex_unlock`) guards all accesses to mutable shared state.

---

## 3. Static Analysis Results (Cppcheck 2.22.0)

Command executed:
```bash
cppcheck --enable=all --inconclusive --std=c11 -Iinclude src/*.c
```

### Summary:
- **Errors**: 0
- **Warnings**: 0
- **Null Pointer Dereferences**: 0
- **Buffer Overflows**: 0
- **Memory Leaks**: 0
- **Portability Issues**: 0
- **Style Notices**: Functions exported as external library/test entry points flagged as unused in standalone `main.c` compilation units.

---

## 4. Documented MISRA Deviations

| MISRA Rule | Description | Justification / Deviation Detail |
| :--- | :--- | :--- |
| **Rule 8.7** | Functions with external linkage not used in all compilation units | Functions such as `chs_escalation_trigger`, `chs_agent_find_by_username`, and mock-clock controls are exported for the Google Test harness. |
| **Rule 21.10** | Standard library time functions should not be used | Real-time POSIX systems require calendar wall-clock timestamps (`time_t`, `clock_gettime`, `gmtime_r`). |
| **Rule 21.3** | Dynamic memory allocation should not be used | Enterprise linked lists for dynamic complaints and customers utilize `calloc` and `free` with strict RAII-style lifecycle ownership. |
| **Rule 21.6** | Standard I/O library should not be used | Console portal interfaces and text-file persistence require POSIX `stdio.h` file descriptors. |
