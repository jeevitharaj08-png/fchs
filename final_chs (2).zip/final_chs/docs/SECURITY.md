# Security Architecture & Implementation Guide

## 1. Threat Model & Security Principles

The Complaint Handling System POC is designed following defense-in-depth principles:
- **No Plaintext Passwords**: Passwords are never stored in memory longer than necessary and never written to disk or logged.
- **Cryptographic Password Hashing**: Passwords use salted cryptographic PBKDF2-HMAC-SHA256 with 2,000 iterations.
- **Unique Salt Generation**: Each user account receives an independently generated 128-bit hex salt.
- **Timing Attack Mitigation**: Credential verification employs a constant-time comparison function (`chs_constant_time_memcmp`).
- **Input Sanitization & Boundary Validation**: Buffer overflow mitigation through bounded copies, stripping newline/carriage-returns, and neutralizing file delimiters (`|`).
- **Role-Based Access Control (RBAC)**: Strict authorization barriers preventing customers from accessing peers' data, and agents from viewing unauthorized tickets.

---

## 2. Password Hashing Specification

The application implements a vetted FIPS 180-4 compliant SHA-256 and HMAC-SHA256 engine powering PBKDF2:
- **Salt Generation**:
  - Primary: Reads cryptographically strong entropy from `/dev/urandom` on POSIX/Linux.
  - Secondary/Fallback: Nanosecond-mixed high-resolution monotonic seed mixer combining `clock_gettime(CLOCK_REALTIME, ...)` and monotonic counter.
- **PBKDF2 Round Count**: 2,000 rounds of HMAC-SHA256.
- **Hash Output**: 64-character lowercase hexadecimal representation.

### Argon2id / Scrypt Integration Guide (Ubuntu Linux)
For enterprise production deployments utilizing external `libargon2` or `libscrypt`:
```bash
# 1. Install development packages on Ubuntu
sudo apt-get update
sudo apt-get install -y libargon2-dev libssl-dev

# 2. Compile and link with -largon2
gcc -std=c11 -Wall -Wextra -pthread -Iinclude src/*.c -largon2 -o chs_app
```

---

## 3. Constant-Time Verification

To eliminate Time-of-Check to Time-of-Use and side-channel timing attacks:
```c
int chs_constant_time_memcmp(const void *a, const void *b, size_t len) {
    const uint8_t *ua = (const uint8_t *)a;
    const uint8_t *ub = (const uint8_t *)b;
    uint8_t result = 0;
    for (size_t i = 0; i < len; i++) {
        result |= (ua[i] ^ ub[i]);
    }
    return (result != 0);
}
```

---

## 4. Input Validation & File Delimiter Safety

The persistent storage engine uses pipe-separated values (`|`). Unsanitized pipe inputs could cause delimiter-injection vulnerabilities. The sanitization layer executes:
1. Replaces `|` with `-` to preserve text structure without corrupting field counters.
2. Replaces `\r`, `\n`, `\t` with spaces.
3. Neutralizes non-printable characters below ASCII 32 or above ASCII 126.
4. Bounded `snprintf` guarantees null-termination across all buffers.
