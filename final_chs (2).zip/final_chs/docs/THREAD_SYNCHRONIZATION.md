# POSIX Multithreading & Thread Synchronization

## 1. Concurrency Architecture

The Complaint Handling System POC employs POSIX threads (`pthreads`) to decouple interactive operations from time-sensitive background SLA monitoring.

```
       [Main Application Thread]                     [Background Monitor Thread]
                  |                                               |
                  |                                  +---> [Wait on Cond / Timer]
   (Register Complaint / Update Note)                |            |
                  |                                  |     (Wakeup on Timeout)
       [Acquire state->lock]                         |            |
                  |                                  |   [Acquire state->lock]
         [Modify In-Memory State]                    |            |
                  |                                  |  [Scan for CRITICAL or >24h]
       [Release state->lock]                         |            |
                  |                                  |  [Update Status to ESCALATED]
                  |                                  |            |
                  |                                  |   [Release state->lock]
                  |                                  |            |
        (Shutdown Requested)                         +------------+
                  |
     [Set monitor_stop_req = true]
     [pthread_cond_broadcast(&cond)]
                  |
    [pthread_join(monitor_thread)]
                  |
        (Clean Destruction)
```

---

## 2. Synchronization Primitives

1. `pthread_mutex_t state->lock`:
   - Recursion-free standard mutual exclusion lock.
   - Guards all access to:
     - `customers` linked list
     - `agents` linked list
     - `complaints` linked list
     - `history` linked list
     - Sequential ID counters
2. `pthread_cond_t state->cond`:
   - Condition variable utilized in conjunction with `pthread_cond_timedwait`.
   - Allows the background monitoring thread to sleep for configurable intervals without burning CPU cycles, while supporting instantaneous interruption upon shutdown.

---

## 3. Deadlock Prevention Strategy

- **Single Lock Hierarchy**: The application utilizes a strictly unified lock hierarchy centered on `state->lock`. Because threads never hold multiple locks concurrently, lock-inversion deadlocks are mathematically impossible.
- **I/O Outside Locks**: File writes are executed with local snapshot copies or atomic temporary files, avoiding holding shared data locks across slow external I/O boundaries.
- **Controlled Timed Waits**: The monitor thread uses monotonic/realtime offsets to bound wait intervals.

---

## 4. Clean Shutdown Sequence

To ensure that Valgrind Memcheck and Helgrind report zero leaks or thread races:
```c
int chs_escalation_stop_monitor(AppState *state) {
    if (!state) return -1;
    pthread_mutex_lock(&state->lock);
    if (!state->monitor_running) {
        pthread_mutex_unlock(&state->lock);
        return 0;
    }
    state->monitor_stop_req = true;
    pthread_cond_broadcast(&state->cond);
    pthread_mutex_unlock(&state->lock);

    /* Cleanly join the background worker */
    pthread_join(state->monitor_thread, NULL);

    pthread_mutex_lock(&state->lock);
    state->monitor_running = false;
    pthread_mutex_unlock(&state->lock);
    return 0;
}
```
All resources are deallocated only after `pthread_join()` has returned, guaranteeing that no detached thread accesses freed memory.
