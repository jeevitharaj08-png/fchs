# Linux Environment Setup & Deployment Guide

## 1. Prerequisites (Ubuntu / Debian)

To build and run CHS natively on an Ubuntu/Debian system, install the core developer toolchain and Google Test libraries:

```bash
sudo apt update && sudo apt install -y build-essential cmake libgtest-dev
```

*(Additional analysis tools for coverage, static analysis, and memory profiling)*:
```bash
sudo apt install -y gcovr lcov cppcheck valgrind
```

*(Optional for Argon2id hardware-accelerated password hashing)*:
```bash
sudo apt install -y libargon2-dev libssl-dev
```

---

## 2. Compilation and Execution

1. **Clone or Navigate to the Repository**:
   ```bash
   cd final_chs
   ```

2. **Build the Production Application**:
   ```bash
   make app
   ```

3. **Run the Console Application**:
   ```bash
   ./chs_app
   ```

4. **Run the Automated Google Test Harness (76 Tests)**:
   ```bash
   make test
   ```

5. **Run Code Coverage Analysis (gcov)**:
   ```bash
   make coverage
   ```

6. **Execute Static Analysis (Cppcheck)**:
   ```bash
   make cppcheck
   ```

7. **Execute Valgrind Memcheck & Helgrind**:
   ```bash
   make valgrind
   make helgrind
   ```

---

## 3. Default Demo Credentials

| Role | Username | Default Password | Permissions |
| :--- | :--- | :--- | :--- |
| **Manager** | `manager` | `ManagerPass123!` | System-wide complaints, agent roster, ticket reassignment, escalation acknowledgment, report generation. |
| **Agents 1–10** | `agent1` .. `agent10` | `AgentPass123!` | View assigned complaints, triage tickets, log progress notes, elevate priority, resolve tickets. |
| **Customers** | Self-registered | Set by user | File complaints, track own tickets, view timestamps, review resolutions. |
