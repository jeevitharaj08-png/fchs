#include "chs_customer.h"

Customer* chs_customer_find_by_id(AppState *state, unsigned int id) {
    if (!state) return NULL;
    pthread_mutex_lock(&state->lock);
    Customer *c = state->customers;
    while (c) {
        if (c->id == id) {
            pthread_mutex_unlock(&state->lock);
            return c;
        }
        c = c->next;
    }
    pthread_mutex_unlock(&state->lock);
    return NULL;
}

Customer* chs_customer_find_by_username(AppState *state, const char *username) {
    if (!state || !username) return NULL;
    pthread_mutex_lock(&state->lock);
    Customer *c = state->customers;
    while (c) {
        if (strcmp(c->username, username) == 0) {
            pthread_mutex_unlock(&state->lock);
            return c;
        }
        c = c->next;
    }
    pthread_mutex_unlock(&state->lock);
    return NULL;
}

int chs_customer_get_complaints(AppState *state, unsigned int customer_id, Complaint ***results_out, size_t *count_out) {
    if (!state || !results_out || !count_out) return -1;
    *results_out = NULL;
    *count_out = 0;

    pthread_mutex_lock(&state->lock);

    size_t count = 0;
    Complaint *cmp = state->complaints;
    while (cmp) {
        if (cmp->customer_id == customer_id) {
            count++;
        }
        cmp = cmp->next;
    }

    if (count == 0) {
        pthread_mutex_unlock(&state->lock);
        return 0;
    }

    Complaint **arr = (Complaint **)calloc(count, sizeof(Complaint *));
    if (!arr) {
        pthread_mutex_unlock(&state->lock);
        return -1;
    }

    size_t idx = 0;
    cmp = state->complaints;
    while (cmp && idx < count) {
        if (cmp->customer_id == customer_id) {
            arr[idx++] = cmp;
        }
        cmp = cmp->next;
    }

    pthread_mutex_unlock(&state->lock);

    *results_out = arr;
    *count_out = count;
    return 0;
}

Complaint* chs_customer_get_complaint_by_id(AppState *state, unsigned int customer_id, unsigned int complaint_id) {
    if (!state) return NULL;
    pthread_mutex_lock(&state->lock);
    Complaint *cmp = state->complaints;
    while (cmp) {
        if (cmp->id == complaint_id && cmp->customer_id == customer_id) {
            pthread_mutex_unlock(&state->lock);
            return cmp;
        }
        cmp = cmp->next;
    }
    pthread_mutex_unlock(&state->lock);
    return NULL;
}
