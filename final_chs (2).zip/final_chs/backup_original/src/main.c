#include "chs.h"

static int chs_read_line(const char *prompt, char *buffer, size_t max_len) {
    if (prompt) {
        printf("%s", prompt);
        fflush(stdout);
    }
    if (!fgets(buffer, (int)max_len, stdin)) {
        buffer[0] = '\0';
        return -1;
    }
    size_t len = strlen(buffer);
    while (len > 0 && (buffer[len - 1] == '\n' || buffer[len - 1] == '\r')) {
        buffer[len - 1] = '\0';
        len--;
    }
    return 0;
}

static int chs_read_int(const char *prompt) {
    char buf[64];
    if (chs_read_line(prompt, buf, sizeof(buf)) != 0) {
        return -1;
    }
    if (buf[0] == '\0') {
        return -1;
    }
    return atoi(buf);
}

/* ---------------- Customer Portal ---------------- */
static void customer_portal_menu(AppState *state, unsigned int customer_id) {
    Customer *cust = chs_customer_find_by_id(state, customer_id);
    if (!cust) return;

    while (1) {
        printf("\n=======================================================\n");
        printf("           CUSTOMER PORTAL - Welcome, %s               \n", cust->full_name);
        printf("=======================================================\n");
        printf(" 1. Register New Complaint\n");
        printf(" 2. View My Complaints\n");
        printf(" 3. Search Complaint by ID\n");
        printf(" 4. View Complaint History & Resolution Details\n");
        printf(" 5. Logout\n");
        printf("-------------------------------------------------------\n");
        int choice = chs_read_int("Enter option: ");
        if (choice == -1 && feof(stdin)) break;

        if (choice == 1) {
            char cat[MAX_CATEGORY_LEN], desc[MAX_DESC_LEN];
            printf("\n--- Register Complaint ---\n");
            chs_read_line("Category (e.g., Technical, Billing, Service): ", cat, sizeof(cat));
            chs_read_line("Description: ", desc, sizeof(desc));
            printf("Priority (0=LOW, 1=MEDIUM, 2=HIGH, 3=CRITICAL): ");
            int pr_val = chs_read_int("");
            ComplaintPriority pr = (pr_val >= 0 && pr_val <= 3) ? (ComplaintPriority)pr_val : PRIORITY_LOW;

            unsigned int new_id = 0;
            int ret = chs_complaint_register(state, customer_id, cat, desc, pr, &new_id);
            if (ret == 0) {
                printf("[SUCCESS] Complaint #%u registered successfully and automatically assigned!\n", new_id);
            } else {
                printf("[ERROR] Failed to register complaint (Error code: %d)\n", ret);
            }
        } else if (choice == 2) {
            Complaint **cmps = NULL;
            size_t count = 0;
            chs_customer_get_complaints(state, customer_id, &cmps, &count);
            printf("\n--- My Complaints (Total: %zu) ---\n", count);
            for (size_t i = 0; i < count; i++) {
                char c_ts[64];
                chs_format_iso(cmps[i]->created_at, c_ts, sizeof(c_ts));
                printf(" #%-5u | Status: %-12s | Priority: %-8s | Agent: %-2u | Created: %s\n",
                       cmps[i]->id, status_to_string(cmps[i]->status),
                       priority_to_string(cmps[i]->priority),
                       cmps[i]->assigned_agent_id, c_ts);
                printf("        Category: %s | Desc: %s\n", cmps[i]->category, cmps[i]->description);
            }
            if (cmps) free(cmps);
        } else if (choice == 3) {
            unsigned int cid = (unsigned int)chs_read_int("\nEnter Complaint ID: ");
            Complaint *c = chs_customer_get_complaint_by_id(state, customer_id, cid);
            if (!c) {
                printf("[ERROR] Complaint #%u not found or you are not authorized to view it.\n", cid);
            } else {
                char c_ts[64], u_ts[64], r_ts[64];
                chs_format_iso(c->created_at, c_ts, sizeof(c_ts));
                chs_format_iso(c->updated_at, u_ts, sizeof(u_ts));
                chs_format_iso(c->resolved_at, r_ts, sizeof(r_ts));
                printf("\n--- Complaint #%u Details ---\n", c->id);
                printf(" Status:       %s\n", status_to_string(c->status));
                printf(" Priority:     %s\n", priority_to_string(c->priority));
                printf(" Category:     %s\n", c->category);
                printf(" Description:  %s\n", c->description);
                printf(" Agent ID:     %u\n", c->assigned_agent_id);
                printf(" Created At:   %s\n", c_ts);
                printf(" Updated At:   %s\n", u_ts);
                if (c->status == STATUS_RESOLVED || c->status == STATUS_CLOSED) {
                    printf(" Resolved At:  %s\n", r_ts);
                    printf(" Resolution:   %s\n", c->resolution_details);
                }
            }
        } else if (choice == 4) {
            unsigned int cid = (unsigned int)chs_read_int("\nEnter Complaint ID for History: ");
            Complaint *c = chs_customer_get_complaint_by_id(state, customer_id, cid);
            if (!c) {
                printf("[ERROR] Complaint not found or not owned by you.\n");
            } else {
                chs_report_complaint_history(state, cid, stdout);
            }
        } else if (choice == 5) {
            printf("Logging out of customer portal...\n");
            break;
        }
    }
}

static void customer_portal_entry(AppState *state) {
    while (1) {
        printf("\n=======================================================\n");
        printf("                   CUSTOMER PORTAL                     \n");
        printf("=======================================================\n");
        printf(" 1. Login\n");
        printf(" 2. Register New Account\n");
        printf(" 3. Back to Main Menu\n");
        printf("-------------------------------------------------------\n");
        int choice = chs_read_int("Enter option: ");
        if (choice == -1 && feof(stdin)) break;

        if (choice == 1) {
            char u[MAX_USERNAME_LEN], p[64];
            chs_read_line("Username: ", u, sizeof(u));
            chs_read_line("Password: ", p, sizeof(p));
            UserRole role;
            unsigned int uid;
            if (chs_auth_login(state, u, p, &role, &uid) == 0 && role == ROLE_CUSTOMER) {
                printf("[SUCCESS] Login successful!\n");
                customer_portal_menu(state, uid);
            } else {
                printf("[ERROR] Invalid customer credentials.\n");
            }
        } else if (choice == 2) {
            char u[MAX_USERNAME_LEN], p[64], fn[MAX_NAME_LEN], em[MAX_EMAIL_LEN], ph[MAX_PHONE_LEN];
            printf("\n--- Customer Registration ---\n");
            chs_read_line("Desired Username: ", u, sizeof(u));
            chs_read_line("Password: ", p, sizeof(p));
            chs_read_line("Full Name: ", fn, sizeof(fn));
            chs_read_line("Email Address: ", em, sizeof(em));
            chs_read_line("Contact Phone: ", ph, sizeof(ph));

            unsigned int new_id = 0;
            int ret = chs_auth_register_customer(state, u, p, fn, em, ph, &new_id);
            if (ret == 0) {
                printf("[SUCCESS] Registration successful! Your Customer ID is %u. You may now log in.\n", new_id);
            } else if (ret == -3) {
                printf("[ERROR] Username is already taken.\n");
            } else {
                printf("[ERROR] Invalid registration data (code: %d). Please check email/phone format.\n", ret);
            }
        } else if (choice == 3) {
            break;
        }
    }
}

/* ---------------- Agent Portal ---------------- */
static void agent_portal_menu(AppState *state, unsigned int agent_id) {
    Agent *a = chs_agent_find_by_id(state, agent_id);
    if (!a) return;

    while (1) {
        printf("\n=======================================================\n");
        printf("            AGENT PORTAL - %s (ID: %u)                 \n", a->full_name, a->id);
        printf("=======================================================\n");
        printf(" 1. View My Assigned Complaints\n");
        printf(" 2. Search Complaint by ID\n");
        printf(" 3. Update Complaint Status\n");
        printf(" 4. Add Progress Note\n");
        printf(" 5. Change Priority\n");
        printf(" 6. Resolve Complaint\n");
        printf(" 7. View Current Workload\n");
        printf(" 8. View Complaint History\n");
        printf(" 9. Logout\n");
        printf("-------------------------------------------------------\n");
        int choice = chs_read_int("Enter option: ");
        if (choice == -1 && feof(stdin)) break;

        if (choice == 1) {
            Complaint **cmps = NULL;
            size_t count = 0;
            chs_agent_get_assigned_complaints(state, agent_id, &cmps, &count);
            printf("\n--- Assigned Complaints (Total: %zu) ---\n", count);
            for (size_t i = 0; i < count; i++) {
                char c_ts[64];
                chs_format_iso(cmps[i]->created_at, c_ts, sizeof(c_ts));
                printf(" #%-5u | Cust: %-3u | Status: %-12s | Priority: %-8s | Created: %s\n",
                       cmps[i]->id, cmps[i]->customer_id,
                       status_to_string(cmps[i]->status),
                       priority_to_string(cmps[i]->priority), c_ts);
                printf("        Category: %s | Description: %s\n", cmps[i]->category, cmps[i]->description);
            }
            if (cmps) free(cmps);
        } else if (choice == 2) {
            unsigned int cid = (unsigned int)chs_read_int("\nEnter Complaint ID: ");
            Complaint *c = chs_complaint_find_by_id(state, cid);
            if (!c || c->assigned_agent_id != agent_id) {
                printf("[ERROR] Complaint not found or not assigned to you.\n");
            } else {
                char c_ts[64], u_ts[64];
                chs_format_iso(c->created_at, c_ts, sizeof(c_ts));
                chs_format_iso(c->updated_at, u_ts, sizeof(u_ts));
                printf("\n--- Complaint #%u ---\n", c->id);
                printf(" Customer ID: %u | Status: %s | Priority: %s\n",
                       c->customer_id, status_to_string(c->status), priority_to_string(c->priority));
                printf(" Category: %s | Description: %s\n", c->category, c->description);
                printf(" Created At: %s | Updated At: %s\n", c_ts, u_ts);
            }
        } else if (choice == 3) {
            unsigned int cid = (unsigned int)chs_read_int("\nEnter Complaint ID: ");
            printf("Select New Status (1=ASSIGNED, 2=IN_PROGRESS, 3=ESCALATED, 4=RESOLVED): ");
            int st_val = chs_read_int("");
            int ret = chs_agent_update_status(state, agent_id, cid, (ComplaintStatus)st_val);
            if (ret == 0) {
                printf("[SUCCESS] Status updated successfully!\n");
            } else {
                printf("[ERROR] Failed to update status (code: %d)\n", ret);
            }
        } else if (choice == 4) {
            unsigned int cid = (unsigned int)chs_read_int("\nEnter Complaint ID: ");
            char note[MAX_NOTE_LEN];
            chs_read_line("Enter Progress Note: ", note, sizeof(note));
            int ret = chs_agent_add_note(state, agent_id, cid, note);
            if (ret == 0) {
                printf("[SUCCESS] Note added successfully!\n");
            } else {
                printf("[ERROR] Failed to add note (code: %d)\n", ret);
            }
        } else if (choice == 5) {
            unsigned int cid = (unsigned int)chs_read_int("\nEnter Complaint ID: ");
            printf("Select New Priority (0=LOW, 1=MEDIUM, 2=HIGH, 3=CRITICAL): ");
            int pr_val = chs_read_int("");
            int ret = chs_agent_change_priority(state, agent_id, cid, (ComplaintPriority)pr_val);
            if (ret == 0) {
                printf("[SUCCESS] Priority changed! (Note: CRITICAL priority triggers auto-escalation)\n");
            } else {
                printf("[ERROR] Failed to change priority (code: %d)\n", ret);
            }
        } else if (choice == 6) {
            unsigned int cid = (unsigned int)chs_read_int("\nEnter Complaint ID to Resolve: ");
            char res[MAX_NOTE_LEN];
            chs_read_line("Resolution Details: ", res, sizeof(res));
            int ret = chs_agent_resolve(state, agent_id, cid, res);
            if (ret == 0) {
                printf("[SUCCESS] Complaint #%u resolved successfully!\n", cid);
            } else {
                printf("[ERROR] Failed to resolve complaint (code: %d)\n", ret);
            }
        } else if (choice == 7) {
            pthread_mutex_lock(&state->lock);
            int wl = chs_agent_calculate_workload(state, agent_id);
            pthread_mutex_unlock(&state->lock);
            printf("\n[INFO] Your Current Active Workload: %d pending/active complaints\n", wl);
        } else if (choice == 8) {
            unsigned int cid = (unsigned int)chs_read_int("\nEnter Complaint ID for History: ");
            chs_report_complaint_history(state, cid, stdout);
        } else if (choice == 9) {
            printf("Logging out of agent portal...\n");
            break;
        }
    }
}

static void agent_portal_entry(AppState *state) {
    printf("\n=======================================================\n");
    printf("                     AGENT PORTAL                      \n");
    printf("=======================================================\n");
    char u[MAX_USERNAME_LEN], p[64];
    chs_read_line("Agent Username (e.g. agent1 to agent10): ", u, sizeof(u));
    chs_read_line("Password (default: AgentPass123!): ", p, sizeof(p));

    UserRole role;
    unsigned int uid;
    int res = chs_auth_login(state, u, p, &role, &uid);
    if (res == 0 && role == ROLE_AGENT) {
        printf("[SUCCESS] Welcome, Agent %u!\n", uid);
        agent_portal_menu(state, uid);
    } else if (res == -2) {
        printf("[ERROR] This agent account has been deactivated by management.\n");
    } else {
        printf("[ERROR] Invalid agent credentials.\n");
    }
}

/* ---------------- Manager Portal ---------------- */
static void manager_escalation_section(AppState *state) {
    while (1) {
        printf("\n=======================================================\n");
        printf("       *** PROMINENT ESCALATION MANAGEMENT HUB ***      \n");
        printf("=======================================================\n");
        printf(" 1. View All Escalated Complaints\n");
        printf(" 2. View Critical Priority Complaints\n");
        printf(" 3. View Complaints Overdue (>= 24 Hours)\n");
        printf(" 4. Acknowledge and Handle Escalation\n");
        printf(" 5. Back to Manager Menu\n");
        printf("-------------------------------------------------------\n");
        int choice = chs_read_int("Enter option: ");
        if (choice == -1 && feof(stdin)) break;

        if (choice == 1) {
            chs_report_escalations(state, stdout);
        } else if (choice == 2) {
            Complaint **cmps = NULL;
            size_t count = 0;
            chs_search_complaints(state, -1, -1, -1, PRIORITY_CRITICAL, &cmps, &count);
            printf("\n--- Critical Priority Complaints (Count: %zu) ---\n", count);
            for (size_t i = 0; i < count; i++) {
                char e_ts[64];
                chs_format_iso(cmps[i]->escalated_at, e_ts, sizeof(e_ts));
                printf(" #%-5u | Status: %-12s | Agent: %-2u | Escalated At: %s | Reason: %s\n",
                       cmps[i]->id, status_to_string(cmps[i]->status),
                       cmps[i]->assigned_agent_id, e_ts, cmps[i]->escalation_reason);
            }
            if (cmps) free(cmps);
        } else if (choice == 3) {
            pthread_mutex_lock(&state->lock);
            time_t now = chs_get_time(state);
            printf("\n--- Complaints Overdue by >= 24 Hours ---\n");
            int cnt = 0;
            Complaint *c = state->complaints;
            while (c) {
                if (c->status != STATUS_RESOLVED && c->status != STATUS_CLOSED) {
                    double age = chs_difftime(now, c->created_at);
                    if (age >= ESCALATION_TIMEOUT_SEC) {
                        cnt++;
                        char ts[64];
                        chs_format_iso(c->created_at, ts, sizeof(ts));
                        printf(" #%-5u | Created: %s | Age: %.0fs (%.1fh) | Status: %s | Agent: %u\n",
                               c->id, ts, age, age / 3600.0, status_to_string(c->status), c->assigned_agent_id);
                    }
                }
                c = c->next;
            }
            if (cnt == 0) printf(" No overdue complaints found.\n");
            pthread_mutex_unlock(&state->lock);
        } else if (choice == 4) {
            unsigned int cid = (unsigned int)chs_read_int("\nEnter Escalated Complaint ID: ");
            char notes[MAX_NOTE_LEN];
            chs_read_line("Enter Manager Acknowledgment Notes: ", notes, sizeof(notes));
            int ret = chs_manager_acknowledge_escalation(state, cid, notes);
            if (ret == 0) {
                printf("[SUCCESS] Escalation acknowledged and logged with manager timestamp!\n");
            } else {
                printf("[ERROR] Failed to acknowledge escalation (code: %d)\n", ret);
            }
        } else if (choice == 5) {
            break;
        }
    }
}

static void manager_reports_section(AppState *state) {
    while (1) {
        printf("\n=======================================================\n");
        printf("                  ANALYTICS & REPORTS                  \n");
        printf("=======================================================\n");
        printf(" 1. Complaint Summary Report\n");
        printf(" 2. Priority Distribution Report\n");
        printf(" 3. Agent Workload & Assignment Report\n");
        printf(" 4. Escalations Audit Report\n");
        printf(" 5. Customer Complaint Summary Report\n");
        printf(" 6. Complaint History Audit by ID\n");
        printf(" 7. Back to Manager Menu\n");
        printf("-------------------------------------------------------\n");
        int choice = chs_read_int("Enter option: ");
        if (choice == -1 && feof(stdin)) break;

        if (choice == 1) chs_report_complaint_summary(state, stdout);
        else if (choice == 2) chs_report_priority(state, stdout);
        else if (choice == 3) chs_report_agent_workload(state, stdout);
        else if (choice == 4) chs_report_escalations(state, stdout);
        else if (choice == 5) chs_report_customer_summary(state, stdout);
        else if (choice == 6) {
            unsigned int cid = (unsigned int)chs_read_int("Enter Complaint ID (0 for all): ");
            chs_report_complaint_history(state, cid, stdout);
        } else if (choice == 7) break;
    }
}

static void manager_portal_menu(AppState *state) {
    while (1) {
        printf("\n=======================================================\n");
        printf("                    MANAGER PORTAL                     \n");
        printf("=======================================================\n");
        printf(" 1. View All Complaints\n");
        printf(" 2. View All Customers\n");
        printf(" 3. View Agents & Manage Roster\n");
        printf(" 4. Add New Agent\n");
        printf(" 5. Deactivate / Reactivate Agent\n");
        printf(" 6. Reassign Complaint\n");
        printf(" 7. *** ESCALATION MANAGEMENT HUB ***\n");
        printf(" 8. Close Resolved Complaint\n");
        printf(" 9. Reports & Audits\n");
        printf(" 10. Logout\n");
        printf("-------------------------------------------------------\n");
        int choice = chs_read_int("Enter option: ");
        if (choice == -1 && feof(stdin)) break;

        if (choice == 1) {
            chs_report_complaint_summary(state, stdout);
        } else if (choice == 2) {
            pthread_mutex_lock(&state->lock);
            printf("\n--- Registered Customers ---\n");
            Customer *c = state->customers;
            while (c) {
                char ts[64];
                chs_format_iso(c->created_at, ts, sizeof(ts));
                printf(" ID: #%-4u | Username: %-14s | Name: %-18s | Email: %-20s | Created: %s\n",
                       c->id, c->username, c->full_name, c->email, ts);
                c = c->next;
            }
            pthread_mutex_unlock(&state->lock);
        } else if (choice == 3) {
            chs_report_agent_workload(state, stdout);
        } else if (choice == 4) {
            char u[MAX_USERNAME_LEN], p[64], fn[MAX_NAME_LEN];
            printf("\n--- Add Agent ---\n");
            chs_read_line("Username: ", u, sizeof(u));
            chs_read_line("Password: ", p, sizeof(p));
            chs_read_line("Full Name: ", fn, sizeof(fn));
            unsigned int new_id = 0;
            int ret = chs_manager_add_agent(state, u, p, fn, &new_id);
            if (ret == 0) {
                printf("[SUCCESS] Agent added with ID: %u\n", new_id);
            } else {
                printf("[ERROR] Failed to add agent (code: %d)\n", ret);
            }
        } else if (choice == 5) {
            unsigned int aid = (unsigned int)chs_read_int("\nEnter Agent ID: ");
            printf("Set status (1=Activate, 0=Deactivate): ");
            int act = chs_read_int("");
            int ret = chs_manager_set_agent_active(state, aid, (act != 0));
            if (ret == 0) {
                printf("[SUCCESS] Agent #%u status updated.\n", aid);
            } else {
                printf("[ERROR] Failed to update agent status.\n");
            }
        } else if (choice == 6) {
            unsigned int cid = (unsigned int)chs_read_int("\nEnter Complaint ID: ");
            unsigned int aid = (unsigned int)chs_read_int("Enter New Agent ID: ");
            char r[MAX_REASON_LEN];
            chs_read_line("Reason for reassignment: ", r, sizeof(r));
            int ret = chs_manager_reassign_complaint(state, cid, aid, r);
            if (ret == 0) {
                printf("[SUCCESS] Complaint #%u reassigned to Agent #%u.\n", cid, aid);
            } else {
                printf("[ERROR] Reassignment failed (code: %d)\n", ret);
            }
        } else if (choice == 7) {
            manager_escalation_section(state);
        } else if (choice == 8) {
            unsigned int cid = (unsigned int)chs_read_int("\nEnter Complaint ID to Close: ");
            int ret = chs_manager_close_complaint(state, cid);
            if (ret == 0) {
                printf("[SUCCESS] Complaint #%u officially closed.\n", cid);
            } else {
                printf("[ERROR] Cannot close complaint (code: %d). Must be in RESOLVED status with resolution details.\n", ret);
            }
        } else if (choice == 9) {
            manager_reports_section(state);
        } else if (choice == 10) {
            printf("Logging out of manager portal...\n");
            break;
        }
    }
}

static void manager_portal_entry(AppState *state) {
    printf("\n=======================================================\n");
    printf("                    MANAGER LOGIN                      \n");
    printf("=======================================================\n");
    char u[MAX_USERNAME_LEN], p[64];
    chs_read_line("Username (default: manager): ", u, sizeof(u));
    chs_read_line("Password (default: ManagerPass123!): ", p, sizeof(p));

    UserRole role;
    unsigned int uid;
    if (chs_auth_login(state, u, p, &role, &uid) == 0 && role == ROLE_MANAGER) {
        printf("[SUCCESS] Manager authenticated successfully!\n");
        manager_portal_menu(state);
    } else {
        printf("[ERROR] Invalid manager credentials.\n");
    }
}

/* ---------------- Main Menu ---------------- */
int main(int argc, char *argv[]) {
    const char *data_dir = (argc > 1) ? argv[1] : "data";

    AppState state;
    if (chs_init(&state, data_dir) != 0) {
        fprintf(stderr, "Fatal: Failed to initialize Complaint Handling System.\n");
        return 1;
    }

    /* Start background escalation monitoring thread */
    chs_escalation_start_monitor(&state);

    printf("\n*******************************************************\n");
    printf("*             COMPLAINT HANDLING SYSTEM POC           *\n");
    printf("*      Linux POSIX Multithreaded Complaint Engine     *\n");
    printf("*******************************************************\n");

    while (1) {
        printf("\n=======================================================\n");
        printf("                      MAIN MENU                        \n");
        printf("=======================================================\n");
        printf(" 1. Customer Portal\n");
        printf(" 2. Agent Portal\n");
        printf(" 3. Manager Portal\n");
        printf(" 4. Exit\n");
        printf("=======================================================\n");
        int option = chs_read_int("Select an option (1-4): ");
        if (option == -1 && feof(stdin)) {
            printf("\nExiting...\n");
            break;
        }

        if (option == 1) {
            customer_portal_entry(&state);
        } else if (option == 2) {
            agent_portal_entry(&state);
        } else if (option == 3) {
            manager_portal_entry(&state);
        } else if (option == 4) {
            printf("\nShutting down Complaint Handling System safely...\n");
            break;
        } else {
            printf("[WARNING] Invalid selection. Please enter 1, 2, 3, or 4.\n");
        }
    }

    chs_cleanup(&state);
    printf("All threads joined and resources released cleanly. Goodbye!\n");
    return 0;
}
