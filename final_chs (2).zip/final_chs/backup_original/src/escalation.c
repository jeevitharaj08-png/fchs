#include "chs_escalation.h"
#include "chs_time.h"
#include "chs_history.h"
#include "chs_storage.h"

int chs_escalation_check_all(AppState *state) {
    if (!state) return -1;

    pthread_mutex_lock(&state->lock);

    time_t now = chs_get_time(state);
    bool changed = false;

    Complaint *cmp = state->complaints;
    while (cmp) {
        if (!cmp->is_escalated) {
            /* Rule 1: CRITICAL priority */
            if (cmp->priority == PRIORITY_CRITICAL) {
                cmp->is_escalated = true;
                cmp->escalated_at = now;
                cmp->status = STATUS_ESCALATED;
                snprintf(cmp->escalation_reason, sizeof(cmp->escalation_reason), "Priority is CRITICAL");
                chs_history_append(state, cmp->id, "ESCALATED", "-", "CRITICAL", "MONITOR", "Auto-escalated by background monitor");
                changed = true;
            }
            /* Rule 2: Unresolved for at least 24 hours (86,400 seconds) */
            else if (cmp->status != STATUS_RESOLVED && cmp->status != STATUS_CLOSED) {
                if (chs_difftime(now, cmp->created_at) >= ESCALATION_TIMEOUT_SEC) {
                    cmp->is_escalated = true;
                    cmp->escalated_at = now;
                    cmp->status = STATUS_ESCALATED;
                    snprintf(cmp->escalation_reason, sizeof(cmp->escalation_reason), "Unresolved for >= 24 hours");
                    chs_history_append(state, cmp->id, "ESCALATED", "-", "ESCALATED", "MONITOR", "Auto-escalated: exceeded 24-hour threshold");
                    changed = true;
                }
            }
        }
        cmp = cmp->next;
    }

    if (changed) {
        chs_storage_save_complaints(state);
    }

    pthread_mutex_unlock(&state->lock);
    return 0;
}

int chs_escalation_trigger(AppState *state, unsigned int complaint_id, const char *reason, const char *acting_user) {
    if (!state) return -1;

    pthread_mutex_lock(&state->lock);

    Complaint *cmp = state->complaints;
    while (cmp && cmp->id != complaint_id) {
        cmp = cmp->next;
    }
    if (!cmp) {
        pthread_mutex_unlock(&state->lock);
        return -1;
    }

    if (cmp->is_escalated) {
        pthread_mutex_unlock(&state->lock);
        return -2; /* Already escalated: prevent duplicate escalation events */
    }

    time_t now = chs_get_time(state);
    cmp->is_escalated = true;
    cmp->escalated_at = now;
    cmp->status = STATUS_ESCALATED;
    snprintf(cmp->escalation_reason, sizeof(cmp->escalation_reason), "%s", reason ? reason : "Manual escalation");

    chs_history_append(state, complaint_id, "ESCALATED", "-", "ESCALATED",
                       acting_user ? acting_user : "SYSTEM", cmp->escalation_reason);
    chs_storage_save_complaints(state);

    pthread_mutex_unlock(&state->lock);
    return 0;
}

static void* monitor_worker_routine(void *arg) {
    AppState *state = (AppState *)arg;
    if (!state) return NULL;

    while (1) {
        pthread_mutex_lock(&state->lock);
        if (state->monitor_stop_req) {
            pthread_mutex_unlock(&state->lock);
            break;
        }

        /* Check for escalations */
        pthread_mutex_unlock(&state->lock);
        chs_escalation_check_all(state);
        pthread_mutex_lock(&state->lock);

        if (state->monitor_stop_req) {
            pthread_mutex_unlock(&state->lock);
            break;
        }

        /* Timed wait using pthread_cond_timedwait */
        struct timespec ts;
        clock_gettime(CLOCK_REALTIME, &ts);
        int interval = state->monitor_interval_sec > 0 ? state->monitor_interval_sec : 1;
        ts.tv_sec += interval;

        pthread_cond_timedwait(&state->cond, &state->lock, &ts);

        if (state->monitor_stop_req) {
            pthread_mutex_unlock(&state->lock);
            break;
        }
        pthread_mutex_unlock(&state->lock);
    }
    return NULL;
}

int chs_escalation_start_monitor(AppState *state) {
    if (!state) return -1;
    pthread_mutex_lock(&state->lock);
    if (state->monitor_running) {
        pthread_mutex_unlock(&state->lock);
        return 0; /* Already running */
    }
    state->monitor_stop_req = false;
    state->monitor_running = true;

    if (pthread_create(&state->monitor_thread, NULL, monitor_worker_routine, state) != 0) {
        state->monitor_running = false;
        pthread_mutex_unlock(&state->lock);
        return -1;
    }

    pthread_mutex_unlock(&state->lock);
    return 0;
}

int chs_escalation_stop_monitor(AppState *state) {
    if (!state) return -1;
    pthread_mutex_lock(&state->lock);
    if (!state->monitor_running) {
        pthread_mutex_unlock(&state->lock);
        return 0;
    }
    state->monitor_stop_req = true;
    pthread_cond_broadcast(&state->cond);
    pthread_mutex_unlock(&state->lock);

    pthread_join(state->monitor_thread, NULL);

    pthread_mutex_lock(&state->lock);
    state->monitor_running = false;
    pthread_mutex_unlock(&state->lock);

    return 0;
}
