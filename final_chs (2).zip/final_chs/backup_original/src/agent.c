#include "chs_agent.h"
#include "chs_security.h"
#include "chs_time.h"
#include "chs_storage.h"
#include "chs_history.h"
#include "chs_escalation.h"

int chs_agent_init_defaults(AppState *state) {
    if (!state) return -1;
    if (state->agents != NULL) return 0; /* Already initialized/loaded */

    for (unsigned int i = 1; i <= INITIAL_AGENT_COUNT; i++) {
        Agent *a = (Agent *)calloc(1, sizeof(Agent));
        if (!a) return -1;

        a->id = i;
        snprintf(a->username, sizeof(a->username), "agent%u", i);
        snprintf(a->full_name, sizeof(a->full_name), "Agent %u", i);
        a->is_active = true;
        a->created_at = chs_get_time(state);
        a->deactivated_at = 0;

        chs_generate_salt(a->salt, sizeof(a->salt));
        /* Default password for demo agents */
        chs_hash_password("AgentPass123!", a->salt, a->password_hash, sizeof(a->password_hash));
        a->next = NULL;

        if (!state->agents) {
            state->agents = a;
        } else {
            Agent *curr = state->agents;
            while (curr->next) curr = curr->next;
            curr->next = a;
        }
    }
    state->next_agent_id = INITIAL_AGENT_COUNT + 1;
    chs_storage_save_agents(state);
    return 0;
}

Agent* chs_agent_find_by_id(AppState *state, unsigned int id) {
    if (!state) return NULL;
    pthread_mutex_lock(&state->lock);
    Agent *a = state->agents;
    while (a) {
        if (a->id == id) {
            pthread_mutex_unlock(&state->lock);
            return a;
        }
        a = a->next;
    }
    pthread_mutex_unlock(&state->lock);
    return NULL;
}

Agent* chs_agent_find_by_username(AppState *state, const char *username) {
    if (!state || !username) return NULL;
    pthread_mutex_lock(&state->lock);
    Agent *a = state->agents;
    while (a) {
        if (strcmp(a->username, username) == 0) {
            pthread_mutex_unlock(&state->lock);
            return a;
        }
        a = a->next;
    }
    pthread_mutex_unlock(&state->lock);
    return NULL;
}

int chs_agent_calculate_workload(AppState *state, unsigned int agent_id) {
    if (!state) return 0;
    int workload = 0;
    Complaint *cmp = state->complaints;
    while (cmp) {
        if (cmp->assigned_agent_id == agent_id &&
            cmp->status != STATUS_RESOLVED &&
            cmp->status != STATUS_CLOSED) {
            workload++;
        }
        cmp = cmp->next;
    }
    return workload;
}

int chs_agent_get_assigned_complaints(AppState *state, unsigned int agent_id, Complaint ***results_out, size_t *count_out) {
    if (!state || !results_out || !count_out) return -1;
    *results_out = NULL;
    *count_out = 0;

    pthread_mutex_lock(&state->lock);

    size_t count = 0;
    Complaint *cmp = state->complaints;
    while (cmp) {
        if (cmp->assigned_agent_id == agent_id) {
            count++;
        }
        cmp = cmp->next;
    }

    if (count == 0) {
        pthread_mutex_unlock(&state->lock);
        return 0;
    }

    Complaint **arr = (Complaint **)calloc(count, sizeof(Complaint *));
    if (!arr) {
        pthread_mutex_unlock(&state->lock);
        return -1;
    }

    size_t idx = 0;
    cmp = state->complaints;
    while (cmp && idx < count) {
        if (cmp->assigned_agent_id == agent_id) {
            arr[idx++] = cmp;
        }
        cmp = cmp->next;
    }

    pthread_mutex_unlock(&state->lock);

    *results_out = arr;
    *count_out = count;
    return 0;
}

int chs_agent_update_status(AppState *state, unsigned int agent_id, unsigned int complaint_id, ComplaintStatus new_status) {
    if (!state) return -1;

    pthread_mutex_lock(&state->lock);

    Complaint *cmp = state->complaints;
    while (cmp && cmp->id != complaint_id) {
        cmp = cmp->next;
    }

    if (!cmp) {
        pthread_mutex_unlock(&state->lock);
        return -1; /* Complaint not found */
    }

    if (cmp->assigned_agent_id != agent_id) {
        pthread_mutex_unlock(&state->lock);
        return -2; /* Not authorized: assigned to a different agent */
    }

    if (!is_valid_status_transition(cmp->status, new_status)) {
        pthread_mutex_unlock(&state->lock);
        return -3; /* Invalid status transition */
    }

    const char *prev_st_str = status_to_string(cmp->status);
    const char *new_st_str = status_to_string(new_status);

    cmp->status = new_status;
    cmp->updated_at = chs_get_time(state);

    char agent_user[MAX_USERNAME_LEN];
    snprintf(agent_user, sizeof(agent_user), "agent%u", agent_id);

    chs_history_append(state, complaint_id, "STATUS_CHANGE", prev_st_str, new_st_str, agent_user, "Agent updated status");
    chs_storage_save_complaints(state);

    pthread_mutex_unlock(&state->lock);
    return 0;
}

int chs_agent_add_note(AppState *state, unsigned int agent_id, unsigned int complaint_id, const char *note) {
    if (!state || !note || strlen(note) == 0) return -1;

    pthread_mutex_lock(&state->lock);

    Complaint *cmp = state->complaints;
    while (cmp && cmp->id != complaint_id) {
        cmp = cmp->next;
    }

    if (!cmp) {
        pthread_mutex_unlock(&state->lock);
        return -1;
    }

    if (cmp->assigned_agent_id != agent_id) {
        pthread_mutex_unlock(&state->lock);
        return -2;
    }

    cmp->updated_at = chs_get_time(state);

    char agent_user[MAX_USERNAME_LEN];
    snprintf(agent_user, sizeof(agent_user), "agent%u", agent_id);

    chs_history_append(state, complaint_id, "NOTE_ADDED", "-", "-", agent_user, note);
    chs_storage_save_complaints(state);

    pthread_mutex_unlock(&state->lock);
    return 0;
}

int chs_agent_change_priority(AppState *state, unsigned int agent_id, unsigned int complaint_id, ComplaintPriority new_priority) {
    if (!state) return -1;

    pthread_mutex_lock(&state->lock);

    Complaint *cmp = state->complaints;
    while (cmp && cmp->id != complaint_id) {
        cmp = cmp->next;
    }

    if (!cmp) {
        pthread_mutex_unlock(&state->lock);
        return -1;
    }

    if (cmp->assigned_agent_id != agent_id) {
        pthread_mutex_unlock(&state->lock);
        return -2;
    }

    const char *prev_pr = priority_to_string(cmp->priority);
    const char *new_pr = priority_to_string(new_priority);

    cmp->priority = new_priority;
    cmp->updated_at = chs_get_time(state);

    char agent_user[MAX_USERNAME_LEN];
    snprintf(agent_user, sizeof(agent_user), "agent%u", agent_id);

    chs_history_append(state, complaint_id, "PRIORITY_CHANGE", prev_pr, new_pr, agent_user, "Agent changed priority");

    /* Critical complaints escalate automatically */
    if (new_priority == PRIORITY_CRITICAL && !cmp->is_escalated) {
        cmp->is_escalated = true;
        cmp->escalated_at = chs_get_time(state);
        cmp->status = STATUS_ESCALATED;
        snprintf(cmp->escalation_reason, sizeof(cmp->escalation_reason), "Priority set to CRITICAL");
        chs_history_append(state, complaint_id, "ESCALATED", prev_pr, "CRITICAL", "SYSTEM", "Automatic escalation on CRITICAL priority");
    }

    chs_storage_save_complaints(state);
    pthread_mutex_unlock(&state->lock);
    return 0;
}

int chs_agent_resolve(AppState *state, unsigned int agent_id, unsigned int complaint_id, const char *resolution_details) {
    if (!state || !resolution_details || strlen(resolution_details) == 0) {
        return -1;
    }

    pthread_mutex_lock(&state->lock);

    Complaint *cmp = state->complaints;
    while (cmp && cmp->id != complaint_id) {
        cmp = cmp->next;
    }

    if (!cmp) {
        pthread_mutex_unlock(&state->lock);
        return -1;
    }

    if (cmp->assigned_agent_id != agent_id) {
        pthread_mutex_unlock(&state->lock);
        return -2;
    }

    if (!is_valid_status_transition(cmp->status, STATUS_RESOLVED)) {
        pthread_mutex_unlock(&state->lock);
        return -3;
    }

    time_t now = chs_get_time(state);
    cmp->status = STATUS_RESOLVED;
    cmp->resolved_at = now;
    cmp->updated_at = now;
    snprintf(cmp->resolution_details, sizeof(cmp->resolution_details), "%s", resolution_details);
    chs_sanitize_string(cmp->resolution_details, sizeof(cmp->resolution_details));

    char agent_user[MAX_USERNAME_LEN];
    snprintf(agent_user, sizeof(agent_user), "agent%u", agent_id);

    chs_history_append(state, complaint_id, "RESOLVED", "-", "RESOLVED", agent_user, cmp->resolution_details);
    chs_storage_save_complaints(state);

    pthread_mutex_unlock(&state->lock);
    return 0;
}
