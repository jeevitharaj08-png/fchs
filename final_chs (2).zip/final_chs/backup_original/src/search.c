#include "chs_search.h"

int chs_search_complaints(AppState *state,
                          int customer_id,
                          int agent_id,
                          int status,
                          int priority,
                          Complaint ***results_out,
                          size_t *count_out) {
    if (!state || !results_out || !count_out) return -1;
    *results_out = NULL;
    *count_out = 0;

    pthread_mutex_lock(&state->lock);

    size_t count = 0;
    Complaint *cmp = state->complaints;
    while (cmp) {
        bool match = true;
        if (customer_id >= 0 && (int)cmp->customer_id != customer_id) match = false;
        if (agent_id >= 0 && (int)cmp->assigned_agent_id != agent_id) match = false;
        if (status >= 0 && (int)cmp->status != status) match = false;
        if (priority >= 0 && (int)cmp->priority != priority) match = false;

        if (match) {
            count++;
        }
        cmp = cmp->next;
    }

    if (count == 0) {
        pthread_mutex_unlock(&state->lock);
        return 0;
    }

    Complaint **arr = (Complaint **)calloc(count, sizeof(Complaint *));
    if (!arr) {
        pthread_mutex_unlock(&state->lock);
        return -1;
    }

    size_t idx = 0;
    cmp = state->complaints;
    while (cmp && idx < count) {
        bool match = true;
        if (customer_id >= 0 && (int)cmp->customer_id != customer_id) match = false;
        if (agent_id >= 0 && (int)cmp->assigned_agent_id != agent_id) match = false;
        if (status >= 0 && (int)cmp->status != status) match = false;
        if (priority >= 0 && (int)cmp->priority != priority) match = false;

        if (match) {
            arr[idx++] = cmp;
        }
        cmp = cmp->next;
    }

    pthread_mutex_unlock(&state->lock);

    *results_out = arr;
    *count_out = count;
    return 0;
}
