#include "chs.h"

const char* status_to_string(ComplaintStatus st) {
    switch (st) {
        case STATUS_OPEN:        return "OPEN";
        case STATUS_ASSIGNED:    return "ASSIGNED";
        case STATUS_IN_PROGRESS: return "IN_PROGRESS";
        case STATUS_ESCALATED:   return "ESCALATED";
        case STATUS_RESOLVED:    return "RESOLVED";
        case STATUS_CLOSED:      return "CLOSED";
        default:                 return "UNKNOWN";
    }
}

ComplaintStatus string_to_status(const char *str) {
    if (!str) return STATUS_OPEN;
    if (strcmp(str, "OPEN") == 0) return STATUS_OPEN;
    if (strcmp(str, "ASSIGNED") == 0) return STATUS_ASSIGNED;
    if (strcmp(str, "IN_PROGRESS") == 0) return STATUS_IN_PROGRESS;
    if (strcmp(str, "ESCALATED") == 0) return STATUS_ESCALATED;
    if (strcmp(str, "RESOLVED") == 0) return STATUS_RESOLVED;
    if (strcmp(str, "CLOSED") == 0) return STATUS_CLOSED;
    return STATUS_OPEN;
}

const char* priority_to_string(ComplaintPriority pr) {
    switch (pr) {
        case PRIORITY_LOW:      return "LOW";
        case PRIORITY_MEDIUM:   return "MEDIUM";
        case PRIORITY_HIGH:     return "HIGH";
        case PRIORITY_CRITICAL: return "CRITICAL";
        default:                return "UNKNOWN";
    }
}

ComplaintPriority string_to_priority(const char *str) {
    if (!str) return PRIORITY_LOW;
    if (strcmp(str, "LOW") == 0) return PRIORITY_LOW;
    if (strcmp(str, "MEDIUM") == 0) return PRIORITY_MEDIUM;
    if (strcmp(str, "HIGH") == 0) return PRIORITY_HIGH;
    if (strcmp(str, "CRITICAL") == 0) return PRIORITY_CRITICAL;
    return PRIORITY_LOW;
}

bool is_valid_status_transition(ComplaintStatus current, ComplaintStatus next) {
    if (current == next) return true;
    switch (current) {
        case STATUS_OPEN:
            return (next == STATUS_ASSIGNED || next == STATUS_ESCALATED);
        case STATUS_ASSIGNED:
            return (next == STATUS_IN_PROGRESS || next == STATUS_ESCALATED || next == STATUS_RESOLVED);
        case STATUS_IN_PROGRESS:
            return (next == STATUS_ESCALATED || next == STATUS_RESOLVED);
        case STATUS_ESCALATED:
            return (next == STATUS_IN_PROGRESS || next == STATUS_RESOLVED);
        case STATUS_RESOLVED:
            return (next == STATUS_CLOSED);
        case STATUS_CLOSED:
            return false; /* Closed complaints cannot transition */
        default:
            return false;
    }
}

int chs_init(AppState *state, const char *data_dir) {
    if (!state) return -1;
    memset(state, 0, sizeof(AppState));

    pthread_mutex_init(&state->lock, NULL);
    pthread_cond_init(&state->cond, NULL);

    state->next_complaint_id = 1001;
    state->next_customer_id = 1;
    state->next_agent_id = 1;
    state->next_history_seq = 1;
    state->monitor_interval_sec = 2; /* Default 2 sec check */

    const char *dir = (data_dir && strlen(data_dir) > 0) ? data_dir : "data";
    snprintf(state->data_dir, sizeof(state->data_dir), "%s", dir);

    chs_storage_init(state, state->data_dir);
    chs_manager_init_default(state);
    chs_agent_init_defaults(state);

    /* Load existing persistent records if any */
    chs_storage_load_all(state);

    return 0;
}

void chs_cleanup(AppState *state) {
    if (!state) return;

    /* Stop background monitor thread cleanly */
    chs_escalation_stop_monitor(state);

    /* Persist all data before releasing memory */
    chs_storage_save_all(state);

    pthread_mutex_lock(&state->lock);

    /* Free customers */
    Customer *c_curr = state->customers;
    while (c_curr) {
        Customer *next = c_curr->next;
        free(c_curr);
        c_curr = next;
    }
    state->customers = NULL;

    /* Free agents */
    Agent *a_curr = state->agents;
    while (a_curr) {
        Agent *next = a_curr->next;
        free(a_curr);
        a_curr = next;
    }
    state->agents = NULL;

    /* Free complaints */
    Complaint *cmp_curr = state->complaints;
    while (cmp_curr) {
        Complaint *next = cmp_curr->next;
        free(cmp_curr);
        cmp_curr = next;
    }
    state->complaints = NULL;

    /* Free history */
    HistoryEvent *h_curr = state->history;
    while (h_curr) {
        HistoryEvent *next = h_curr->next;
        free(h_curr);
        h_curr = next;
    }
    state->history = NULL;

    pthread_mutex_unlock(&state->lock);

    pthread_mutex_destroy(&state->lock);
    pthread_cond_destroy(&state->cond);
}
