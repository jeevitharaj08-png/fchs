#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include "chs_time.h"
#include <ctype.h>

#if defined(__linux__) || defined(__GLIBC__) || defined(__gnu_linux__)
extern time_t timegm(struct tm *tm);
#endif

static time_t g_mock_time = 0;
static bool g_use_mock_time = false;

time_t chs_get_time(AppState *state) {
    if (state && state->get_time_fn) {
        return state->get_time_fn();
    }
    if (g_use_mock_time) {
        return g_mock_time;
    }
    struct timespec ts;
    if (clock_gettime(CLOCK_REALTIME, &ts) == 0) {
        return ts.tv_sec;
    }
    return time(NULL);
}

void chs_set_mock_time(time_t t) {
    g_mock_time = t;
    g_use_mock_time = true;
}

void chs_advance_mock_time(time_t seconds) {
    if (!g_use_mock_time) {
        g_mock_time = time(NULL);
        g_use_mock_time = true;
    }
    g_mock_time += seconds;
}

void chs_reset_mock_time(void) {
    g_use_mock_time = false;
    g_mock_time = 0;
}

void chs_format_iso(time_t t, char *buffer, size_t buf_len) {
    if (!buffer || buf_len == 0) return;
    if (t == 0) {
        snprintf(buffer, buf_len, "N/A");
        return;
    }
    struct tm tm_info;
    if (gmtime_r(&t, &tm_info) == NULL) {
        snprintf(buffer, buf_len, "N/A");
        return;
    }
    strftime(buffer, buf_len, "%Y-%m-%dT%H:%M:%SZ", &tm_info);
}

static bool is_leap_year(int year) {
    return ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0));
}

static int days_in_month(int year, int mon) {
    static const int days_per_mon[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (mon < 1 || mon > 12) return 0;
    if (mon == 2 && is_leap_year(year)) return 29;
    return days_per_mon[mon - 1];
}

time_t chs_parse_iso(const char *buffer) {
    if (!buffer || strlen(buffer) == 0 || strcmp(buffer, "N/A") == 0) {
        return 0;
    }

    /* 1. If the buffer is a numeric epoch timestamp */
    char *endptr = NULL;
    long long epoch_val = strtoll(buffer, &endptr, 10);
    if (endptr && *endptr == '\0') {
        if (epoch_val <= 0 || epoch_val > 4102444800LL) {
            return 0; /* Invalid epoch range */
        }
        return (time_t)epoch_val;
    }

    /* 2. Parse ISO 8601 string: YYYY-MM-DDTHH:MM:SS with optional timezone */
    int year = 0, mon = 0, mday = 0, hour = 0, min = 0, sec = 0;
    char sep = '\0';
    int nparsed = sscanf(buffer, "%4d-%2d-%2d%c%2d:%2d:%2d",
                         &year, &mon, &mday, &sep, &hour, &min, &sec);
    if (nparsed < 7 || (sep != 'T' && sep != ' ' && sep != 't')) {
        return 0; /* Malformed format */
    }

    /* Range validation */
    if (year < 1970 || year > 2099) return 0;
    if (mon < 1 || mon > 12) return 0;
    int max_day = days_in_month(year, mon);
    if (mday < 1 || mday > max_day) return 0; /* Leap year / month boundary violation */
    if (hour < 0 || hour > 23) return 0;
    if (min < 0 || min > 59) return 0;
    if (sec < 0 || sec > 60) return 0; /* 60 allows leap seconds */

    struct tm tm_info;
    memset(&tm_info, 0, sizeof(struct tm));
    tm_info.tm_year = year - 1900;
    tm_info.tm_mon = mon - 1;
    tm_info.tm_mday = mday;
    tm_info.tm_hour = hour;
    tm_info.tm_min = min;
    tm_info.tm_sec = sec;
    tm_info.tm_isdst = 0;

    time_t utc_sec = 0;
#if defined(_WIN32)
    utc_sec = _mkgmtime(&tm_info);
#else
    utc_sec = timegm(&tm_info);
#endif

    if (utc_sec == (time_t)-1) {
        return 0; /* Conversion error */
    }

    /* Check for timezone offset: e.g. +05:30, -04:00, or Z */
    const char *tz_part = buffer + 19;
    while (*tz_part == ' ') tz_part++;

    if (*tz_part == '+' || *tz_part == '-') {
        char sign = *tz_part;
        int tz_h = 0, tz_m = 0;
        if (sscanf(tz_part + 1, "%2d:%2d", &tz_h, &tz_m) >= 1) {
            long offset = (tz_h * 3600) + (tz_m * 60);
            if (sign == '+') {
                utc_sec -= offset;
            } else {
                utc_sec += offset;
            }
        }
    }

    return utc_sec;
}

double chs_difftime(time_t end, time_t start) {
    return difftime(end, start);
}
