#include "chs_assignment.h"
#include "chs_agent.h"
#include "chs_time.h"
#include "chs_history.h"
#include "chs_storage.h"

int chs_assignment_auto_assign(AppState *state, Complaint *complaint) {
    if (!state || !complaint) return -1;

    unsigned int best_agent_id = 0;
    int min_workload = 999999;

    Agent *a = state->agents;
    while (a) {
        if (a->is_active) {
            int wl = chs_agent_calculate_workload(state, a->id);
            /* Deterministic tie-breaker: if workload is strictly less, or equal with smaller ID */
            if (wl < min_workload || (wl == min_workload && (best_agent_id == 0 || a->id < best_agent_id))) {
                min_workload = wl;
                best_agent_id = a->id;
            }
        }
        a = a->next;
    }

    time_t now = chs_get_time(state);
    if (best_agent_id > 0) {
        complaint->assigned_agent_id = best_agent_id;
        complaint->status = STATUS_ASSIGNED;
        complaint->assigned_at = now;
        complaint->updated_at = now;

        char new_val[64];
        snprintf(new_val, sizeof(new_val), "Agent %u", best_agent_id);
        chs_history_append(state, complaint->id, "ASSIGNED", "None", new_val, "SYSTEM", "Auto-assigned by lowest workload");
    } else {
        complaint->assigned_agent_id = 0;
        complaint->status = STATUS_OPEN;
        chs_history_append(state, complaint->id, "UNASSIGNED", "None", "None", "SYSTEM", "No active agents available");
    }

    chs_storage_save_complaints(state);
    return (int)best_agent_id;
}
