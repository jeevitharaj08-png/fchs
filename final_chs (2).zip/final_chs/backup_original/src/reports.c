#include "chs_reports.h"
#include "chs_time.h"
#include "chs_customer.h"
#include "chs_agent.h"

void chs_report_complaint_summary(AppState *state, FILE *out) {
    if (!state || !out) return;
    pthread_mutex_lock(&state->lock);

    int total = 0, open = 0, assigned = 0, in_progress = 0;
    int escalated = 0, resolved = 0, closed = 0, unresolved = 0, overdue = 0;
    unsigned int oldest_unres_id = 0;
    time_t oldest_unres_time = 0;
    time_t now = chs_get_time(state);

    Complaint *cmp = state->complaints;
    while (cmp) {
        total++;
        switch (cmp->status) {
            case STATUS_OPEN:        open++; break;
            case STATUS_ASSIGNED:    assigned++; break;
            case STATUS_IN_PROGRESS: in_progress++; break;
            case STATUS_ESCALATED:   escalated++; break;
            case STATUS_RESOLVED:    resolved++; break;
            case STATUS_CLOSED:      closed++; break;
        }

        if (cmp->status != STATUS_RESOLVED && cmp->status != STATUS_CLOSED) {
            unresolved++;
            double age = chs_difftime(now, cmp->created_at);
            if (age >= ESCALATION_TIMEOUT_SEC) {
                overdue++;
            }
            if (oldest_unres_time == 0 || cmp->created_at < oldest_unres_time) {
                oldest_unres_time = cmp->created_at;
                oldest_unres_id = cmp->id;
            }
        }
        cmp = cmp->next;
    }

    fprintf(out, "\n=======================================================\n");
    fprintf(out, "               COMPLAINT SUMMARY REPORT                \n");
    fprintf(out, "=======================================================\n");
    fprintf(out, " Total Complaints:         %d\n", total);
    fprintf(out, "   - Open:                 %d\n", open);
    fprintf(out, "   - Assigned:             %d\n", assigned);
    fprintf(out, "   - In Progress:          %d\n", in_progress);
    fprintf(out, "   - Escalated:            %d\n", escalated);
    fprintf(out, "   - Resolved:             %d\n", resolved);
    fprintf(out, "   - Closed:               %d\n", closed);
    fprintf(out, " Total Unresolved:         %d\n", unresolved);
    fprintf(out, " Overdue (>= 24 Hours):    %d\n", overdue);
    if (oldest_unres_id > 0) {
        char ts[64];
        chs_format_iso(oldest_unres_time, ts, sizeof(ts));
        fprintf(out, " Oldest Unresolved ID:     #%u (Created: %s, Age: %.0fs)\n",
                oldest_unres_id, ts, chs_difftime(now, oldest_unres_time));
    } else {
        fprintf(out, " Oldest Unresolved:        None\n");
    }
    fprintf(out, "=======================================================\n\n");

    pthread_mutex_unlock(&state->lock);
}

void chs_report_priority(AppState *state, FILE *out) {
    if (!state || !out) return;
    pthread_mutex_lock(&state->lock);

    int low = 0, med = 0, high = 0, crit = 0;
    int unres_low = 0, unres_med = 0, unres_high = 0, unres_crit = 0;

    Complaint *cmp = state->complaints;
    while (cmp) {
        bool unres = (cmp->status != STATUS_RESOLVED && cmp->status != STATUS_CLOSED);
        switch (cmp->priority) {
            case PRIORITY_LOW:
                low++;
                if (unres) unres_low++;
                break;
            case PRIORITY_MEDIUM:
                med++;
                if (unres) unres_med++;
                break;
            case PRIORITY_HIGH:
                high++;
                if (unres) unres_high++;
                break;
            case PRIORITY_CRITICAL:
                crit++;
                if (unres) unres_crit++;
                break;
        }
        cmp = cmp->next;
    }

    fprintf(out, "\n=======================================================\n");
    fprintf(out, "                    PRIORITY REPORT                    \n");
    fprintf(out, "=======================================================\n");
    fprintf(out, " LOW:      Total: %4d | Unresolved: %4d\n", low, unres_low);
    fprintf(out, " MEDIUM:   Total: %4d | Unresolved: %4d\n", med, unres_med);
    fprintf(out, " HIGH:     Total: %4d | Unresolved: %4d\n", high, unres_high);
    fprintf(out, " CRITICAL: Total: %4d | Unresolved: %4d\n", crit, unres_crit);
    fprintf(out, "=======================================================\n\n");

    pthread_mutex_unlock(&state->lock);
}

void chs_report_agent_workload(AppState *state, FILE *out) {
    if (!state || !out) return;
    pthread_mutex_lock(&state->lock);

    fprintf(out, "\n========================================================================================\n");
    fprintf(out, "                                 AGENT WORKLOAD REPORT                                  \n");
    fprintf(out, "========================================================================================\n");
    fprintf(out, "%-8s %-16s %-10s %-8s %-10s %-8s %-20s\n",
            "AgentID", "Name", "Status", "Active", "Resolved", "Closed", "Oldest Active Assigned");
    fprintf(out, "----------------------------------------------------------------------------------------\n");

    Agent *a = state->agents;
    while (a) {
        int active_cnt = 0, res_cnt = 0, closed_cnt = 0;
        time_t oldest_assigned = 0;

        Complaint *cmp = state->complaints;
        while (cmp) {
            if (cmp->assigned_agent_id == a->id) {
                if (cmp->status == STATUS_RESOLVED) {
                    res_cnt++;
                } else if (cmp->status == STATUS_CLOSED) {
                    closed_cnt++;
                } else {
                    active_cnt++;
                    if (oldest_assigned == 0 || (cmp->assigned_at > 0 && cmp->assigned_at < oldest_assigned)) {
                        oldest_assigned = cmp->assigned_at;
                    }
                }
            }
            cmp = cmp->next;
        }

        char old_ts[64];
        if (oldest_assigned > 0) {
            chs_format_iso(oldest_assigned, old_ts, sizeof(old_ts));
        } else {
            snprintf(old_ts, sizeof(old_ts), "N/A");
        }

        fprintf(out, "%-8u %-16s %-10s %-8d %-10d %-8d %-20s\n",
                a->id, a->full_name, a->is_active ? "Active" : "Inactive",
                active_cnt, res_cnt, closed_cnt, old_ts);
        a = a->next;
    }
    fprintf(out, "========================================================================================\n\n");

    pthread_mutex_unlock(&state->lock);
}

void chs_report_escalations(AppState *state, FILE *out) {
    if (!state || !out) return;
    pthread_mutex_lock(&state->lock);

    fprintf(out, "\n====================================================================================================\n");
    fprintf(out, "                                     ESCALATION AUDIT REPORT                                       \n");
    fprintf(out, "====================================================================================================\n");
    fprintf(out, "%-6s %-8s %-10s %-8s %-20s %-20s %-12s %-20s\n",
            "ID", "CustID", "Priority", "Agent", "Created At", "Escalated At", "Status", "Reason");
    fprintf(out, "----------------------------------------------------------------------------------------------------\n");

    int esc_count = 0;
    Complaint *cmp = state->complaints;
    while (cmp) {
        if (cmp->is_escalated) {
            esc_count++;
            char c_ts[64], e_ts[64];
            chs_format_iso(cmp->created_at, c_ts, sizeof(c_ts));
            chs_format_iso(cmp->escalated_at, e_ts, sizeof(e_ts));

            char ack_status[32];
            if (cmp->is_acknowledged) {
                snprintf(ack_status, sizeof(ack_status), "Acked");
            } else {
                snprintf(ack_status, sizeof(ack_status), "Pending");
            }

            fprintf(out, "#%-5u %-8u %-10s %-8u %-20s %-20s %-12s %-20s\n",
                    cmp->id, cmp->customer_id, priority_to_string(cmp->priority),
                    cmp->assigned_agent_id, c_ts, e_ts, ack_status, cmp->escalation_reason);
        }
        cmp = cmp->next;
    }
    if (esc_count == 0) {
        fprintf(out, " No escalated complaints found.\n");
    }
    fprintf(out, "====================================================================================================\n\n");

    pthread_mutex_unlock(&state->lock);
}

void chs_report_customer_summary(AppState *state, FILE *out) {
    if (!state || !out) return;
    pthread_mutex_lock(&state->lock);

    fprintf(out, "\n========================================================================\n");
    fprintf(out, "                        CUSTOMER SUMMARY REPORT                         \n");
    fprintf(out, "========================================================================\n");
    fprintf(out, "%-8s %-16s %-10s %-12s %-12s\n",
            "CustID", "Username", "Total", "Unresolved", "Resolved/Closed");
    fprintf(out, "------------------------------------------------------------------------\n");

    Customer *c = state->customers;
    while (c) {
        int total = 0, unres = 0, done = 0;
        Complaint *cmp = state->complaints;
        while (cmp) {
            if (cmp->customer_id == c->id) {
                total++;
                if (cmp->status == STATUS_RESOLVED || cmp->status == STATUS_CLOSED) {
                    done++;
                } else {
                    unres++;
                }
            }
            cmp = cmp->next;
        }

        fprintf(out, "%-8u %-16s %-10d %-12d %-12d\n",
                c->id, c->username, total, unres, done);
        c = c->next;
    }
    fprintf(out, "========================================================================\n\n");

    pthread_mutex_unlock(&state->lock);
}

void chs_report_complaint_history(AppState *state, unsigned int complaint_id, FILE *out) {
    if (!state || !out) return;
    pthread_mutex_lock(&state->lock);

    fprintf(out, "\n===============================================================================================\n");
    fprintf(out, "                             HISTORY AUDIT FOR COMPLAINT #%u                                    \n", complaint_id);
    fprintf(out, "===============================================================================================\n");
    fprintf(out, "%-6s %-20s %-16s %-12s %-12s %-12s %-20s\n",
            "Seq", "Timestamp", "Event Type", "Prev Val", "New Val", "User", "Notes");
    fprintf(out, "-----------------------------------------------------------------------------------------------\n");

    int count = 0;
    HistoryEvent *h = state->history;
    while (h) {
        if (complaint_id == 0 || h->complaint_id == complaint_id) {
            count++;
            char ts[64];
            chs_format_iso(h->timestamp, ts, sizeof(ts));
            fprintf(out, "%-6u %-20s %-16s %-12s %-12s %-12s %-20s\n",
                    h->seq_num, ts, h->event_type, h->prev_value, h->new_value, h->acting_user, h->notes);
        }
        h = h->next;
    }
    if (count == 0) {
        fprintf(out, " No history events found for complaint #%u.\n", complaint_id);
    }
    fprintf(out, "===============================================================================================\n\n");

    pthread_mutex_unlock(&state->lock);
}
