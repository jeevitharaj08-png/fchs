#include "chs_security.h"
#include <ctype.h>

/* SHA-256 implementation */
typedef struct {
    uint32_t state[8];
    uint64_t count;
    uint8_t buffer[64];
} SHA256_CTX;

#define ROTR(x, n) (((x) >> (n)) | ((x) << (32 - (n))))
#define CH(x, y, z) (((x) & (y)) ^ (~(x) & (z)))
#define MAJ(x, y, z) (((x) & (y)) ^ ((x) & (z)) ^ ((y) & (z)))
#define EP0(x) (ROTR(x, 2) ^ ROTR(x, 13) ^ ROTR(x, 22))
#define EP1(x) (ROTR(x, 6) ^ ROTR(x, 11) ^ ROTR(x, 25))
#define SIG0(x) (ROTR(x, 7) ^ ROTR(x, 18) ^ ((x) >> 3))
#define SIG1(x) (ROTR(x, 17) ^ ROTR(x, 19) ^ ((x) >> 10))

static const uint32_t K256[64] = {
    0x428a2f98UL, 0x71374491UL, 0xb5c0fbcfUL, 0xe9b5dba5UL,
    0x3956c25bUL, 0x59f111f1UL, 0x923f82a4UL, 0xab1c5ed5UL,
    0xd807aa98UL, 0x12835b01UL, 0x243185beUL, 0x550c7dc3UL,
    0x72be5d74UL, 0x80deb1feUL, 0x9bdc06a7UL, 0xc19bf174UL,
    0xe49b69c1UL, 0xefbe4786UL, 0x0fc19dc6UL, 0x240ca1ccUL,
    0x2de92c6fUL, 0x4a7484aaUL, 0x5cb0a9dcUL, 0x76f988daUL,
    0x983e5152UL, 0xa831c66dUL, 0xb00327c8UL, 0xbf597fc7UL,
    0xc6e00bf3UL, 0xd5a79147UL, 0x06ca6351UL, 0x14292967UL,
    0x27b70a85UL, 0x2e1b2138UL, 0x4d2c6dfcUL, 0x53380d13UL,
    0x650a7354UL, 0x766a0abbUL, 0x81c2c92eUL, 0x92722c85UL,
    0xa2bfe8a1UL, 0xa81a664bUL, 0xc24b8b70UL, 0xc76c51a3UL,
    0xd192e819UL, 0xd6990624UL, 0xf40e3585UL, 0x106aa070UL,
    0x19a4c116UL, 0x1e376c08UL, 0x2748774cUL, 0x34b0bcb5UL,
    0x391c0cb3UL, 0x4ed8aa4aUL, 0x5b9cca4fUL, 0x682e6ff3UL,
    0x748f82eeUL, 0x78a5636fUL, 0x84c87814UL, 0x8cc70208UL,
    0x90befffaUL, 0xa4506cebUL, 0xbef9a3f7UL, 0xc67178f2UL
};

static void sha256_transform(SHA256_CTX *ctx, const uint8_t data[64]) {
    uint32_t a, b, c, d, e, f, g, h, m[64];
    for (int i = 0, j = 0; i < 16; ++i, j += 4) {
        m[i] = ((uint32_t)data[j] << 24) | ((uint32_t)data[j + 1] << 16) |
               ((uint32_t)data[j + 2] << 8) | ((uint32_t)data[j + 3]);
    }
    for (int i = 16; i < 64; ++i) {
        m[i] = SIG1(m[i - 2]) + m[i - 7] + SIG0(m[i - 15]) + m[i - 16];
    }
    a = ctx->state[0]; b = ctx->state[1]; c = ctx->state[2]; d = ctx->state[3];
    e = ctx->state[4]; f = ctx->state[5]; g = ctx->state[6]; h = ctx->state[7];

    for (int i = 0; i < 64; ++i) {
        uint32_t t1 = h + EP1(e) + CH(e, f, g) + K256[i] + m[i];
        uint32_t t2 = EP0(a) + MAJ(a, b, c);
        h = g; g = f; f = e; e = d + t1;
        d = c; c = b; b = a; a = t1 + t2;
    }
    ctx->state[0] += a; ctx->state[1] += b; ctx->state[2] += c; ctx->state[3] += d;
    ctx->state[4] += e; ctx->state[5] += f; ctx->state[6] += g; ctx->state[7] += h;
}

static void sha256_init(SHA256_CTX *ctx) {
    ctx->state[0] = 0x6a09e667UL; ctx->state[1] = 0xbb67ae85UL;
    ctx->state[2] = 0x3c6ef372UL; ctx->state[3] = 0xa54ff53aUL;
    ctx->state[4] = 0x510e527fUL; ctx->state[5] = 0x9b05688cUL;
    ctx->state[6] = 0x1f83d9abUL; ctx->state[7] = 0x5be0cd19UL;
    ctx->count = 0;
}

static void sha256_update(SHA256_CTX *ctx, const uint8_t *data, size_t len) {
    for (size_t i = 0; i < len; ++i) {
        ctx->buffer[ctx->count % 64] = data[i];
        ctx->count++;
        if ((ctx->count % 64) == 0) {
            sha256_transform(ctx, ctx->buffer);
        }
    }
}

static void sha256_final(SHA256_CTX *ctx, uint8_t hash[32]) {
    size_t i = ctx->count % 64;
    ctx->buffer[i++] = 0x80;
    if (i > 56) {
        while (i < 64) ctx->buffer[i++] = 0x00;
        sha256_transform(ctx, ctx->buffer);
        memset(ctx->buffer, 0, 56);
    } else {
        while (i < 56) ctx->buffer[i++] = 0x00;
    }
    uint64_t total_bits = ctx->count * 8;
    for (int j = 7; j >= 0; --j) {
        ctx->buffer[56 + (7 - j)] = (uint8_t)((total_bits >> (j * 8)) & 0xFF);
    }
    sha256_transform(ctx, ctx->buffer);
    for (int j = 0; j < 4; ++j) {
        for (int k = 0; k < 8; ++k) {
            hash[k * 4 + j] = (uint8_t)((ctx->state[k] >> (24 - j * 8)) & 0x000000ff);
        }
    }
}

/* HMAC-SHA256 */
static void hmac_sha256(const uint8_t *key, size_t key_len,
                        const uint8_t *data, size_t data_len,
                        uint8_t out[32]) {
    uint8_t k[64] = {0};
    if (key_len > 64) {
        SHA256_CTX ctx;
        sha256_init(&ctx);
        sha256_update(&ctx, key, key_len);
        sha256_final(&ctx, k);
    } else {
        memcpy(k, key, key_len);
    }

    uint8_t k_ipad[64], k_opad[64];
    for (int i = 0; i < 64; i++) {
        k_ipad[i] = k[i] ^ 0x36;
        k_opad[i] = k[i] ^ 0x5c;
    }

    uint8_t inner_hash[32];
    SHA256_CTX ctx;
    sha256_init(&ctx);
    sha256_update(&ctx, k_ipad, 64);
    sha256_update(&ctx, data, data_len);
    sha256_final(&ctx, inner_hash);

    sha256_init(&ctx);
    sha256_update(&ctx, k_opad, 64);
    sha256_update(&ctx, inner_hash, 32);
    sha256_final(&ctx, out);
}

/* PBKDF2-HMAC-SHA256 with 2,000 iterations */
static void pbkdf2_sha256(const char *pass, const char *salt, uint8_t out[32]) {
    size_t pass_len = strlen(pass);
    size_t salt_len = strlen(salt);
    uint8_t salt_with_counter[128];
    size_t swc_len = salt_len + 4;
    if (swc_len > sizeof(salt_with_counter)) swc_len = sizeof(salt_with_counter);
    memcpy(salt_with_counter, salt, salt_len);
    salt_with_counter[salt_len] = 0;
    salt_with_counter[salt_len + 1] = 0;
    salt_with_counter[salt_len + 2] = 0;
    salt_with_counter[salt_len + 3] = 1; /* Block 1 */

    uint8_t u[32], t[32];
    hmac_sha256((const uint8_t *)pass, pass_len, salt_with_counter, swc_len, u);
    memcpy(t, u, 32);

    for (int iter = 1; iter < 2000; iter++) {
        hmac_sha256((const uint8_t *)pass, pass_len, u, 32, u);
        for (int k = 0; k < 32; k++) {
            t[k] ^= u[k];
        }
    }
    memcpy(out, t, 32);
}

void chs_generate_salt(char *salt_out, size_t max_len) {
    if (!salt_out || max_len < 17) return;
    const char charset[] = "0123456789abcdef";
    uint8_t rand_bytes[16];

    /* Read from /dev/urandom if available */
    FILE *f = fopen("/dev/urandom", "rb");
    if (f) {
        size_t n = fread(rand_bytes, 1, 16, f);
        (void)n;
        fclose(f);
    } else {
        /* High-resolution fallback with monotonic/nanosecond mixing */
        static unsigned int g_salt_counter = 54321;
        g_salt_counter += 1013904223U;
        struct timespec ts;
        clock_gettime(CLOCK_REALTIME, &ts);
        unsigned int seed = (unsigned int)(ts.tv_nsec ^ (uint64_t)ts.tv_sec ^ g_salt_counter);
        for (int i = 0; i < 16; i++) {
            seed = seed * 1103515245U + 12345U;
            rand_bytes[i] = (uint8_t)((seed >> 16) & 0xFF);
        }
    }
    for (int i = 0; i < 16 && (size_t)(i * 2 + 1) < max_len; i++) {
        salt_out[i * 2] = charset[(rand_bytes[i] >> 4) & 0x0F];
        salt_out[i * 2 + 1] = charset[rand_bytes[i] & 0x0F];
    }
    salt_out[32 < max_len ? 32 : max_len - 1] = '\0';
}

int chs_hash_password(const char *password, const char *salt, char *hash_out, size_t max_len) {
    if (!password || !salt || !hash_out || max_len < 65) return -1;
    uint8_t digest[32];
    pbkdf2_sha256(password, salt, digest);

    const char hex[] = "0123456789abcdef";
    for (int i = 0; i < 32; i++) {
        hash_out[i * 2] = hex[(digest[i] >> 4) & 0x0F];
        hash_out[i * 2 + 1] = hex[digest[i] & 0x0F];
    }
    hash_out[64] = '\0';
    return 0;
}

int chs_constant_time_memcmp(const void *a, const void *b, size_t len) {
    const uint8_t *ua = (const uint8_t *)a;
    const uint8_t *ub = (const uint8_t *)b;
    uint8_t result = 0;
    for (size_t i = 0; i < len; i++) {
        result |= (ua[i] ^ ub[i]);
    }
    return (result != 0);
}

bool chs_verify_password(const char *password, const char *salt, const char *expected_hash) {
    if (!password || !salt || !expected_hash) return false;
    char computed[128];
    if (chs_hash_password(password, salt, computed, sizeof(computed)) != 0) {
        return false;
    }
    if (strlen(computed) != strlen(expected_hash)) return false;
    return (chs_constant_time_memcmp(computed, expected_hash, strlen(expected_hash)) == 0);
}

void chs_sanitize_string(char *str, size_t max_len) {
    if (!str) return;
    for (size_t i = 0; i < max_len && str[i] != '\0'; i++) {
        if (str[i] == '\r' || str[i] == '\n' || str[i] == '\t') {
            str[i] = ' ';
        } else if (str[i] == '|') {
            str[i] = '-'; /* Neutralize delimiter in text-file storage */
        } else if ((unsigned char)str[i] < 32 || (unsigned char)str[i] > 126) {
            str[i] = ' ';
        }
    }
    str[max_len - 1] = '\0';
}

bool chs_validate_input(const char *str, size_t min_len, size_t max_len) {
    if (!str) return false;
    size_t len = strlen(str);
    if (len < min_len || len >= max_len) return false;
    for (size_t i = 0; i < len; i++) {
        if (str[i] == '|' || str[i] == '\n' || str[i] == '\r') {
            return false;
        }
    }
    return true;
}

bool chs_validate_email(const char *email) {
    if (!email) return false;
    size_t len = strlen(email);
    if (len < 5 || len >= MAX_EMAIL_LEN) return false;
    const char *at = strchr(email, '@');
    if (!at || at == email) return false;
    const char *dot = strchr(at + 1, '.');
    if (!dot || dot == at + 1 || *(dot + 1) == '\0') return false;
    return true;
}

bool chs_validate_phone(const char *phone) {
    if (!phone) return false;
    size_t len = strlen(phone);
    if (len < 7 || len >= MAX_PHONE_LEN) return false;
    for (size_t i = 0; i < len; i++) {
        if (!isdigit((unsigned char)phone[i]) && phone[i] != '+' &&
            phone[i] != '-' && phone[i] != ' ' && phone[i] != '(' && phone[i] != ')') {
            return false;
        }
    }
    return true;
}
