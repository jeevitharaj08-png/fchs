#include "chs_history.h"
#include "chs_time.h"
#include "chs_storage.h"

int chs_history_append(AppState *state, unsigned int complaint_id,
                       const char *event_type, const char *prev_value,
                       const char *new_value, const char *acting_user,
                       const char *notes) {
    if (!state) return -1;

    HistoryEvent *ev = (HistoryEvent *)calloc(1, sizeof(HistoryEvent));
    if (!ev) return -1;

    ev->complaint_id = complaint_id;
    ev->seq_num = state->next_history_seq++;
    ev->timestamp = chs_get_time(state);
    snprintf(ev->event_type, sizeof(ev->event_type), "%s", event_type ? event_type : "EVENT");
    snprintf(ev->prev_value, sizeof(ev->prev_value), "%s", prev_value ? prev_value : "-");
    snprintf(ev->new_value, sizeof(ev->new_value), "%s", new_value ? new_value : "-");
    snprintf(ev->acting_user, sizeof(ev->acting_user), "%s", acting_user ? acting_user : "SYSTEM");
    snprintf(ev->notes, sizeof(ev->notes), "%s", notes ? notes : "");
    ev->next = NULL;

    if (!state->history) {
        state->history = ev;
    } else {
        HistoryEvent *curr = state->history;
        while (curr->next) curr = curr->next;
        curr->next = ev;
    }

    /* Save history to text file and audit log */
    chs_storage_save_history(state);

    char audit_buf[768];
    snprintf(audit_buf, sizeof(audit_buf), "CMP#%u %s: %s -> %s (%s)",
             complaint_id, ev->event_type, ev->prev_value, ev->new_value, ev->notes);
    chs_audit_log(state, ev->acting_user, ev->event_type, audit_buf);

    return 0;
}

int chs_history_get_for_complaint(AppState *state, unsigned int complaint_id,
                                  HistoryEvent ***events_out, size_t *count_out) {
    if (!state || !events_out || !count_out) return -1;
    *events_out = NULL;
    *count_out = 0;

    pthread_mutex_lock(&state->lock);

    /* Count matching events */
    size_t count = 0;
    HistoryEvent *curr = state->history;
    while (curr) {
        if (curr->complaint_id == complaint_id) {
            count++;
        }
        curr = curr->next;
    }

    if (count == 0) {
        pthread_mutex_unlock(&state->lock);
        return 0;
    }

    HistoryEvent **arr = (HistoryEvent **)calloc(count, sizeof(HistoryEvent *));
    if (!arr) {
        pthread_mutex_unlock(&state->lock);
        return -1;
    }

    size_t idx = 0;
    curr = state->history;
    while (curr && idx < count) {
        if (curr->complaint_id == complaint_id) {
            arr[idx++] = curr;
        }
        curr = curr->next;
    }

    pthread_mutex_unlock(&state->lock);

    *events_out = arr;
    *count_out = count;
    return 0;
}
