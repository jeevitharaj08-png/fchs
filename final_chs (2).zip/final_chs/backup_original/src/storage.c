#include "chs_storage.h"
#include "chs_time.h"
#include <sys/stat.h>

#if defined(_WIN32)
#include <direct.h>
#define mkdir_compat(path) _mkdir(path)
#else
#define mkdir_compat(path) mkdir(path, 0700)
#endif

int chs_storage_init(AppState *state, const char *data_dir) {
    if (!state) return -1;
    mkdir_compat(data_dir);
    return 0;
}

void chs_audit_log(AppState *state, const char *user, const char *action, const char *details) {
    if (!state) return;
    char path[1024];
    snprintf(path, sizeof(path), "%s/audit.log", state->data_dir);
    FILE *f = fopen(path, "a");
    if (!f) return;
    char ts[64];
    chs_format_iso(chs_get_time(state), ts, sizeof(ts));
    fprintf(f, "[%s] USER: %s | ACTION: %s | DETAILS: %s\n",
            ts, user ? user : "SYSTEM", action ? action : "UNKNOWN", details ? details : "");
    fclose(f);
}

int chs_storage_save_manager(AppState *state) {
    if (!state) return -1;
    char path[1024], tmp_path[1024];
    snprintf(path, sizeof(path), "%s/manager.txt", state->data_dir);
    snprintf(tmp_path, sizeof(tmp_path), "%s/manager.txt.tmp", state->data_dir);

    FILE *f = fopen(tmp_path, "w");
    if (!f) return -1;
    fprintf(f, "%s|%s|%s\n",
            state->manager_username,
            state->manager_password_hash,
            state->manager_salt);
    fclose(f);
    remove(path);
    rename(tmp_path, path);
    return 0;
}

int chs_storage_save_customers(AppState *state) {
    if (!state) return -1;
    char path[1024], tmp_path[1024];
    snprintf(path, sizeof(path), "%s/customers.txt", state->data_dir);
    snprintf(tmp_path, sizeof(tmp_path), "%s/customers.txt.tmp", state->data_dir);

    FILE *f = fopen(tmp_path, "w");
    if (!f) return -1;

    Customer *c = state->customers;
    while (c) {
        fprintf(f, "%u|%s|%s|%s|%s|%s|%s|%lld\n",
                c->id, c->username, c->password_hash, c->salt,
                c->full_name, c->email, c->phone, (long long)c->created_at);
        c = c->next;
    }
    fclose(f);
    remove(path);
    rename(tmp_path, path);
    return 0;
}

int chs_storage_save_agents(AppState *state) {
    if (!state) return -1;
    char path[1024], tmp_path[1024];
    snprintf(path, sizeof(path), "%s/agents.txt", state->data_dir);
    snprintf(tmp_path, sizeof(tmp_path), "%s/agents.txt.tmp", state->data_dir);

    FILE *f = fopen(tmp_path, "w");
    if (!f) return -1;

    Agent *a = state->agents;
    while (a) {
        fprintf(f, "%u|%s|%s|%s|%s|%d|%lld|%lld\n",
                a->id, a->username, a->password_hash, a->salt,
                a->full_name, a->is_active ? 1 : 0,
                (long long)a->created_at, (long long)a->deactivated_at);
        a = a->next;
    }
    fclose(f);
    remove(path);
    rename(tmp_path, path);
    return 0;
}

int chs_storage_save_complaints(AppState *state) {
    if (!state) return -1;
    char path[1024], tmp_path[1024];
    snprintf(path, sizeof(path), "%s/complaints.txt", state->data_dir);
    snprintf(tmp_path, sizeof(tmp_path), "%s/complaints.txt.tmp", state->data_dir);

    FILE *f = fopen(tmp_path, "w");
    if (!f) return -1;

    Complaint *cmp = state->complaints;
    while (cmp) {
        fprintf(f, "%u|%u|%s|%s|%s|%s|%u|%lld|%lld|%lld|%d|%lld|%s|%d|%lld|%s|%s|%lld|%lld\n",
                cmp->id, cmp->customer_id, cmp->category, cmp->description,
                priority_to_string(cmp->priority), status_to_string(cmp->status),
                cmp->assigned_agent_id,
                (long long)cmp->created_at, (long long)cmp->updated_at, (long long)cmp->assigned_at,
                cmp->is_escalated ? 1 : 0, (long long)cmp->escalated_at, cmp->escalation_reason,
                cmp->is_acknowledged ? 1 : 0, (long long)cmp->acknowledged_at,
                cmp->manager_notes, cmp->resolution_details,
                (long long)cmp->resolved_at, (long long)cmp->closed_at);
        cmp = cmp->next;
    }
    fclose(f);
    remove(path);
    rename(tmp_path, path);
    return 0;
}

int chs_storage_save_history(AppState *state) {
    if (!state) return -1;
    char path[1024], tmp_path[1024];
    snprintf(path, sizeof(path), "%s/history.txt", state->data_dir);
    snprintf(tmp_path, sizeof(tmp_path), "%s/history.txt.tmp", state->data_dir);

    FILE *f = fopen(tmp_path, "w");
    if (!f) return -1;

    HistoryEvent *h = state->history;
    while (h) {
        fprintf(f, "%u|%u|%lld|%s|%s|%s|%s|%s\n",
                h->complaint_id, h->seq_num, (long long)h->timestamp,
                h->event_type, h->prev_value, h->new_value,
                h->acting_user, h->notes);
        h = h->next;
    }
    fclose(f);
    remove(path);
    rename(tmp_path, path);
    return 0;
}

int chs_storage_save_all(AppState *state) {
    if (!state) return -1;
    pthread_mutex_lock(&state->lock);
    chs_storage_save_manager(state);
    chs_storage_save_customers(state);
    chs_storage_save_agents(state);
    chs_storage_save_complaints(state);
    chs_storage_save_history(state);
    pthread_mutex_unlock(&state->lock);
    return 0;
}

int chs_storage_load_all(AppState *state) {
    if (!state) return -1;
    char path[1024];
    char line[1024];

    pthread_mutex_lock(&state->lock);

    /* 1. Load Manager */
    snprintf(path, sizeof(path), "%s/manager.txt", state->data_dir);
    FILE *fm = fopen(path, "r");
    if (fm) {
        if (fgets(line, sizeof(line), fm)) {
            char u[MAX_USERNAME_LEN] = {0}, h[MAX_HASH_LEN] = {0}, s[MAX_SALT_LEN] = {0};
            if (sscanf(line, "%31[^|]|%127[^|]|%63[^\n]", u, h, s) == 3) {
                snprintf(state->manager_username, sizeof(state->manager_username), "%s", u);
                snprintf(state->manager_password_hash, sizeof(state->manager_password_hash), "%s", h);
                snprintf(state->manager_salt, sizeof(state->manager_salt), "%s", s);
            }
        }
        fclose(fm);
    }

    /* 2. Load Customers */
    snprintf(path, sizeof(path), "%s/customers.txt", state->data_dir);
    FILE *fc = fopen(path, "r");
    if (fc) {
        while (fgets(line, sizeof(line), fc)) {
            unsigned int id = 0;
            char u[MAX_USERNAME_LEN] = {0}, h[MAX_HASH_LEN] = {0}, s[MAX_SALT_LEN] = {0};
            char fn[MAX_NAME_LEN] = {0}, em[MAX_EMAIL_LEN] = {0}, ph[MAX_PHONE_LEN] = {0};
            long long ca = 0;
            if (sscanf(line, "%u|%31[^|]|%127[^|]|%63[^|]|%63[^|]|%63[^|]|%23[^|]|%lld",
                       &id, u, h, s, fn, em, ph, &ca) >= 7) {
                /* Append customer to list */
                Customer *nc = (Customer *)calloc(1, sizeof(Customer));
                if (nc) {
                    nc->id = id;
                    snprintf(nc->username, sizeof(nc->username), "%s", u);
                    snprintf(nc->password_hash, sizeof(nc->password_hash), "%s", h);
                    snprintf(nc->salt, sizeof(nc->salt), "%s", s);
                    snprintf(nc->full_name, sizeof(nc->full_name), "%s", fn);
                    snprintf(nc->email, sizeof(nc->email), "%s", em);
                    snprintf(nc->phone, sizeof(nc->phone), "%s", ph);
                    nc->created_at = (time_t)ca;
                    nc->next = NULL;

                    if (!state->customers) {
                        state->customers = nc;
                    } else {
                        Customer *curr = state->customers;
                        while (curr->next) curr = curr->next;
                        curr->next = nc;
                    }
                    if (id >= state->next_customer_id) {
                        state->next_customer_id = id + 1;
                    }
                }
            }
        }
        fclose(fc);
    }

    /* 3. Load Agents */
    snprintf(path, sizeof(path), "%s/agents.txt", state->data_dir);
    FILE *fa = fopen(path, "r");
    if (fa) {
        /* Free existing default agents if file exists */
        Agent *curra = state->agents;
        while (curra) {
            Agent *nxt = curra->next;
            free(curra);
            curra = nxt;
        }
        state->agents = NULL;

        while (fgets(line, sizeof(line), fa)) {
            unsigned int id = 0;
            char u[MAX_USERNAME_LEN] = {0}, h[MAX_HASH_LEN] = {0}, s[MAX_SALT_LEN] = {0}, fn[MAX_NAME_LEN] = {0};
            int active = 1;
            long long ca = 0, da = 0;
            if (sscanf(line, "%u|%31[^|]|%127[^|]|%63[^|]|%63[^|]|%d|%lld|%lld",
                       &id, u, h, s, fn, &active, &ca, &da) >= 6) {
                Agent *na = (Agent *)calloc(1, sizeof(Agent));
                if (na) {
                    na->id = id;
                    snprintf(na->username, sizeof(na->username), "%s", u);
                    snprintf(na->password_hash, sizeof(na->password_hash), "%s", h);
                    snprintf(na->salt, sizeof(na->salt), "%s", s);
                    snprintf(na->full_name, sizeof(na->full_name), "%s", fn);
                    na->is_active = (active != 0);
                    na->created_at = (time_t)ca;
                    na->deactivated_at = (time_t)da;
                    na->next = NULL;

                    if (!state->agents) {
                        state->agents = na;
                    } else {
                        Agent *tail = state->agents;
                        while (tail->next) tail = tail->next;
                        tail->next = na;
                    }
                    if (id >= state->next_agent_id) {
                        state->next_agent_id = id + 1;
                    }
                }
            }
        }
        fclose(fa);
    }

    /* 4. Load Complaints */
    snprintf(path, sizeof(path), "%s/complaints.txt", state->data_dir);
    FILE *fcmp = fopen(path, "r");
    if (fcmp) {
        while (fgets(line, sizeof(line), fcmp)) {
            Complaint *nc = (Complaint *)calloc(1, sizeof(Complaint));
            if (!nc) continue;
            char pr_str[32] = {0}, st_str[32] = {0};
            int is_esc = 0, is_ack = 0;
            long long ca = 0, ua = 0, aa = 0, ea = 0, acka = 0, ra = 0, cla = 0;

            /* Parse tokens safely */
            char *tok = strtok(line, "|\n");
            int field = 0;
            while (tok) {
                switch (field) {
                    case 0: nc->id = (unsigned int)atoi(tok); break;
                    case 1: nc->customer_id = (unsigned int)atoi(tok); break;
                    case 2: snprintf(nc->category, sizeof(nc->category), "%s", tok); break;
                    case 3: snprintf(nc->description, sizeof(nc->description), "%s", tok); break;
                    case 4: snprintf(pr_str, sizeof(pr_str), "%s", tok); break;
                    case 5: snprintf(st_str, sizeof(st_str), "%s", tok); break;
                    case 6: nc->assigned_agent_id = (unsigned int)atoi(tok); break;
                    case 7: ca = atoll(tok); break;
                    case 8: ua = atoll(tok); break;
                    case 9: aa = atoll(tok); break;
                    case 10: is_esc = atoi(tok); break;
                    case 11: ea = atoll(tok); break;
                    case 12: snprintf(nc->escalation_reason, sizeof(nc->escalation_reason), "%s", tok); break;
                    case 13: is_ack = atoi(tok); break;
                    case 14: acka = atoll(tok); break;
                    case 15: snprintf(nc->manager_notes, sizeof(nc->manager_notes), "%s", tok); break;
                    case 16: snprintf(nc->resolution_details, sizeof(nc->resolution_details), "%s", tok); break;
                    case 17: ra = atoll(tok); break;
                    case 18: cla = atoll(tok); break;
                }
                field++;
                tok = strtok(NULL, "|\n");
            }

            if (field >= 7) {
                nc->priority = string_to_priority(pr_str);
                nc->status = string_to_status(st_str);
                nc->created_at = (time_t)ca;
                nc->updated_at = (time_t)ua;
                nc->assigned_at = (time_t)aa;
                nc->is_escalated = (is_esc != 0);
                nc->escalated_at = (time_t)ea;
                nc->is_acknowledged = (is_ack != 0);
                nc->acknowledged_at = (time_t)acka;
                nc->resolved_at = (time_t)ra;
                nc->closed_at = (time_t)cla;

                if (!state->complaints) {
                    state->complaints = nc;
                } else {
                    Complaint *tail = state->complaints;
                    while (tail->next) tail = tail->next;
                    tail->next = nc;
                }
                if (nc->id >= state->next_complaint_id) {
                    state->next_complaint_id = nc->id + 1;
                }
            } else {
                free(nc);
            }
        }
        fclose(fcmp);
    }

    /* 5. Load History */
    snprintf(path, sizeof(path), "%s/history.txt", state->data_dir);
    FILE *fh = fopen(path, "r");
    if (fh) {
        while (fgets(line, sizeof(line), fh)) {
            HistoryEvent *nh = (HistoryEvent *)calloc(1, sizeof(HistoryEvent));
            if (!nh) continue;
            long long ts = 0;
            char *tok = strtok(line, "|\n");
            int field = 0;
            while (tok) {
                switch (field) {
                    case 0: nh->complaint_id = (unsigned int)atoi(tok); break;
                    case 1: nh->seq_num = (unsigned int)atoi(tok); break;
                    case 2: ts = atoll(tok); break;
                    case 3: snprintf(nh->event_type, sizeof(nh->event_type), "%s", tok); break;
                    case 4: snprintf(nh->prev_value, sizeof(nh->prev_value), "%s", tok); break;
                    case 5: snprintf(nh->new_value, sizeof(nh->new_value), "%s", tok); break;
                    case 6: snprintf(nh->acting_user, sizeof(nh->acting_user), "%s", tok); break;
                    case 7: snprintf(nh->notes, sizeof(nh->notes), "%s", tok); break;
                }
                field++;
                tok = strtok(NULL, "|\n");
            }
            if (field >= 4) {
                nh->timestamp = (time_t)ts;
                if (!state->history) {
                    state->history = nh;
                } else {
                    HistoryEvent *tail = state->history;
                    while (tail->next) tail = tail->next;
                    tail->next = nh;
                }
                if (nh->seq_num >= state->next_history_seq) {
                    state->next_history_seq = nh->seq_num + 1;
                }
            } else {
                free(nh);
            }
        }
        fclose(fh);
    }

    pthread_mutex_unlock(&state->lock);
    return 0;
}
