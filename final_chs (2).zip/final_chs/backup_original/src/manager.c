#include "chs_manager.h"
#include "chs_security.h"
#include "chs_time.h"
#include "chs_storage.h"
#include "chs_history.h"

int chs_manager_init_default(AppState *state) {
    if (!state) return -1;
    if (strlen(state->manager_username) > 0) return 0; /* Already loaded */

    snprintf(state->manager_username, sizeof(state->manager_username), "manager");
    chs_generate_salt(state->manager_salt, sizeof(state->manager_salt));
    chs_hash_password("ManagerPass123!", state->manager_salt,
                      state->manager_password_hash, sizeof(state->manager_password_hash));

    chs_storage_save_manager(state);
    return 0;
}

int chs_manager_add_agent(AppState *state, const char *username, const char *password,
                          const char *full_name, unsigned int *new_id_out) {
    if (!state || !username || !password || !full_name) return -1;

    if (!chs_validate_input(username, 3, MAX_USERNAME_LEN) ||
        !chs_validate_input(password, 4, 64) ||
        !chs_validate_input(full_name, 2, MAX_NAME_LEN)) {
        return -2;
    }

    pthread_mutex_lock(&state->lock);

    /* Check unique username */
    if (strcmp(state->manager_username, username) == 0) {
        pthread_mutex_unlock(&state->lock);
        return -3;
    }
    Agent *a_check = state->agents;
    while (a_check) {
        if (strcmp(a_check->username, username) == 0) {
            pthread_mutex_unlock(&state->lock);
            return -3;
        }
        a_check = a_check->next;
    }

    Agent *na = (Agent *)calloc(1, sizeof(Agent));
    if (!na) {
        pthread_mutex_unlock(&state->lock);
        return -1;
    }

    na->id = state->next_agent_id++;
    snprintf(na->username, sizeof(na->username), "%s", username);
    snprintf(na->full_name, sizeof(na->full_name), "%s", full_name);
    na->is_active = true;
    na->created_at = chs_get_time(state);
    na->deactivated_at = 0;

    chs_generate_salt(na->salt, sizeof(na->salt));
    chs_hash_password(password, na->salt, na->password_hash, sizeof(na->password_hash));
    na->next = NULL;

    if (!state->agents) {
        state->agents = na;
    } else {
        Agent *tail = state->agents;
        while (tail->next) tail = tail->next;
        tail->next = na;
    }

    if (new_id_out) {
        *new_id_out = na->id;
    }

    chs_storage_save_agents(state);
    pthread_mutex_unlock(&state->lock);

    chs_audit_log(state, "manager", "ADD_AGENT", username);
    return 0;
}

int chs_manager_set_agent_active(AppState *state, unsigned int agent_id, bool active) {
    if (!state) return -1;

    pthread_mutex_lock(&state->lock);

    Agent *a = state->agents;
    while (a && a->id != agent_id) {
        a = a->next;
    }

    if (!a) {
        pthread_mutex_unlock(&state->lock);
        return -1;
    }

    a->is_active = active;
    if (!active) {
        a->deactivated_at = chs_get_time(state);
    } else {
        a->deactivated_at = 0;
    }

    chs_storage_save_agents(state);
    pthread_mutex_unlock(&state->lock);

    char det[64];
    snprintf(det, sizeof(det), "Agent #%u set active=%d", agent_id, active ? 1 : 0);
    chs_audit_log(state, "manager", "SET_AGENT_STATUS", det);
    return 0;
}

int chs_manager_reassign_complaint(AppState *state, unsigned int complaint_id, unsigned int new_agent_id, const char *reason) {
    if (!state) return -1;

    pthread_mutex_lock(&state->lock);

    /* Verify agent is valid and active */
    Agent *a = state->agents;
    while (a && a->id != new_agent_id) {
        a = a->next;
    }
    if (!a || !a->is_active) {
        pthread_mutex_unlock(&state->lock);
        return -2; /* Target agent is invalid or inactive */
    }

    Complaint *cmp = state->complaints;
    while (cmp && cmp->id != complaint_id) {
        cmp = cmp->next;
    }
    if (!cmp) {
        pthread_mutex_unlock(&state->lock);
        return -1;
    }

    char prev_val[64], new_val[64];
    snprintf(prev_val, sizeof(prev_val), "Agent %u", cmp->assigned_agent_id);
    snprintf(new_val, sizeof(new_val), "Agent %u", new_agent_id);

    cmp->assigned_agent_id = new_agent_id;
    time_t now = chs_get_time(state);
    cmp->assigned_at = now;
    cmp->updated_at = now;
    /* Do NOT reset cmp->created_at! */

    chs_history_append(state, complaint_id, "REASSIGNED", prev_val, new_val, "manager", reason ? reason : "Reassigned by manager");
    chs_storage_save_complaints(state);

    pthread_mutex_unlock(&state->lock);
    return 0;
}

int chs_manager_acknowledge_escalation(AppState *state, unsigned int complaint_id, const char *manager_notes) {
    if (!state) return -1;

    pthread_mutex_lock(&state->lock);

    Complaint *cmp = state->complaints;
    while (cmp && cmp->id != complaint_id) {
        cmp = cmp->next;
    }
    if (!cmp) {
        pthread_mutex_unlock(&state->lock);
        return -1;
    }

    if (!cmp->is_escalated) {
        pthread_mutex_unlock(&state->lock);
        return -2; /* Not an escalated complaint */
    }

    time_t now = chs_get_time(state);
    cmp->is_acknowledged = true;
    cmp->acknowledged_at = now;
    cmp->updated_at = now;
    if (manager_notes) {
        snprintf(cmp->manager_notes, sizeof(cmp->manager_notes), "%s", manager_notes);
        chs_sanitize_string(cmp->manager_notes, sizeof(cmp->manager_notes));
    }

    chs_history_append(state, complaint_id, "ACKNOWLEDGED", "Pending", "Acknowledged", "manager", cmp->manager_notes);
    chs_storage_save_complaints(state);

    pthread_mutex_unlock(&state->lock);
    return 0;
}

int chs_manager_close_complaint(AppState *state, unsigned int complaint_id) {
    if (!state) return -1;

    pthread_mutex_lock(&state->lock);

    Complaint *cmp = state->complaints;
    while (cmp && cmp->id != complaint_id) {
        cmp = cmp->next;
    }
    if (!cmp) {
        pthread_mutex_unlock(&state->lock);
        return -1;
    }

    /* A resolved complaint must not be closed without required resolution details */
    if (cmp->status != STATUS_RESOLVED || strlen(cmp->resolution_details) == 0) {
        pthread_mutex_unlock(&state->lock);
        return -2; /* Cannot close unresolved complaint or one lacking resolution details */
    }

    time_t now = chs_get_time(state);
    cmp->status = STATUS_CLOSED;
    cmp->closed_at = now;
    cmp->updated_at = now;

    chs_history_append(state, complaint_id, "CLOSED", "RESOLVED", "CLOSED", "manager", "Complaint closed by manager");
    chs_storage_save_complaints(state);

    pthread_mutex_unlock(&state->lock);
    return 0;
}
