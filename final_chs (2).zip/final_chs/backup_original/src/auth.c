#include "chs_auth.h"
#include "chs_security.h"
#include "chs_time.h"
#include "chs_storage.h"

int chs_auth_login(AppState *state, const char *username, const char *password,
                   UserRole *role_out, unsigned int *user_id_out) {
    if (!state || !username || !password || !role_out || !user_id_out) {
        return -1;
    }
    *role_out = ROLE_NONE;
    *user_id_out = 0;

    pthread_mutex_lock(&state->lock);

    /* 1. Check Manager */
    if (strcmp(state->manager_username, username) == 0) {
        if (chs_verify_password(password, state->manager_salt, state->manager_password_hash)) {
            *role_out = ROLE_MANAGER;
            *user_id_out = 99999;
            pthread_mutex_unlock(&state->lock);
            chs_audit_log(state, username, "LOGIN", "Manager login successful");
            return 0;
        }
        pthread_mutex_unlock(&state->lock);
        chs_audit_log(state, username, "LOGIN_FAILED", "Invalid manager password");
        return -1;
    }

    /* 2. Check Agents */
    Agent *a = state->agents;
    while (a) {
        if (strcmp(a->username, username) == 0) {
            if (!a->is_active) {
                pthread_mutex_unlock(&state->lock);
                chs_audit_log(state, username, "LOGIN_FAILED", "Agent account is inactive");
                return -2; /* Inactive account */
            }
            if (chs_verify_password(password, a->salt, a->password_hash)) {
                *role_out = ROLE_AGENT;
                *user_id_out = a->id;
                pthread_mutex_unlock(&state->lock);
                chs_audit_log(state, username, "LOGIN", "Agent login successful");
                return 0;
            }
            pthread_mutex_unlock(&state->lock);
            chs_audit_log(state, username, "LOGIN_FAILED", "Invalid agent password");
            return -1;
        }
        a = a->next;
    }

    /* 3. Check Customers */
    Customer *c = state->customers;
    while (c) {
        if (strcmp(c->username, username) == 0) {
            if (chs_verify_password(password, c->salt, c->password_hash)) {
                *role_out = ROLE_CUSTOMER;
                *user_id_out = c->id;
                pthread_mutex_unlock(&state->lock);
                chs_audit_log(state, username, "LOGIN", "Customer login successful");
                return 0;
            }
            pthread_mutex_unlock(&state->lock);
            chs_audit_log(state, username, "LOGIN_FAILED", "Invalid customer password");
            return -1;
        }
        c = c->next;
    }

    pthread_mutex_unlock(&state->lock);
    chs_audit_log(state, username, "LOGIN_FAILED", "User not found");
    return -1;
}

int chs_auth_register_customer(AppState *state, const char *username, const char *password,
                              const char *full_name, const char *email, const char *phone,
                              unsigned int *cust_id_out) {
    if (!state || !username || !password || !full_name || !email || !phone) {
        return -1;
    }

    /* Input validation */
    if (!chs_validate_input(username, 3, MAX_USERNAME_LEN) ||
        !chs_validate_input(password, 4, 64) ||
        !chs_validate_input(full_name, 2, MAX_NAME_LEN) ||
        !chs_validate_email(email) ||
        !chs_validate_phone(phone)) {
        return -2; /* Invalid input fields */
    }

    pthread_mutex_lock(&state->lock);

    /* Check duplicate username across manager, agents, customers */
    if (strcmp(state->manager_username, username) == 0) {
        pthread_mutex_unlock(&state->lock);
        return -3; /* Username taken */
    }
    Agent *a = state->agents;
    while (a) {
        if (strcmp(a->username, username) == 0) {
            pthread_mutex_unlock(&state->lock);
            return -3;
        }
        a = a->next;
    }
    Customer *c = state->customers;
    while (c) {
        if (strcmp(c->username, username) == 0) {
            pthread_mutex_unlock(&state->lock);
            return -3;
        }
        c = c->next;
    }

    Customer *new_c = (Customer *)calloc(1, sizeof(Customer));
    if (!new_c) {
        pthread_mutex_unlock(&state->lock);
        return -1;
    }

    new_c->id = state->next_customer_id++;
    snprintf(new_c->username, sizeof(new_c->username), "%s", username);
    snprintf(new_c->full_name, sizeof(new_c->full_name), "%s", full_name);
    snprintf(new_c->email, sizeof(new_c->email), "%s", email);
    snprintf(new_c->phone, sizeof(new_c->phone), "%s", phone);
    new_c->created_at = chs_get_time(state);

    chs_generate_salt(new_c->salt, sizeof(new_c->salt));
    chs_hash_password(password, new_c->salt, new_c->password_hash, sizeof(new_c->password_hash));

    new_c->next = NULL;

    if (!state->customers) {
        state->customers = new_c;
    } else {
        Customer *curr = state->customers;
        while (curr->next) curr = curr->next;
        curr->next = new_c;
    }

    if (cust_id_out) {
        *cust_id_out = new_c->id;
    }

    chs_storage_save_customers(state);
    pthread_mutex_unlock(&state->lock);

    chs_audit_log(state, username, "REGISTER", "New customer registered");
    return 0;
}
