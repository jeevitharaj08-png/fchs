#include "chs_complaint.h"
#include "chs_customer.h"
#include "chs_assignment.h"
#include "chs_escalation.h"
#include "chs_time.h"
#include "chs_security.h"
#include "chs_history.h"
#include "chs_storage.h"

int chs_complaint_register(AppState *state, unsigned int customer_id, const char *category,
                           const char *description, ComplaintPriority priority,
                           unsigned int *complaint_id_out) {
    if (!state || !category || !description) return -1;

    if (!chs_validate_input(category, 2, MAX_CATEGORY_LEN) ||
        !chs_validate_input(description, 5, MAX_DESC_LEN)) {
        return -2; /* Invalid input */
    }

    pthread_mutex_lock(&state->lock);

    /* Verify customer exists */
    Customer *c = state->customers;
    while (c && c->id != customer_id) {
        c = c->next;
    }
    if (!c) {
        pthread_mutex_unlock(&state->lock);
        return -3; /* Customer does not exist */
    }

    Complaint *cmp = (Complaint *)calloc(1, sizeof(Complaint));
    if (!cmp) {
        pthread_mutex_unlock(&state->lock);
        return -1;
    }

    cmp->id = state->next_complaint_id++;
    cmp->customer_id = customer_id;
    snprintf(cmp->category, sizeof(cmp->category), "%s", category);
    snprintf(cmp->description, sizeof(cmp->description), "%s", description);
    chs_sanitize_string(cmp->category, sizeof(cmp->category));
    chs_sanitize_string(cmp->description, sizeof(cmp->description));

    cmp->priority = priority;
    cmp->status = STATUS_OPEN;
    time_t now = chs_get_time(state);
    cmp->created_at = now;   /* Preserved throughout lifecycle */
    cmp->updated_at = now;
    cmp->next = NULL;

    if (!state->complaints) {
        state->complaints = cmp;
    } else {
        Complaint *tail = state->complaints;
        while (tail->next) tail = tail->next;
        tail->next = cmp;
    }

    if (complaint_id_out) {
        *complaint_id_out = cmp->id;
    }

    char customer_name[MAX_USERNAME_LEN];
    snprintf(customer_name, sizeof(customer_name), "%s", c->username);

    chs_history_append(state, cmp->id, "CREATED", "None", "OPEN", customer_name, cmp->description);

    /* Automatic assignment to lowest-workload active agent */
    chs_assignment_auto_assign(state, cmp);

    /* If priority is CRITICAL, trigger automatic escalation immediately */
    if (cmp->priority == PRIORITY_CRITICAL && !cmp->is_escalated) {
        cmp->is_escalated = true;
        cmp->escalated_at = now;
        cmp->status = STATUS_ESCALATED;
        snprintf(cmp->escalation_reason, sizeof(cmp->escalation_reason), "Registered with CRITICAL priority");
        chs_history_append(state, cmp->id, "ESCALATED", "None", "CRITICAL", "SYSTEM", "Automatic escalation on CRITICAL priority");
    }

    chs_storage_save_complaints(state);
    pthread_mutex_unlock(&state->lock);

    return 0;
}

Complaint* chs_complaint_find_by_id(AppState *state, unsigned int id) {
    if (!state) return NULL;
    pthread_mutex_lock(&state->lock);
    Complaint *cmp = state->complaints;
    while (cmp) {
        if (cmp->id == id) {
            pthread_mutex_unlock(&state->lock);
            return cmp;
        }
        cmp = cmp->next;
    }
    pthread_mutex_unlock(&state->lock);
    return NULL;
}

int chs_complaint_update_status(AppState *state, unsigned int complaint_id, ComplaintStatus new_status,
                                const char *acting_user, const char *notes) {
    if (!state) return -1;
    pthread_mutex_lock(&state->lock);

    Complaint *cmp = state->complaints;
    while (cmp && cmp->id != complaint_id) {
        cmp = cmp->next;
    }
    if (!cmp) {
        pthread_mutex_unlock(&state->lock);
        return -1;
    }

    if (!is_valid_status_transition(cmp->status, new_status)) {
        pthread_mutex_unlock(&state->lock);
        return -2;
    }

    const char *prev_st = status_to_string(cmp->status);
    const char *next_st = status_to_string(new_status);

    cmp->status = new_status;
    cmp->updated_at = chs_get_time(state);

    chs_history_append(state, complaint_id, "STATUS_CHANGE", prev_st, next_st, acting_user, notes);
    chs_storage_save_complaints(state);

    pthread_mutex_unlock(&state->lock);
    return 0;
}
