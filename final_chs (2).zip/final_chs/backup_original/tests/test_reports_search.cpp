#include <gtest/gtest.h>
#include "chs.h"

static void clean_test_dir(const char *dir) {
    char buf[256];
    snprintf(buf, sizeof(buf), "%s/complaints.txt", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/complaints.txt.tmp", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/customers.txt", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/customers.txt.tmp", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/agents.txt", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/agents.txt.tmp", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/history.txt", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/history.txt.tmp", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/manager.txt", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/manager.txt.tmp", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/audit.log", dir); remove(buf);
}

class SearchReportsFixture {
public:
    AppState state;
    char test_dir[64];
    unsigned int cust1, cust2;

    SearchReportsFixture() {
        snprintf(test_dir, sizeof(test_dir), "data_test_sr");
        clean_test_dir(test_dir);
        chs_init(&state, test_dir);
        cust1 = 0; cust2 = 0;
        chs_auth_register_customer(&state, "sr_cust1", "Pass1234!", "Customer One", "c1@test.com", "+1234567890", &cust1);
        chs_auth_register_customer(&state, "sr_cust2", "Pass1234!", "Customer Two", "c2@test.com", "+1234567891", &cust2);
    }

    ~SearchReportsFixture() {
        chs_cleanup(&state);
        clean_test_dir(test_dir);
    }
};

/* 62. Search complaints by ID */
TEST(SearchReportsSuite, SearchByComplaintId) {
    SearchReportsFixture fix;
    unsigned int cid = 0;
    chs_complaint_register(&fix.state, fix.cust1, "Tech", "Issue search ID", PRIORITY_LOW, &cid);

    Complaint *c = chs_complaint_find_by_id(&fix.state, cid);
    ASSERT_TRUE(c != nullptr);
    EXPECT_EQ(c->id, cid);
}

/* 63. Search complaints by customer ID */
TEST(SearchReportsSuite, SearchByCustomerId) {
    SearchReportsFixture fix;
    unsigned int c1 = 0, c2 = 0;
    chs_complaint_register(&fix.state, fix.cust1, "Tech", "Ticket 1", PRIORITY_LOW, &c1);
    chs_complaint_register(&fix.state, fix.cust2, "Tech", "Ticket 2", PRIORITY_LOW, &c2);

    Complaint **res = nullptr;
    size_t count = 0;
    chs_search_complaints(&fix.state, fix.cust1, -1, -1, -1, &res, &count);
    EXPECT_EQ(count, 1u);
    if (res) {
        EXPECT_EQ(res[0]->customer_id, fix.cust1);
        free(res);
    }
}

/* 64. Search complaints by agent ID */
TEST(SearchReportsSuite, SearchByAgentId) {
    SearchReportsFixture fix;
    unsigned int c1 = 0;
    chs_complaint_register(&fix.state, fix.cust1, "Tech", "Ticket Agent", PRIORITY_LOW, &c1);

    Complaint **res = nullptr;
    size_t count = 0;
    chs_search_complaints(&fix.state, -1, 1, -1, -1, &res, &count);
    EXPECT_GE(count, 1u);
    if (res) free(res);
}

/* 65. Search complaints by status */
TEST(SearchReportsSuite, SearchByStatus) {
    SearchReportsFixture fix;
    unsigned int c1 = 0;
    chs_complaint_register(&fix.state, fix.cust1, "Tech", "Ticket Status", PRIORITY_LOW, &c1);

    Complaint **res = nullptr;
    size_t count = 0;
    chs_search_complaints(&fix.state, -1, -1, STATUS_ASSIGNED, -1, &res, &count);
    EXPECT_GE(count, 1u);
    if (res) free(res);
}

/* 66. Search complaints by priority */
TEST(SearchReportsSuite, SearchByPriority) {
    SearchReportsFixture fix;
    unsigned int c1 = 0;
    chs_complaint_register(&fix.state, fix.cust1, "Billing", "Ticket Priority", PRIORITY_HIGH, &c1);

    Complaint **res = nullptr;
    size_t count = 0;
    chs_search_complaints(&fix.state, -1, -1, -1, PRIORITY_HIGH, &res, &count);
    EXPECT_GE(count, 1u);
    if (res) free(res);
}

/* 67. Search with no matches */
TEST(SearchReportsSuite, SearchWithNoMatches) {
    SearchReportsFixture fix;
    Complaint **res = nullptr;
    size_t count = 0;
    /* Searching for non-existent customer 9999 */
    chs_search_complaints(&fix.state, 9999, -1, -1, -1, &res, &count);
    EXPECT_EQ(count, 0u);
    EXPECT_TRUE(res == nullptr);
}

/* 68. Manager add new agent */
TEST(SearchReportsSuite, ManagerAddAgentSuccess) {
    SearchReportsFixture fix;
    unsigned int new_aid = 0;
    int rc = chs_manager_add_agent(&fix.state, "agent11", "AgentPass123!", "Agent Eleven", &new_aid);
    EXPECT_EQ(rc, 0);
    EXPECT_EQ(new_aid, 11u);

    Agent *a = chs_agent_find_by_id(&fix.state, 11);
    ASSERT_TRUE(a != nullptr);
    EXPECT_TRUE(a->is_active);
}

/* 69. Manager add agent duplicate rejected */
TEST(SearchReportsSuite, ManagerAddAgentDuplicateRejected) {
    SearchReportsFixture fix;
    unsigned int new_aid = 0;
    int rc = chs_manager_add_agent(&fix.state, "agent1", "AgentPass123!", "Duplicate Agent", &new_aid);
    EXPECT_EQ(rc, -3);
}

/* 70. Customer data isolation (cannot view other complaints) */
TEST(SearchReportsSuite, CustomerDataIsolation) {
    SearchReportsFixture fix;
    unsigned int c1 = 0;
    chs_complaint_register(&fix.state, fix.cust1, "Private", "Secret issue", PRIORITY_LOW, &c1);

    /* Customer 2 tries to fetch Customer 1's complaint */
    Complaint *attempt = chs_customer_get_complaint_by_id(&fix.state, fix.cust2, c1);
    EXPECT_TRUE(attempt == nullptr);

    /* Customer 1 can fetch their own complaint */
    Complaint *valid = chs_customer_get_complaint_by_id(&fix.state, fix.cust1, c1);
    EXPECT_TRUE(valid != nullptr);
}

/* 71. Reports execution without crashing */
TEST(SearchReportsSuite, ReportsExecution) {
    SearchReportsFixture fix;
    unsigned int c1 = 0;
    chs_complaint_register(&fix.state, fix.cust1, "Tech", "Issue report", PRIORITY_LOW, &c1);

    /* Direct all reports to a null/temp stream */
    FILE *tmp = fopen("test_report_tmp.txt", "w");
    ASSERT_TRUE(tmp != nullptr);

    chs_report_complaint_summary(&fix.state, tmp);
    chs_report_priority(&fix.state, tmp);
    chs_report_agent_workload(&fix.state, tmp);
    chs_report_escalations(&fix.state, tmp);
    chs_report_customer_summary(&fix.state, tmp);
    chs_report_complaint_history(&fix.state, c1, tmp);

    fclose(tmp);
    remove("test_report_tmp.txt");
}

/* 72. Background escalation monitor start and clean shutdown */
TEST(SearchReportsSuite, BackgroundMonitorStartAndShutdown) {
    SearchReportsFixture fix;
    fix.state.monitor_interval_sec = 1;
    int rc_start = chs_escalation_start_monitor(&fix.state);
    EXPECT_EQ(rc_start, 0);

    /* Let it run for a brief moment */
    struct timespec ts = {0, 50000000}; /* 50ms */
    nanosleep(&ts, nullptr);

    int rc_stop = chs_escalation_stop_monitor(&fix.state);
    EXPECT_EQ(rc_stop, 0);
}

/* 73. Customer queries (find by username and get complaints list) */
TEST(SearchReportsSuite, CustomerQueries) {
    SearchReportsFixture fix;
    Customer *c = chs_customer_find_by_username(&fix.state, "sr_cust1");
    ASSERT_TRUE(c != nullptr);
    EXPECT_EQ(c->id, fix.cust1);

    Customer *missing = chs_customer_find_by_username(&fix.state, "nonexistent");
    EXPECT_TRUE(missing == nullptr);

    unsigned int cid = 0;
    chs_complaint_register(&fix.state, fix.cust1, "Tech", "Query ticket", PRIORITY_LOW, &cid);

    Complaint **arr = nullptr;
    size_t count = 0;
    int rc = chs_customer_get_complaints(&fix.state, fix.cust1, &arr, &count);
    EXPECT_EQ(rc, 0);
    EXPECT_EQ(count, 1u);
    if (arr) free(arr);
}

/* 74. Agent queries (find by username and get assigned list) */
TEST(SearchReportsSuite, AgentQueries) {
    SearchReportsFixture fix;
    Agent *a = chs_agent_find_by_username(&fix.state, "agent1");
    ASSERT_TRUE(a != nullptr);
    EXPECT_EQ(a->id, 1u);

    Agent *missing = chs_agent_find_by_username(&fix.state, "agent999");
    EXPECT_TRUE(missing == nullptr);

    unsigned int cid = 0;
    chs_complaint_register(&fix.state, fix.cust1, "Billing", "Agent query ticket", PRIORITY_LOW, &cid);

    Complaint **arr = nullptr;
    size_t count = 0;
    int rc = chs_agent_get_assigned_complaints(&fix.state, 1, &arr, &count);
    EXPECT_EQ(rc, 0);
    EXPECT_GE(count, 1u);
    if (arr) free(arr);
}

/* 75. Complaint direct update status */
TEST(SearchReportsSuite, ComplaintDirectUpdateStatus) {
    SearchReportsFixture fix;
    unsigned int cid = 0;
    chs_complaint_register(&fix.state, fix.cust1, "Service", "Direct update", PRIORITY_LOW, &cid);

    int rc = chs_complaint_update_status(&fix.state, cid, STATUS_IN_PROGRESS, "supervisor", "Direct progress");
    EXPECT_EQ(rc, 0);

    /* Invalid transition from IN_PROGRESS directly to OPEN */
    int rc_bad = chs_complaint_update_status(&fix.state, cid, STATUS_OPEN, "supervisor", "Bad transition");
    EXPECT_EQ(rc_bad, -2);
}

/* 76. String and enum conversions round-trip */
TEST(SearchReportsSuite, StringAndEnumConversions) {
    EXPECT_STREQ(status_to_string(STATUS_OPEN), "OPEN");
    EXPECT_STREQ(status_to_string(STATUS_ASSIGNED), "ASSIGNED");
    EXPECT_STREQ(status_to_string(STATUS_IN_PROGRESS), "IN_PROGRESS");
    EXPECT_STREQ(status_to_string(STATUS_ESCALATED), "ESCALATED");
    EXPECT_STREQ(status_to_string(STATUS_RESOLVED), "RESOLVED");
    EXPECT_STREQ(status_to_string(STATUS_CLOSED), "CLOSED");
    EXPECT_EQ(string_to_status("OPEN"), STATUS_OPEN);
    EXPECT_EQ(string_to_status("ASSIGNED"), STATUS_ASSIGNED);
    EXPECT_EQ(string_to_status("IN_PROGRESS"), STATUS_IN_PROGRESS);
    EXPECT_EQ(string_to_status("ESCALATED"), STATUS_ESCALATED);
    EXPECT_EQ(string_to_status("RESOLVED"), STATUS_RESOLVED);
    EXPECT_EQ(string_to_status("CLOSED"), STATUS_CLOSED);

    EXPECT_STREQ(priority_to_string(PRIORITY_LOW), "LOW");
    EXPECT_STREQ(priority_to_string(PRIORITY_MEDIUM), "MEDIUM");
    EXPECT_STREQ(priority_to_string(PRIORITY_HIGH), "HIGH");
    EXPECT_STREQ(priority_to_string(PRIORITY_CRITICAL), "CRITICAL");
    EXPECT_EQ(string_to_priority("LOW"), PRIORITY_LOW);
    EXPECT_EQ(string_to_priority("MEDIUM"), PRIORITY_MEDIUM);
    EXPECT_EQ(string_to_priority("HIGH"), PRIORITY_HIGH);
    EXPECT_EQ(string_to_priority("CRITICAL"), PRIORITY_CRITICAL);
}
