#include <gtest/gtest.h>
#include "chs.h"

static void clean_test_dir(const char *dir) {
    char buf[256];
    snprintf(buf, sizeof(buf), "%s/complaints.txt", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/complaints.txt.tmp", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/customers.txt", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/customers.txt.tmp", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/agents.txt", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/agents.txt.tmp", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/history.txt", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/history.txt.tmp", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/manager.txt", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/manager.txt.tmp", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/audit.log", dir); remove(buf);
}

class AssignmentTestFixture {
public:
    AppState state;
    char test_dir[64];
    unsigned int cust_id;

    AssignmentTestFixture() {
        snprintf(test_dir, sizeof(test_dir), "data_test_assign");
        clean_test_dir(test_dir);
        chs_init(&state, test_dir);
        cust_id = 0;
        chs_auth_register_customer(&state, "assignuser", "Pass1234!", "Assign User", "au@test.com", "+1234567890", &cust_id);
    }

    ~AssignmentTestFixture() {
        chs_cleanup(&state);
        clean_test_dir(test_dir);
    }
};

/* 54. Auto-assign to least loaded agent */
TEST(AssignmentSuite, AutoAssignLeastLoadedAgent) {
    AssignmentTestFixture fix;
    unsigned int c1 = 0, c2 = 0;
    /* First complaint assigned to Agent 1 (tie-breaker lowest ID) */
    chs_complaint_register(&fix.state, fix.cust_id, "Tech", "Issue 1", PRIORITY_LOW, &c1);
    Complaint *cmp1 = chs_complaint_find_by_id(&fix.state, c1);
    ASSERT_TRUE(cmp1 != nullptr);
    EXPECT_EQ(cmp1->assigned_agent_id, 1u);

    /* Second complaint should go to Agent 2 because Agent 1 now has workload 1 and Agent 2 has workload 0 */
    chs_complaint_register(&fix.state, fix.cust_id, "Tech", "Issue 2", PRIORITY_LOW, &c2);
    Complaint *cmp2 = chs_complaint_find_by_id(&fix.state, c2);
    ASSERT_TRUE(cmp2 != nullptr);
    EXPECT_EQ(cmp2->assigned_agent_id, 2u);
}

/* 55. Deterministic tie breaking lowest agent ID */
TEST(AssignmentSuite, DeterministicTieBreaking) {
    AssignmentTestFixture fix;
    unsigned int c1 = 0;
    /* All agents 1-10 have workload 0. Must pick Agent 1 */
    chs_complaint_register(&fix.state, fix.cust_id, "Tech", "Issue tie break", PRIORITY_LOW, &c1);
    Complaint *cmp1 = chs_complaint_find_by_id(&fix.state, c1);
    ASSERT_TRUE(cmp1 != nullptr);
    EXPECT_EQ(cmp1->assigned_agent_id, 1u);
}

/* 56. Auto-assign ignores inactive agents */
TEST(AssignmentSuite, AutoAssignIgnoresInactiveAgents) {
    AssignmentTestFixture fix;
    /* Deactivate Agent 1 */
    chs_manager_set_agent_active(&fix.state, 1, false);

    unsigned int c1 = 0;
    chs_complaint_register(&fix.state, fix.cust_id, "Tech", "Issue without agent 1", PRIORITY_LOW, &c1);
    Complaint *cmp1 = chs_complaint_find_by_id(&fix.state, c1);
    ASSERT_TRUE(cmp1 != nullptr);
    /* Should be assigned to Agent 2 */
    EXPECT_EQ(cmp1->assigned_agent_id, 2u);
}

/* 57. Auto-assign when all agents inactive */
TEST(AssignmentSuite, AutoAssignWhenAllAgentsInactive) {
    AssignmentTestFixture fix;
    /* Deactivate all agents 1 to 10 */
    for (unsigned int i = 1; i <= 10; i++) {
        chs_manager_set_agent_active(&fix.state, i, false);
    }

    unsigned int c1 = 0;
    chs_complaint_register(&fix.state, fix.cust_id, "Tech", "No agents online", PRIORITY_LOW, &c1);
    Complaint *cmp1 = chs_complaint_find_by_id(&fix.state, c1);
    ASSERT_TRUE(cmp1 != nullptr);
    EXPECT_EQ(cmp1->assigned_agent_id, 0u);
    EXPECT_EQ(cmp1->status, STATUS_OPEN);
}

/* 58. Workload calculation updates after resolution */
TEST(AssignmentSuite, WorkloadUpdatesAfterResolution) {
    AssignmentTestFixture fix;
    unsigned int c1 = 0;
    chs_complaint_register(&fix.state, fix.cust_id, "Tech", "Workload check", PRIORITY_LOW, &c1);
    EXPECT_EQ(chs_agent_calculate_workload(&fix.state, 1), 1);

    chs_agent_resolve(&fix.state, 1, c1, "Resolved problem");
    EXPECT_EQ(chs_agent_calculate_workload(&fix.state, 1), 0);
}

/* 59. Workload calculation updates after closure */
TEST(AssignmentSuite, WorkloadUpdatesAfterClosure) {
    AssignmentTestFixture fix;
    unsigned int c1 = 0;
    chs_complaint_register(&fix.state, fix.cust_id, "Tech", "Closure check", PRIORITY_LOW, &c1);
    chs_agent_resolve(&fix.state, 1, c1, "Resolved");
    chs_manager_close_complaint(&fix.state, c1);

    EXPECT_EQ(chs_agent_calculate_workload(&fix.state, 1), 0);
}

/* 60. Manager reassign to active agent success */
TEST(AssignmentSuite, ManagerReassignSuccess) {
    AssignmentTestFixture fix;
    unsigned int c1 = 0;
    chs_complaint_register(&fix.state, fix.cust_id, "Tech", "Reassign test", PRIORITY_LOW, &c1);

    int rc = chs_manager_reassign_complaint(&fix.state, c1, 5, "Escalated skill required");
    EXPECT_EQ(rc, 0);

    Complaint *cmp1 = chs_complaint_find_by_id(&fix.state, c1);
    ASSERT_TRUE(cmp1 != nullptr);
    EXPECT_EQ(cmp1->assigned_agent_id, 5u);
}

/* 61. Manager reassign to inactive agent rejected */
TEST(AssignmentSuite, ManagerReassignToInactiveAgentRejected) {
    AssignmentTestFixture fix;
    unsigned int c1 = 0;
    chs_complaint_register(&fix.state, fix.cust_id, "Tech", "Reassign fail test", PRIORITY_LOW, &c1);

    chs_manager_set_agent_active(&fix.state, 4, false);
    int rc = chs_manager_reassign_complaint(&fix.state, c1, 4, "Should fail");
    EXPECT_EQ(rc, -2); /* Inactive target agent */
}
