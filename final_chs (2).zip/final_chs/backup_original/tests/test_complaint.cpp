#include <gtest/gtest.h>
#include "chs.h"

static void clean_test_dir(const char *dir) {
    char buf[256];
    snprintf(buf, sizeof(buf), "%s/complaints.txt", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/complaints.txt.tmp", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/customers.txt", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/customers.txt.tmp", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/agents.txt", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/agents.txt.tmp", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/history.txt", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/history.txt.tmp", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/manager.txt", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/manager.txt.tmp", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/audit.log", dir); remove(buf);
}

class ComplaintTestFixture {
public:
    AppState state;
    char test_dir[64];
    unsigned int cust_id;

    ComplaintTestFixture() {
        snprintf(test_dir, sizeof(test_dir), "data_test_cmp");
        clean_test_dir(test_dir);
        chs_init(&state, test_dir);
        cust_id = 0;
        chs_auth_register_customer(&state, "cmpuser", "Pass1234!", "Complaint User", "cu@test.com", "+1234567890", &cust_id);
    }

    ~ComplaintTestFixture() {
        chs_cleanup(&state);
        clean_test_dir(test_dir);
    }
};

/* 44. Register complaint success */
TEST(ComplaintSuite, RegisterComplaintSuccess) {
    ComplaintTestFixture fix;
    unsigned int cmp_id = 0;
    int rc = chs_complaint_register(&fix.state, fix.cust_id, "Billing", "Overcharged on bill", PRIORITY_MEDIUM, &cmp_id);
    EXPECT_EQ(rc, 0);
    EXPECT_GT(cmp_id, 0u);

    Complaint *c = chs_complaint_find_by_id(&fix.state, cmp_id);
    ASSERT_TRUE(c != nullptr);
    EXPECT_EQ(c->customer_id, fix.cust_id);
    EXPECT_EQ(c->status, STATUS_ASSIGNED);
    EXPECT_GT(c->assigned_agent_id, 0u);
}

/* 45. Register complaint non-existent customer rejected */
TEST(ComplaintSuite, NonExistentCustomerRejected) {
    ComplaintTestFixture fix;
    unsigned int cmp_id = 0;
    int rc = chs_complaint_register(&fix.state, 99999, "Billing", "Overcharged", PRIORITY_LOW, &cmp_id);
    EXPECT_EQ(rc, -3);
}

/* 46. Register complaint empty fields rejected */
TEST(ComplaintSuite, EmptyFieldsRejected) {
    ComplaintTestFixture fix;
    unsigned int cmp_id = 0;
    int r1 = chs_complaint_register(&fix.state, fix.cust_id, "", "Description text", PRIORITY_LOW, &cmp_id);
    EXPECT_EQ(r1, -2);
    int r2 = chs_complaint_register(&fix.state, fix.cust_id, "Category", "", PRIORITY_LOW, &cmp_id);
    EXPECT_EQ(r2, -2);
}

/* 47. Valid transition ASSIGNED to IN_PROGRESS */
TEST(ComplaintSuite, ValidTransitionAssignedToInProgress) {
    ComplaintTestFixture fix;
    unsigned int cmp_id = 0;
    chs_complaint_register(&fix.state, fix.cust_id, "Tech", "Issue text", PRIORITY_LOW, &cmp_id);

    int rc = chs_agent_update_status(&fix.state, 1, cmp_id, STATUS_IN_PROGRESS);
    EXPECT_EQ(rc, 0);

    Complaint *c = chs_complaint_find_by_id(&fix.state, cmp_id);
    ASSERT_TRUE(c != nullptr);
    EXPECT_EQ(c->status, STATUS_IN_PROGRESS);
}

/* 48. Valid transition IN_PROGRESS to RESOLVED */
TEST(ComplaintSuite, ValidTransitionInProgressToResolved) {
    ComplaintTestFixture fix;
    unsigned int cmp_id = 0;
    chs_complaint_register(&fix.state, fix.cust_id, "Tech", "Issue text", PRIORITY_LOW, &cmp_id);
    chs_agent_update_status(&fix.state, 1, cmp_id, STATUS_IN_PROGRESS);

    int rc = chs_agent_resolve(&fix.state, 1, cmp_id, "Applied firmware patch");
    EXPECT_EQ(rc, 0);

    Complaint *c = chs_complaint_find_by_id(&fix.state, cmp_id);
    ASSERT_TRUE(c != nullptr);
    EXPECT_EQ(c->status, STATUS_RESOLVED);
    EXPECT_STREQ(c->resolution_details, "Applied firmware patch");
}

/* 49. Valid transition RESOLVED to CLOSED */
TEST(ComplaintSuite, ValidTransitionResolvedToClosed) {
    ComplaintTestFixture fix;
    unsigned int cmp_id = 0;
    chs_complaint_register(&fix.state, fix.cust_id, "Tech", "Issue text", PRIORITY_LOW, &cmp_id);
    chs_agent_resolve(&fix.state, 1, cmp_id, "Fixed root cause");

    int rc = chs_manager_close_complaint(&fix.state, cmp_id);
    EXPECT_EQ(rc, 0);

    Complaint *c = chs_complaint_find_by_id(&fix.state, cmp_id);
    ASSERT_TRUE(c != nullptr);
    EXPECT_EQ(c->status, STATUS_CLOSED);
    EXPECT_GT(c->closed_at, 0);
}

/* 50. Cannot close unresolved complaint */
TEST(ComplaintSuite, CannotCloseUnresolvedComplaint) {
    ComplaintTestFixture fix;
    unsigned int cmp_id = 0;
    chs_complaint_register(&fix.state, fix.cust_id, "Tech", "Issue text", PRIORITY_LOW, &cmp_id);

    int rc = chs_manager_close_complaint(&fix.state, cmp_id);
    EXPECT_EQ(rc, -2); /* Not in RESOLVED state */

    Complaint *c = chs_complaint_find_by_id(&fix.state, cmp_id);
    ASSERT_TRUE(c != nullptr);
    EXPECT_NE(c->status, STATUS_CLOSED);
}

/* 51. Cannot close resolved complaint lacking resolution details */
TEST(ComplaintSuite, CannotCloseLackingResolutionDetails) {
    ComplaintTestFixture fix;
    unsigned int cmp_id = 0;
    chs_complaint_register(&fix.state, fix.cust_id, "Tech", "Issue text", PRIORITY_LOW, &cmp_id);

    Complaint *c = chs_complaint_find_by_id(&fix.state, cmp_id);
    ASSERT_TRUE(c != nullptr);
    c->status = STATUS_RESOLVED;
    c->resolution_details[0] = '\0'; /* Force empty resolution details */

    int rc = chs_manager_close_complaint(&fix.state, cmp_id);
    EXPECT_EQ(rc, -2);
}

/* 52. Invalid status transition CLOSED to OPEN rejected */
TEST(ComplaintSuite, ClosedCannotTransition) {
    ComplaintTestFixture fix;
    unsigned int cmp_id = 0;
    chs_complaint_register(&fix.state, fix.cust_id, "Tech", "Issue text", PRIORITY_LOW, &cmp_id);
    chs_agent_resolve(&fix.state, 1, cmp_id, "Fixed");
    chs_manager_close_complaint(&fix.state, cmp_id);

    EXPECT_FALSE(is_valid_status_transition(STATUS_CLOSED, STATUS_OPEN));
    EXPECT_FALSE(is_valid_status_transition(STATUS_CLOSED, STATUS_IN_PROGRESS));
}

/* 53. Agent unauthorized complaint update rejected */
TEST(ComplaintSuite, AgentUnauthorizedUpdateRejected) {
    ComplaintTestFixture fix;
    unsigned int cmp_id = 0;
    chs_complaint_register(&fix.state, fix.cust_id, "Tech", "Issue text", PRIORITY_LOW, &cmp_id);

    /* Complaint is assigned to Agent 1. Agent 2 attempts to update */
    int rc = chs_agent_update_status(&fix.state, 2, cmp_id, STATUS_IN_PROGRESS);
    EXPECT_EQ(rc, -2); /* Not authorized */
}
