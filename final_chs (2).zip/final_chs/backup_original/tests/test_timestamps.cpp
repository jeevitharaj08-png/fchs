#include <gtest/gtest.h>
#include "chs.h"

static void clean_test_dir(const char *dir) {
    char buf[256];
    snprintf(buf, sizeof(buf), "%s/complaints.txt", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/complaints.txt.tmp", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/customers.txt", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/customers.txt.tmp", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/agents.txt", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/agents.txt.tmp", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/history.txt", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/history.txt.tmp", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/manager.txt", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/manager.txt.tmp", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/audit.log", dir); remove(buf);
}

class TimestampTestFixture {
public:
    AppState state;
    char test_dir[64];

    TimestampTestFixture() {
        snprintf(test_dir, sizeof(test_dir), "data_test_ts");
        clean_test_dir(test_dir);
        chs_reset_mock_time();
        chs_set_mock_time(1700000000);
        chs_init(&state, test_dir);
    }

    ~TimestampTestFixture() {
        chs_cleanup(&state);
        clean_test_dir(test_dir);
        chs_reset_mock_time();
    }
};

/* 1. Complaint creation timestamp */
TEST(TimestampSuite, CreationTimestamp) {
    TimestampTestFixture fix;
    unsigned int cust_id = 0;
    chs_auth_register_customer(&fix.state, "testuser1", "Pass1234!", "Test User 1", "u1@test.com", "+1234567890", &cust_id);

    chs_set_mock_time(1700000100);
    unsigned int cmp_id = 0;
    int rc = chs_complaint_register(&fix.state, cust_id, "Tech", "Issue with internet", PRIORITY_LOW, &cmp_id);
    EXPECT_EQ(rc, 0);

    Complaint *c = chs_complaint_find_by_id(&fix.state, cmp_id);
    ASSERT_TRUE(c != nullptr);
    EXPECT_EQ(c->created_at, (time_t)1700000100);
}

/* 2. Last-updated timestamp */
TEST(TimestampSuite, LastUpdatedTimestamp) {
    TimestampTestFixture fix;
    unsigned int cust_id = 0, cmp_id = 0;
    chs_auth_register_customer(&fix.state, "testuser2", "Pass1234!", "Test User 2", "u2@test.com", "+1234567890", &cust_id);
    chs_set_mock_time(1700000200);
    chs_complaint_register(&fix.state, cust_id, "Tech", "Issue with speed", PRIORITY_LOW, &cmp_id);

    chs_set_mock_time(1700000500);
    chs_agent_add_note(&fix.state, 1, cmp_id, "Checking network line");

    Complaint *c = chs_complaint_find_by_id(&fix.state, cmp_id);
    ASSERT_TRUE(c != nullptr);
    EXPECT_EQ(c->created_at, (time_t)1700000200);
    EXPECT_EQ(c->updated_at, (time_t)1700000500);
}

/* 3. Assignment timestamp */
TEST(TimestampSuite, AssignmentTimestamp) {
    TimestampTestFixture fix;
    unsigned int cust_id = 0, cmp_id = 0;
    chs_auth_register_customer(&fix.state, "testuser3", "Pass1234!", "Test User 3", "u3@test.com", "+1234567890", &cust_id);
    chs_set_mock_time(1700000300);
    chs_complaint_register(&fix.state, cust_id, "Billing", "Double charge", PRIORITY_LOW, &cmp_id);

    Complaint *c = chs_complaint_find_by_id(&fix.state, cmp_id);
    ASSERT_TRUE(c != nullptr);
    EXPECT_GT(c->assigned_agent_id, 0u);
    EXPECT_EQ(c->assigned_at, (time_t)1700000300);
}

/* 4. Reassignment timestamp */
TEST(TimestampSuite, ReassignmentTimestamp) {
    TimestampTestFixture fix;
    unsigned int cust_id = 0, cmp_id = 0;
    chs_auth_register_customer(&fix.state, "testuser4", "Pass1234!", "Test User 4", "u4@test.com", "+1234567890", &cust_id);
    chs_set_mock_time(1700000400);
    chs_complaint_register(&fix.state, cust_id, "Billing", "Wrong tier", PRIORITY_LOW, &cmp_id);

    chs_set_mock_time(1700000800);
    int rc = chs_manager_reassign_complaint(&fix.state, cmp_id, 2, "Workload rebalance");
    EXPECT_EQ(rc, 0);

    Complaint *c = chs_complaint_find_by_id(&fix.state, cmp_id);
    ASSERT_TRUE(c != nullptr);
    EXPECT_EQ(c->assigned_agent_id, 2u);
    EXPECT_EQ(c->assigned_at, (time_t)1700000800);
    EXPECT_EQ(c->created_at, (time_t)1700000400); /* Creation time remains unchanged */
}

/* 5. Status-change timestamps */
TEST(TimestampSuite, StatusChangeTimestamps) {
    TimestampTestFixture fix;
    unsigned int cust_id = 0, cmp_id = 0;
    chs_auth_register_customer(&fix.state, "testuser5", "Pass1234!", "Test User 5", "u5@test.com", "+1234567890", &cust_id);
    chs_set_mock_time(1700001000);
    chs_complaint_register(&fix.state, cust_id, "Service", "Downtime", PRIORITY_LOW, &cmp_id);

    chs_set_mock_time(1700002000);
    int rc = chs_agent_update_status(&fix.state, 1, cmp_id, STATUS_IN_PROGRESS);
    EXPECT_EQ(rc, 0);

    Complaint *c = chs_complaint_find_by_id(&fix.state, cmp_id);
    ASSERT_TRUE(c != nullptr);
    EXPECT_EQ(c->status, STATUS_IN_PROGRESS);
    EXPECT_EQ(c->updated_at, (time_t)1700002000);
}

/* 6. Priority-change timestamps */
TEST(TimestampSuite, PriorityChangeTimestamps) {
    TimestampTestFixture fix;
    unsigned int cust_id = 0, cmp_id = 0;
    chs_auth_register_customer(&fix.state, "testuser6", "Pass1234!", "Test User 6", "u6@test.com", "+1234567890", &cust_id);
    chs_set_mock_time(1700003000);
    chs_complaint_register(&fix.state, cust_id, "Support", "Login bug", PRIORITY_LOW, &cmp_id);

    chs_set_mock_time(1700004000);
    chs_agent_change_priority(&fix.state, 1, cmp_id, PRIORITY_HIGH);

    Complaint *c = chs_complaint_find_by_id(&fix.state, cmp_id);
    ASSERT_TRUE(c != nullptr);
    EXPECT_EQ(c->priority, PRIORITY_HIGH);
    EXPECT_EQ(c->updated_at, (time_t)1700004000);
}

/* 7. Escalation timestamp */
TEST(TimestampSuite, EscalationTimestamp) {
    TimestampTestFixture fix;
    unsigned int cust_id = 0, cmp_id = 0;
    chs_auth_register_customer(&fix.state, "testuser7", "Pass1234!", "Test User 7", "u7@test.com", "+1234567890", &cust_id);
    chs_set_mock_time(1700005000);
    chs_complaint_register(&fix.state, cust_id, "Support", "Urgent bug", PRIORITY_LOW, &cmp_id);

    chs_set_mock_time(1700006000);
    chs_escalation_trigger(&fix.state, cmp_id, "Customer requested supervisor", "agent1");

    Complaint *c = chs_complaint_find_by_id(&fix.state, cmp_id);
    ASSERT_TRUE(c != nullptr);
    EXPECT_TRUE(c->is_escalated);
    EXPECT_EQ(c->escalated_at, (time_t)1700006000);
    EXPECT_EQ(c->status, STATUS_ESCALATED);
}

/* 8. Manager acknowledgment timestamp */
TEST(TimestampSuite, ManagerAcknowledgmentTimestamp) {
    TimestampTestFixture fix;
    unsigned int cust_id = 0, cmp_id = 0;
    chs_auth_register_customer(&fix.state, "testuser8", "Pass1234!", "Test User 8", "u8@test.com", "+1234567890", &cust_id);
    chs_set_mock_time(1700007000);
    chs_complaint_register(&fix.state, cust_id, "Hardware", "Router damaged", PRIORITY_LOW, &cmp_id);
    chs_escalation_trigger(&fix.state, cmp_id, "Hardware replacement needed", "agent1");

    chs_set_mock_time(1700008000);
    int rc = chs_manager_acknowledge_escalation(&fix.state, cmp_id, "Dispatching engineer");
    EXPECT_EQ(rc, 0);

    Complaint *c = chs_complaint_find_by_id(&fix.state, cmp_id);
    ASSERT_TRUE(c != nullptr);
    EXPECT_TRUE(c->is_acknowledged);
    EXPECT_EQ(c->acknowledged_at, (time_t)1700008000);
}

/* 9. Resolution timestamp */
TEST(TimestampSuite, ResolutionTimestamp) {
    TimestampTestFixture fix;
    unsigned int cust_id = 0, cmp_id = 0;
    chs_auth_register_customer(&fix.state, "testuser9", "Pass1234!", "Test User 9", "u9@test.com", "+1234567890", &cust_id);
    chs_set_mock_time(1700009000);
    chs_complaint_register(&fix.state, cust_id, "Config", "Port forwarding issue", PRIORITY_LOW, &cmp_id);

    chs_set_mock_time(1700010000);
    int rc = chs_agent_resolve(&fix.state, 1, cmp_id, "Reconfigured firewall ports 80/443");
    EXPECT_EQ(rc, 0);

    Complaint *c = chs_complaint_find_by_id(&fix.state, cmp_id);
    ASSERT_TRUE(c != nullptr);
    EXPECT_EQ(c->status, STATUS_RESOLVED);
    EXPECT_EQ(c->resolved_at, (time_t)1700010000);
}

/* 10. Closure timestamp */
TEST(TimestampSuite, ClosureTimestamp) {
    TimestampTestFixture fix;
    unsigned int cust_id = 0, cmp_id = 0;
    chs_auth_register_customer(&fix.state, "testuser10", "Pass1234!", "Test User 10", "u10@test.com", "+1234567890", &cust_id);
    chs_set_mock_time(1700011000);
    chs_complaint_register(&fix.state, cust_id, "Config", "DNS fix", PRIORITY_LOW, &cmp_id);
    chs_agent_resolve(&fix.state, 1, cmp_id, "Updated upstream DNS nameservers");

    chs_set_mock_time(1700012000);
    int rc = chs_manager_close_complaint(&fix.state, cmp_id);
    EXPECT_EQ(rc, 0);

    Complaint *c = chs_complaint_find_by_id(&fix.state, cmp_id);
    ASSERT_TRUE(c != nullptr);
    EXPECT_EQ(c->status, STATUS_CLOSED);
    EXPECT_EQ(c->closed_at, (time_t)1700012000);
}

/* 11. History timestamp ordering */
TEST(TimestampSuite, HistoryTimestampOrdering) {
    TimestampTestFixture fix;
    unsigned int cust_id = 0, cmp_id = 0;
    chs_auth_register_customer(&fix.state, "testuser11", "Pass1234!", "Test User 11", "u11@test.com", "+1234567890", &cust_id);

    chs_set_mock_time(1700020000);
    chs_complaint_register(&fix.state, cust_id, "Tech", "Issue A", PRIORITY_LOW, &cmp_id);

    chs_set_mock_time(1700020100);
    chs_agent_add_note(&fix.state, 1, cmp_id, "Note 1");

    chs_set_mock_time(1700020200);
    chs_agent_change_priority(&fix.state, 1, cmp_id, PRIORITY_MEDIUM);

    HistoryEvent **events = nullptr;
    size_t count = 0;
    chs_history_get_for_complaint(&fix.state, cmp_id, &events, &count);
    ASSERT_GE(count, 3u);

    for (size_t i = 1; i < count; i++) {
        EXPECT_GE(events[i]->timestamp, events[i - 1]->timestamp);
        EXPECT_GT(events[i]->seq_num, events[i - 1]->seq_num);
    }
    if (events) free(events);
}

/* 12. Persistence and timestamp reload */
TEST(TimestampSuite, PersistenceAndTimestampReload) {
    char dir[] = "data_test_reload";
    clean_test_dir(dir);
    chs_set_mock_time(1700030000);
    AppState state1;
    chs_init(&state1, dir);

    unsigned int cust_id = 0, cmp_id = 0;
    chs_auth_register_customer(&state1, "reloaduser", "Pass1234!", "Reload User", "ru@test.com", "+1234567890", &cust_id);
    chs_complaint_register(&state1, cust_id, "Tech", "Reload test ticket", PRIORITY_LOW, &cmp_id);

    chs_set_mock_time(1700030500);
    chs_agent_add_note(&state1, 1, cmp_id, "Note before restart");

    chs_storage_save_all(&state1);
    chs_cleanup(&state1);

    /* Reload in fresh state */
    AppState state2;
    chs_init(&state2, dir);

    Complaint *c = chs_complaint_find_by_id(&state2, cmp_id);
    ASSERT_TRUE(c != nullptr);
    EXPECT_EQ(c->created_at, (time_t)1700030000);
    EXPECT_EQ(c->updated_at, (time_t)1700030500);

    chs_cleanup(&state2);
    clean_test_dir(dir);
}

/* 13. Exactly 86,400 seconds elapsed */
TEST(TimestampSuite, Exactly86400SecondsElapsed) {
    TimestampTestFixture fix;
    unsigned int cust_id = 0, cmp_id = 0;
    chs_auth_register_customer(&fix.state, "user86400", "Pass1234!", "User 86400", "u864@test.com", "+1234567890", &cust_id);

    chs_set_mock_time(1700040000);
    chs_complaint_register(&fix.state, cust_id, "Tech", "SLA Test 86400", PRIORITY_LOW, &cmp_id);

    /* Advance time by exactly 86,400 seconds */
    chs_set_mock_time(1700040000 + 86400);
    chs_escalation_check_all(&fix.state);

    Complaint *c = chs_complaint_find_by_id(&fix.state, cmp_id);
    ASSERT_TRUE(c != nullptr);
    EXPECT_TRUE(c->is_escalated);
    EXPECT_EQ(c->status, STATUS_ESCALATED);
}

/* 14. One second below threshold */
TEST(TimestampSuite, OneSecondBelowThreshold) {
    TimestampTestFixture fix;
    unsigned int cust_id = 0, cmp_id = 0;
    chs_auth_register_customer(&fix.state, "user86399", "Pass1234!", "User 86399", "u863@test.com", "+1234567890", &cust_id);

    chs_set_mock_time(1700050000);
    chs_complaint_register(&fix.state, cust_id, "Tech", "SLA Test 86399", PRIORITY_LOW, &cmp_id);

    /* Advance time by 86,399 seconds (1 second below threshold) */
    chs_set_mock_time(1700050000 + 86399);
    chs_escalation_check_all(&fix.state);

    Complaint *c = chs_complaint_find_by_id(&fix.state, cmp_id);
    ASSERT_TRUE(c != nullptr);
    EXPECT_FALSE(c->is_escalated);
    EXPECT_NE(c->status, STATUS_ESCALATED);
}

/* 15. One second above threshold */
TEST(TimestampSuite, OneSecondAboveThreshold) {
    TimestampTestFixture fix;
    unsigned int cust_id = 0, cmp_id = 0;
    chs_auth_register_customer(&fix.state, "user86401", "Pass1234!", "User 86401", "u8641@test.com", "+1234567890", &cust_id);

    chs_set_mock_time(1700060000);
    chs_complaint_register(&fix.state, cust_id, "Tech", "SLA Test 86401", PRIORITY_LOW, &cmp_id);

    /* Advance time by 86,401 seconds */
    chs_set_mock_time(1700060000 + 86401);
    chs_escalation_check_all(&fix.state);

    Complaint *c = chs_complaint_find_by_id(&fix.state, cmp_id);
    ASSERT_TRUE(c != nullptr);
    EXPECT_TRUE(c->is_escalated);
}

/* 16. Critical complaint escalation */
TEST(TimestampSuite, CriticalComplaintEscalation) {
    TimestampTestFixture fix;
    unsigned int cust_id = 0, cmp_id = 0;
    chs_auth_register_customer(&fix.state, "usercrit", "Pass1234!", "User Crit", "crit@test.com", "+1234567890", &cust_id);

    chs_set_mock_time(1700070000);
    /* Registering with CRITICAL priority escalates automatically */
    chs_complaint_register(&fix.state, cust_id, "Safety", "Gas leak detected", PRIORITY_CRITICAL, &cmp_id);

    Complaint *c = chs_complaint_find_by_id(&fix.state, cmp_id);
    ASSERT_TRUE(c != nullptr);
    EXPECT_TRUE(c->is_escalated);
    EXPECT_EQ(c->status, STATUS_ESCALATED);
    EXPECT_EQ(c->escalated_at, (time_t)1700070000);
}

/* 17. Resolved complaint excluded from age-based escalation */
TEST(TimestampSuite, ResolvedComplaintExcludedFromAgeEscalation) {
    TimestampTestFixture fix;
    unsigned int cust_id = 0, cmp_id = 0;
    chs_auth_register_customer(&fix.state, "userres", "Pass1234!", "User Res", "res@test.com", "+1234567890", &cust_id);

    chs_set_mock_time(1700080000);
    chs_complaint_register(&fix.state, cust_id, "Tech", "Short issue", PRIORITY_LOW, &cmp_id);
    chs_agent_resolve(&fix.state, 1, cmp_id, "Fixed promptly");

    /* Fast forward 48 hours */
    chs_set_mock_time(1700080000 + 172800);
    chs_escalation_check_all(&fix.state);

    Complaint *c = chs_complaint_find_by_id(&fix.state, cmp_id);
    ASSERT_TRUE(c != nullptr);
    EXPECT_FALSE(c->is_escalated);
    EXPECT_EQ(c->status, STATUS_RESOLVED);
}

/* 18. Closed complaint excluded from age-based escalation */
TEST(TimestampSuite, ClosedComplaintExcludedFromAgeEscalation) {
    TimestampTestFixture fix;
    unsigned int cust_id = 0, cmp_id = 0;
    chs_auth_register_customer(&fix.state, "userclo", "Pass1234!", "User Clo", "clo@test.com", "+1234567890", &cust_id);

    chs_set_mock_time(1700090000);
    chs_complaint_register(&fix.state, cust_id, "Tech", "Issue to close", PRIORITY_LOW, &cmp_id);
    chs_agent_resolve(&fix.state, 1, cmp_id, "Resolved ticket");
    chs_manager_close_complaint(&fix.state, cmp_id);

    /* Fast forward 7 days */
    chs_set_mock_time(1700090000 + (7 * 86400));
    chs_escalation_check_all(&fix.state);

    Complaint *c = chs_complaint_find_by_id(&fix.state, cmp_id);
    ASSERT_TRUE(c != nullptr);
    EXPECT_FALSE(c->is_escalated);
    EXPECT_EQ(c->status, STATUS_CLOSED);
}

/* 19. Reassignment not resetting the original timer */
TEST(TimestampSuite, ReassignmentNotResettingOriginalTimer) {
    TimestampTestFixture fix;
    unsigned int cust_id = 0, cmp_id = 0;
    chs_auth_register_customer(&fix.state, "userreassign", "Pass1234!", "User Reassign", "re@test.com", "+1234567890", &cust_id);

    chs_set_mock_time(1700100000);
    chs_complaint_register(&fix.state, cust_id, "Billing", "Bill dispute", PRIORITY_LOW, &cmp_id);

    /* After 20 hours, reassign complaint */
    chs_set_mock_time(1700100000 + 72000);
    chs_manager_reassign_complaint(&fix.state, cmp_id, 2, "Reassigned to specialist");

    /* After 5 more hours (total 25 hours elapsed since creation) */
    chs_set_mock_time(1700100000 + 72000 + 18000);
    chs_escalation_check_all(&fix.state);

    Complaint *c = chs_complaint_find_by_id(&fix.state, cmp_id);
    ASSERT_TRUE(c != nullptr);
    /* Must be escalated because 25 hours elapsed from created_at! */
    EXPECT_TRUE(c->is_escalated);
    EXPECT_EQ(c->created_at, (time_t)1700100000);
}

/* 20. Overdue complaint detection after restart */
TEST(TimestampSuite, OverdueComplaintDetectionAfterRestart) {
    char dir[] = "data_test_restart_overdue";
    clean_test_dir(dir);
    chs_set_mock_time(1700200000);
    AppState s1;
    chs_init(&s1, dir);

    unsigned int cust_id = 0, cmp_id = 0;
    chs_auth_register_customer(&s1, "overdueuser", "Pass1234!", "Overdue User", "ov@test.com", "+1234567890", &cust_id);
    chs_complaint_register(&s1, cust_id, "Tech", "Overdue ticket across restart", PRIORITY_LOW, &cmp_id);

    chs_storage_save_all(&s1);
    chs_cleanup(&s1);

    /* Fast-forward time by 30 hours, then restart system */
    chs_set_mock_time(1700200000 + (30 * 3600));

    AppState s2;
    chs_init(&s2, dir);
    /* Monitor checks on startup */
    chs_escalation_check_all(&s2);

    Complaint *c = chs_complaint_find_by_id(&s2, cmp_id);
    ASSERT_TRUE(c != nullptr);
    EXPECT_TRUE(c->is_escalated);

    chs_cleanup(&s2);
    clean_test_dir(dir);
}

/* 21. Invalid timestamps */
TEST(TimestampSuite, InvalidTimestamps) {
    time_t parsed = chs_parse_iso("invalid-timestamp-string");
    EXPECT_EQ(parsed, 0);

    parsed = chs_parse_iso(nullptr);
    EXPECT_EQ(parsed, 0);

    char buf[64];
    chs_format_iso(0, buf, sizeof(buf));
    EXPECT_STREQ(buf, "N/A");
}

/* 22. Future timestamps */
TEST(TimestampSuite, FutureTimestamps) {
    time_t future_t = 2000000000;
    char iso_buf[64];
    chs_format_iso(future_t, iso_buf, sizeof(iso_buf));
    EXPECT_GT(strlen(iso_buf), 10u);

    time_t parsed = chs_parse_iso(iso_buf);
    EXPECT_EQ(parsed, future_t);
}

/* 23. Concurrent timestamp and history updates */
TEST(TimestampSuite, ConcurrentTimestampAndHistoryUpdates) {
    TimestampTestFixture fix;
    unsigned int cust_id = 0, cmp_id = 0;
    chs_auth_register_customer(&fix.state, "concuruser", "Pass1234!", "Concur User", "cc@test.com", "+1234567890", &cust_id);
    chs_complaint_register(&fix.state, cust_id, "Tech", "Concurrent updates ticket", PRIORITY_LOW, &cmp_id);

    for (int i = 0; i < 50; i++) {
        chs_advance_mock_time(10);
        char note[64];
        snprintf(note, sizeof(note), "Concurrent Note #%d", i);
        chs_history_append(&fix.state, cmp_id, "NOTE_ADDED", "-", "-", "agent1", note);
    }

    HistoryEvent **evs = nullptr;
    size_t count = 0;
    chs_history_get_for_complaint(&fix.state, cmp_id, &evs, &count);
    EXPECT_GE(count, 50u);
    if (evs) free(evs);
}

/* 24. Duplicate escalation prevention */
TEST(TimestampSuite, DuplicateEscalationPrevention) {
    TimestampTestFixture fix;
    unsigned int cust_id = 0, cmp_id = 0;
    chs_auth_register_customer(&fix.state, "dupesc", "Pass1234!", "Dup Esc", "de@test.com", "+1234567890", &cust_id);
    chs_complaint_register(&fix.state, cust_id, "Tech", "Escalation ticket", PRIORITY_LOW, &cmp_id);

    int r1 = chs_escalation_trigger(&fix.state, cmp_id, "Reason 1", "agent1");
    EXPECT_EQ(r1, 0);

    /* Second escalation trigger must be rejected */
    int r2 = chs_escalation_trigger(&fix.state, cmp_id, "Reason 2", "agent1");
    EXPECT_EQ(r2, -2);
}

/* 25. Fake-clock behavior */
TEST(TimestampSuite, FakeClockBehavior) {
    chs_reset_mock_time();
    chs_set_mock_time(123456789);
    EXPECT_EQ(chs_get_time(nullptr), (time_t)123456789);

    chs_advance_mock_time(500);
    EXPECT_EQ(chs_get_time(nullptr), (time_t)123457289);

    chs_reset_mock_time();
    time_t real_t = chs_get_time(nullptr);
    EXPECT_GT(real_t, 1700000000);
}
