#include <gtest/gtest.h>
#include "chs.h"

static void clean_test_dir(const char *dir) {
    char buf[256];
    snprintf(buf, sizeof(buf), "%s/complaints.txt", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/complaints.txt.tmp", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/customers.txt", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/customers.txt.tmp", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/agents.txt", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/agents.txt.tmp", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/history.txt", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/history.txt.tmp", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/manager.txt", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/manager.txt.tmp", dir); remove(buf);
    snprintf(buf, sizeof(buf), "%s/audit.log", dir); remove(buf);
}

class AuthTestFixture {
public:
    AppState state;
    char test_dir[64];

    AuthTestFixture() {
        snprintf(test_dir, sizeof(test_dir), "data_test_auth");
        clean_test_dir(test_dir);
        chs_init(&state, test_dir);
    }

    ~AuthTestFixture() {
        chs_cleanup(&state);
        clean_test_dir(test_dir);
    }
};

/* 26. Customer registration success */
TEST(AuthSuite, CustomerRegistrationSuccess) {
    AuthTestFixture fix;
    unsigned int id = 0;
    int rc = chs_auth_register_customer(&fix.state, "alice", "AlicePass123!", "Alice Smith", "alice@example.com", "+1-555-123456", &id);
    EXPECT_EQ(rc, 0);
    EXPECT_GT(id, 0u);
}

/* 27. Duplicate username rejected */
TEST(AuthSuite, DuplicateUsernameRejected) {
    AuthTestFixture fix;
    unsigned int id1 = 0, id2 = 0;
    chs_auth_register_customer(&fix.state, "bob", "BobPass123!", "Bob Jones", "bob@example.com", "+1-555-987654", &id1);
    int rc = chs_auth_register_customer(&fix.state, "bob", "BobNewPass!", "Bob Other", "bob2@example.com", "+1-555-111222", &id2);
    EXPECT_EQ(rc, -3);
}

/* 28. Duplicate with agent username rejected */
TEST(AuthSuite, DuplicateWithAgentUsernameRejected) {
    AuthTestFixture fix;
    unsigned int id = 0;
    int rc = chs_auth_register_customer(&fix.state, "agent1", "Pass1234!", "Fake Agent", "fa@test.com", "+1234567890", &id);
    EXPECT_EQ(rc, -3);
}

/* 29. Duplicate with manager username rejected */
TEST(AuthSuite, DuplicateWithManagerUsernameRejected) {
    AuthTestFixture fix;
    unsigned int id = 0;
    int rc = chs_auth_register_customer(&fix.state, "manager", "Pass1234!", "Fake Manager", "fm@test.com", "+1234567890", &id);
    EXPECT_EQ(rc, -3);
}

/* 30. Invalid username too short */
TEST(AuthSuite, InvalidUsernameTooShort) {
    AuthTestFixture fix;
    unsigned int id = 0;
    int rc = chs_auth_register_customer(&fix.state, "ab", "Pass1234!", "Short Name", "sn@test.com", "+1234567890", &id);
    EXPECT_EQ(rc, -2);
}

/* 31. Invalid password too short */
TEST(AuthSuite, InvalidPasswordTooShort) {
    AuthTestFixture fix;
    unsigned int id = 0;
    int rc = chs_auth_register_customer(&fix.state, "user_pwd", "123", "User Short Pwd", "usp@test.com", "+1234567890", &id);
    EXPECT_EQ(rc, -2);
}

/* 32. Invalid email format rejected */
TEST(AuthSuite, InvalidEmailRejected) {
    AuthTestFixture fix;
    unsigned int id = 0;
    int rc = chs_auth_register_customer(&fix.state, "bademailuser", "Pass1234!", "Bad Email", "invalidemail.com", "+1234567890", &id);
    EXPECT_EQ(rc, -2);
}

/* 33. Invalid phone format rejected */
TEST(AuthSuite, InvalidPhoneRejected) {
    AuthTestFixture fix;
    unsigned int id = 0;
    int rc = chs_auth_register_customer(&fix.state, "badphoneuser", "Pass1234!", "Bad Phone", "bp@test.com", "not_a_phone", &id);
    EXPECT_EQ(rc, -2);
}

/* 34. Customer login success */
TEST(AuthSuite, CustomerLoginSuccess) {
    AuthTestFixture fix;
    unsigned int id = 0;
    chs_auth_register_customer(&fix.state, "charlie", "CharlieSecret!", "Charlie Brown", "charlie@test.com", "+1555666777", &id);

    UserRole role = ROLE_NONE;
    unsigned int logged_id = 0;
    int rc = chs_auth_login(&fix.state, "charlie", "CharlieSecret!", &role, &logged_id);
    EXPECT_EQ(rc, 0);
    EXPECT_EQ(role, ROLE_CUSTOMER);
    EXPECT_EQ(logged_id, id);
}

/* 35. Customer login wrong password */
TEST(AuthSuite, CustomerLoginWrongPassword) {
    AuthTestFixture fix;
    chs_auth_register_customer(&fix.state, "dave", "DaveSecret!", "Dave White", "dave@test.com", "+1555666888", nullptr);

    UserRole role = ROLE_NONE;
    unsigned int logged_id = 0;
    int rc = chs_auth_login(&fix.state, "dave", "WrongPass!", &role, &logged_id);
    EXPECT_EQ(rc, -1);
}

/* 36. Customer login nonexistent user */
TEST(AuthSuite, CustomerLoginNonexistentUser) {
    AuthTestFixture fix;
    UserRole role = ROLE_NONE;
    unsigned int logged_id = 0;
    int rc = chs_auth_login(&fix.state, "ghostuser", "AnyPass!", &role, &logged_id);
    EXPECT_EQ(rc, -1);
}

/* 37. Manager login success */
TEST(AuthSuite, ManagerLoginSuccess) {
    AuthTestFixture fix;
    UserRole role = ROLE_NONE;
    unsigned int logged_id = 0;
    int rc = chs_auth_login(&fix.state, "manager", "ManagerPass123!", &role, &logged_id);
    EXPECT_EQ(rc, 0);
    EXPECT_EQ(role, ROLE_MANAGER);
}

/* 38. Manager login wrong password */
TEST(AuthSuite, ManagerLoginWrongPassword) {
    AuthTestFixture fix;
    UserRole role = ROLE_NONE;
    unsigned int logged_id = 0;
    int rc = chs_auth_login(&fix.state, "manager", "WrongPass!", &role, &logged_id);
    EXPECT_EQ(rc, -1);
}

/* 39. Agent login success */
TEST(AuthSuite, AgentLoginSuccess) {
    AuthTestFixture fix;
    UserRole role = ROLE_NONE;
    unsigned int logged_id = 0;
    int rc = chs_auth_login(&fix.state, "agent1", "AgentPass123!", &role, &logged_id);
    EXPECT_EQ(rc, 0);
    EXPECT_EQ(role, ROLE_AGENT);
    EXPECT_EQ(logged_id, 1u);
}

/* 40. Agent login wrong password */
TEST(AuthSuite, AgentLoginWrongPassword) {
    AuthTestFixture fix;
    UserRole role = ROLE_NONE;
    unsigned int logged_id = 0;
    int rc = chs_auth_login(&fix.state, "agent1", "WrongAgentPass", &role, &logged_id);
    EXPECT_EQ(rc, -1);
}

/* 41. Deactivated agent login blocked */
TEST(AuthSuite, DeactivatedAgentLoginBlocked) {
    AuthTestFixture fix;
    chs_manager_set_agent_active(&fix.state, 3, false);

    UserRole role = ROLE_NONE;
    unsigned int logged_id = 0;
    int rc = chs_auth_login(&fix.state, "agent3", "AgentPass123!", &role, &logged_id);
    EXPECT_EQ(rc, -2); /* Inactive account */
}

/* 42. Unique salt generation */
TEST(AuthSuite, UniqueSaltGeneration) {
    char salt1[64] = {0}, salt2[64] = {0};
    chs_generate_salt(salt1, sizeof(salt1));
    chs_generate_salt(salt2, sizeof(salt2));
    EXPECT_GT(strlen(salt1), 16u);
    EXPECT_GT(strlen(salt2), 16u);
    EXPECT_STRNE(salt1, salt2);
}

/* 43. Constant-time memcmp verification */
TEST(AuthSuite, ConstantTimeMemcmpVerification) {
    char a[] = "hash_string_1234567890";
    char b[] = "hash_string_1234567890";
    char c[] = "hash_string_1234567899";
    EXPECT_EQ(chs_constant_time_memcmp(a, b, strlen(a)), 0);
    EXPECT_NE(chs_constant_time_memcmp(a, c, strlen(a)), 0);
}
