#ifndef CHS_HISTORY_H
#define CHS_HISTORY_H

#include "chs_common.h"

#ifdef __cplusplus
extern "C" {
#endif

int chs_history_append(AppState *state, unsigned int complaint_id,
                       const char *event_type, const char *prev_value,
                       const char *new_value, const char *acting_user,
                       const char *notes);
int chs_history_get_for_complaint(AppState *state, unsigned int complaint_id,
                                  HistoryEvent ***events_out, size_t *count_out);

#ifdef __cplusplus
}
#endif

#endif /* CHS_HISTORY_H */
