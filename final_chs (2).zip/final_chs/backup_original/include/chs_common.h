#ifndef CHS_COMMON_H
#define CHS_COMMON_H

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include <time.h>
#include <pthread.h>

#ifdef __cplusplus
extern "C" {
#endif

#define MAX_USERNAME_LEN      32
#define MAX_NAME_LEN          64
#define MAX_EMAIL_LEN         64
#define MAX_PHONE_LEN         24
#define MAX_CATEGORY_LEN      32
#define MAX_DESC_LEN          256
#define MAX_REASON_LEN        128
#define MAX_NOTE_LEN          256
#define MAX_HASH_LEN          128
#define MAX_SALT_LEN          64
#define MAX_PATH_LEN          512

#define ESCALATION_TIMEOUT_SEC 86400
#define INITIAL_AGENT_COUNT   10

typedef enum {
    ROLE_NONE = 0,
    ROLE_CUSTOMER = 1,
    ROLE_AGENT = 2,
    ROLE_MANAGER = 3
} UserRole;

typedef enum {
    STATUS_OPEN = 0,
    STATUS_ASSIGNED = 1,
    STATUS_IN_PROGRESS = 2,
    STATUS_ESCALATED = 3,
    STATUS_RESOLVED = 4,
    STATUS_CLOSED = 5
} ComplaintStatus;

typedef enum {
    PRIORITY_LOW = 0,
    PRIORITY_MEDIUM = 1,
    PRIORITY_HIGH = 2,
    PRIORITY_CRITICAL = 3
} ComplaintPriority;

typedef struct Customer {
    unsigned int id;
    char username[MAX_USERNAME_LEN];
    char password_hash[MAX_HASH_LEN];
    char salt[MAX_SALT_LEN];
    char full_name[MAX_NAME_LEN];
    char email[MAX_EMAIL_LEN];
    char phone[MAX_PHONE_LEN];
    time_t created_at;
    struct Customer *next;
} Customer;

typedef struct Agent {
    unsigned int id;
    char username[MAX_USERNAME_LEN];
    char password_hash[MAX_HASH_LEN];
    char salt[MAX_SALT_LEN];
    char full_name[MAX_NAME_LEN];
    bool is_active;
    time_t created_at;
    time_t deactivated_at;
    struct Agent *next;
} Agent;

typedef struct Complaint {
    unsigned int id;
    unsigned int customer_id;
    char category[MAX_CATEGORY_LEN];
    char description[MAX_DESC_LEN];
    ComplaintPriority priority;
    ComplaintStatus status;
    unsigned int assigned_agent_id;
    time_t created_at;       /* Must never be reset */
    time_t updated_at;
    time_t assigned_at;
    bool is_escalated;
    time_t escalated_at;
    char escalation_reason[MAX_REASON_LEN];
    bool is_acknowledged;
    time_t acknowledged_at;
    char manager_notes[MAX_NOTE_LEN];
    char resolution_details[MAX_NOTE_LEN];
    time_t resolved_at;
    time_t closed_at;
    struct Complaint *next;
} Complaint;

typedef struct HistoryEvent {
    unsigned int complaint_id;
    unsigned int seq_num;
    time_t timestamp;
    char event_type[32];
    char prev_value[64];
    char new_value[64];
    char acting_user[MAX_USERNAME_LEN];
    char notes[MAX_NOTE_LEN];
    struct HistoryEvent *next;
} HistoryEvent;

typedef struct AppState {
    Customer *customers;
    Agent *agents;
    Complaint *complaints;
    HistoryEvent *history;

    pthread_mutex_t lock;
    pthread_cond_t cond;
    pthread_t monitor_thread;
    bool monitor_running;
    bool monitor_stop_req;
    int monitor_interval_sec;

    unsigned int next_complaint_id;
    unsigned int next_customer_id;
    unsigned int next_agent_id;
    unsigned int next_history_seq;

    char data_dir[MAX_PATH_LEN];
    char manager_username[MAX_USERNAME_LEN];
    char manager_password_hash[MAX_HASH_LEN];
    char manager_salt[MAX_SALT_LEN];

    time_t (*get_time_fn)(void);
} AppState;

/* Utility string helpers */
const char* status_to_string(ComplaintStatus st);
ComplaintStatus string_to_status(const char *str);
const char* priority_to_string(ComplaintPriority pr);
ComplaintPriority string_to_priority(const char *str);
bool is_valid_status_transition(ComplaintStatus current, ComplaintStatus next);

#ifdef __cplusplus
}
#endif

#endif /* CHS_COMMON_H */
