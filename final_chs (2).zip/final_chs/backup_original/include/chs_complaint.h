#ifndef CHS_COMPLAINT_H
#define CHS_COMPLAINT_H

#include "chs_common.h"

#ifdef __cplusplus
extern "C" {
#endif

int chs_complaint_register(AppState *state, unsigned int customer_id, const char *category,
                           const char *description, ComplaintPriority priority,
                           unsigned int *complaint_id_out);
Complaint* chs_complaint_find_by_id(AppState *state, unsigned int id);
int chs_complaint_update_status(AppState *state, unsigned int complaint_id, ComplaintStatus new_status,
                                const char *acting_user, const char *notes);

#ifdef __cplusplus
}
#endif

#endif /* CHS_COMPLAINT_H */
