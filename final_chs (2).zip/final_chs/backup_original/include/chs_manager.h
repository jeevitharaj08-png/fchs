#ifndef CHS_MANAGER_H
#define CHS_MANAGER_H

#include "chs_common.h"

#ifdef __cplusplus
extern "C" {
#endif

int chs_manager_init_default(AppState *state);
int chs_manager_add_agent(AppState *state, const char *username, const char *password, const char *full_name, unsigned int *new_id_out);
int chs_manager_set_agent_active(AppState *state, unsigned int agent_id, bool active);
int chs_manager_reassign_complaint(AppState *state, unsigned int complaint_id, unsigned int new_agent_id, const char *reason);
int chs_manager_acknowledge_escalation(AppState *state, unsigned int complaint_id, const char *manager_notes);
int chs_manager_close_complaint(AppState *state, unsigned int complaint_id);

#ifdef __cplusplus
}
#endif

#endif /* CHS_MANAGER_H */
