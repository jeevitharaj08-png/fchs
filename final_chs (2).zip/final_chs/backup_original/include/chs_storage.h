#ifndef CHS_STORAGE_H
#define CHS_STORAGE_H

#include "chs_common.h"

#ifdef __cplusplus
extern "C" {
#endif

int chs_storage_init(AppState *state, const char *data_dir);
int chs_storage_load_all(AppState *state);
int chs_storage_save_all(AppState *state);
int chs_storage_save_customers(AppState *state);
int chs_storage_save_agents(AppState *state);
int chs_storage_save_complaints(AppState *state);
int chs_storage_save_history(AppState *state);
int chs_storage_save_manager(AppState *state);
void chs_audit_log(AppState *state, const char *user, const char *action, const char *details);

#ifdef __cplusplus
}
#endif

#endif /* CHS_STORAGE_H */
