#ifndef CHS_REPORTS_H
#define CHS_REPORTS_H

#include "chs_common.h"

#ifdef __cplusplus
extern "C" {
#endif

void chs_report_complaint_summary(AppState *state, FILE *out);
void chs_report_priority(AppState *state, FILE *out);
void chs_report_agent_workload(AppState *state, FILE *out);
void chs_report_escalations(AppState *state, FILE *out);
void chs_report_customer_summary(AppState *state, FILE *out);
void chs_report_complaint_history(AppState *state, unsigned int complaint_id, FILE *out);

#ifdef __cplusplus
}
#endif

#endif /* CHS_REPORTS_H */
