#ifndef CHS_ASSIGNMENT_H
#define CHS_ASSIGNMENT_H

#include "chs_common.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Algorithm:
 * Evaluates each active agent in state->agents.
 * Calculates workload W = count of complaints assigned to agent with status != RESOLVED && status != CLOSED.
 * Selects agent with minimum W. Deterministic tie-breaker: minimum agent->id.
 * Time Complexity: O(A * C) worst case, or O(A) with indexed counter where A is agent count (10) and C is active complaints.
 */
int chs_assignment_auto_assign(AppState *state, Complaint *complaint);

#ifdef __cplusplus
}
#endif

#endif /* CHS_ASSIGNMENT_H */
