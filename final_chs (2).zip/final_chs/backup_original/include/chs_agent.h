#ifndef CHS_AGENT_H
#define CHS_AGENT_H

#include "chs_common.h"

#ifdef __cplusplus
extern "C" {
#endif

int chs_agent_init_defaults(AppState *state);
Agent* chs_agent_find_by_id(AppState *state, unsigned int id);
Agent* chs_agent_find_by_username(AppState *state, const char *username);
int chs_agent_calculate_workload(AppState *state, unsigned int agent_id);
int chs_agent_get_assigned_complaints(AppState *state, unsigned int agent_id, Complaint ***results_out, size_t *count_out);
int chs_agent_update_status(AppState *state, unsigned int agent_id, unsigned int complaint_id, ComplaintStatus new_status);
int chs_agent_add_note(AppState *state, unsigned int agent_id, unsigned int complaint_id, const char *note);
int chs_agent_change_priority(AppState *state, unsigned int agent_id, unsigned int complaint_id, ComplaintPriority new_priority);
int chs_agent_resolve(AppState *state, unsigned int agent_id, unsigned int complaint_id, const char *resolution_details);

#ifdef __cplusplus
}
#endif

#endif /* CHS_AGENT_H */
