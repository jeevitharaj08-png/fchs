#ifndef CHS_SECURITY_H
#define CHS_SECURITY_H

#include "chs_common.h"

#ifdef __cplusplus
extern "C" {
#endif

void chs_generate_salt(char *salt_out, size_t max_len);
int chs_hash_password(const char *password, const char *salt, char *hash_out, size_t max_len);
bool chs_verify_password(const char *password, const char *salt, const char *expected_hash);
int chs_constant_time_memcmp(const void *a, const void *b, size_t len);

void chs_sanitize_string(char *str, size_t max_len);
bool chs_validate_input(const char *str, size_t min_len, size_t max_len);
bool chs_validate_email(const char *email);
bool chs_validate_phone(const char *phone);

#ifdef __cplusplus
}
#endif

#endif /* CHS_SECURITY_H */
