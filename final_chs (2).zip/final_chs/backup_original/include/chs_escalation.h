#ifndef CHS_ESCALATION_H
#define CHS_ESCALATION_H

#include "chs_common.h"

#ifdef __cplusplus
extern "C" {
#endif

int chs_escalation_check_all(AppState *state);
int chs_escalation_trigger(AppState *state, unsigned int complaint_id, const char *reason, const char *acting_user);
int chs_escalation_start_monitor(AppState *state);
int chs_escalation_stop_monitor(AppState *state);

#ifdef __cplusplus
}
#endif

#endif /* CHS_ESCALATION_H */
