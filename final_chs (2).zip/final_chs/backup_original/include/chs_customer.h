#ifndef CHS_CUSTOMER_H
#define CHS_CUSTOMER_H

#include "chs_common.h"

#ifdef __cplusplus
extern "C" {
#endif

Customer* chs_customer_find_by_id(AppState *state, unsigned int id);
Customer* chs_customer_find_by_username(AppState *state, const char *username);
int chs_customer_get_complaints(AppState *state, unsigned int customer_id, Complaint ***results_out, size_t *count_out);
Complaint* chs_customer_get_complaint_by_id(AppState *state, unsigned int customer_id, unsigned int complaint_id);

#ifdef __cplusplus
}
#endif

#endif /* CHS_CUSTOMER_H */
