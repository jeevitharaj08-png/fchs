#ifndef CHS_TIME_H
#define CHS_TIME_H

#include "chs_common.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Injectable clock abstraction */
time_t chs_get_time(AppState *state);
void chs_set_mock_time(time_t t);
void chs_advance_mock_time(time_t seconds);
void chs_reset_mock_time(void);

/* Timestamp formatting and parsing */
void chs_format_iso(time_t t, char *buffer, size_t buf_len);
time_t chs_parse_iso(const char *buffer);
double chs_difftime(time_t end, time_t start);

#ifdef __cplusplus
}
#endif

#endif /* CHS_TIME_H */
