#ifndef CHS_AUTH_H
#define CHS_AUTH_H

#include "chs_common.h"

#ifdef __cplusplus
extern "C" {
#endif

int chs_auth_login(AppState *state, const char *username, const char *password, UserRole *role_out, unsigned int *user_id_out);
int chs_auth_register_customer(AppState *state, const char *username, const char *password,
                              const char *full_name, const char *email, const char *phone,
                              unsigned int *cust_id_out);

#ifdef __cplusplus
}
#endif

#endif /* CHS_AUTH_H */
