#ifndef CHS_SEARCH_H
#define CHS_SEARCH_H

#include "chs_common.h"

#ifdef __cplusplus
extern "C" {
#endif

int chs_search_complaints(AppState *state,
                          int customer_id,      /* -1 for any */
                          int agent_id,         /* -1 for any */
                          int status,           /* -1 for any */
                          int priority,         /* -1 for any */
                          Complaint ***results_out,
                          size_t *count_out);

#ifdef __cplusplus
}
#endif

#endif /* CHS_SEARCH_H */
