#ifndef CHS_H
#define CHS_H

#include "chs_common.h"
#include "chs_time.h"
#include "chs_security.h"
#include "chs_storage.h"
#include "chs_auth.h"
#include "chs_customer.h"
#include "chs_agent.h"
#include "chs_manager.h"
#include "chs_complaint.h"
#include "chs_assignment.h"
#include "chs_escalation.h"
#include "chs_history.h"
#include "chs_search.h"
#include "chs_reports.h"

#ifdef __cplusplus
extern "C" {
#endif

int chs_init(AppState *state, const char *data_dir);
void chs_cleanup(AppState *state);

#ifdef __cplusplus
}
#endif

#endif /* CHS_H */
