#include "chs.h"

int chs_report_print(AppState *state, ReportType type, unsigned int filter_id, FILE *out) {
    if (!state) return -1;
    if (!out) out = stdout;
    pthread_mutex_lock(&state->lock);

    if (type == REPORT_SUMMARY) {
        int tot = 0, st_c[6] = {0}, pr_c[4] = {0};
        for (Complaint *c = state->complaints; c; c = c->next) {
            tot++;
            if (c->status >= 0 && c->status <= 5) st_c[c->status]++;
            if (c->priority >= 0 && c->priority <= 3) pr_c[c->priority]++;
        }
        fprintf(out, "\n=== Complaint Summary ===\nTotal: %d | Open: %d | Assigned: %d | In Progress: %d | Escalated: %d | Resolved: %d | Closed: %d\n",
                tot, st_c[0], st_c[1], st_c[2], st_c[3], st_c[4], st_c[5]);
        fprintf(out, "Priorities: Low: %d | Medium: %d | High: %d | Critical: %d\n", pr_c[0], pr_c[1], pr_c[2], pr_c[3]);
    } else if (type == REPORT_PRIORITY) {
        fprintf(out, "\n=== Priority Breakdown ===\n");
        for (int p = 3; p >= 0; p--) {
            fprintf(out, "-- %s Priority --\n", priority_to_string((ComplaintPriority)p));
            for (Complaint *c = state->complaints; c; c = c->next)
                if (c->priority == (ComplaintPriority)p)
                    fprintf(out, " #%-4u | Status: %-12s | Cust: %-3u | Agent: %-2u | Desc: %s\n",
                            c->id, status_to_string(c->status), c->customer_id, c->assigned_agent_id, c->description);
        }
    } else if (type == REPORT_WORKLOAD) {
        fprintf(out, "\n=== Agent Workload ===\n");
        for (Agent *a = state->agents; a; a = a->next) {
            int wl = 0;
            for (Complaint *c = state->complaints; c; c = c->next)
                if (c->assigned_agent_id == a->id && c->status != STATUS_RESOLVED && c->status != STATUS_CLOSED) wl++;
            fprintf(out, " Agent #%-2u | %-16s | Status: %-8s | Active Load: %d\n", a->id, a->full_name, a->is_active ? "ACTIVE" : "INACTIVE", wl);
        }
    } else if (type == REPORT_ESCALATIONS) {
        fprintf(out, "\n=== Escalations Hub ===\n");
        for (Complaint *c = state->complaints; c; c = c->next) {
            if (c->status == STATUS_ESCALATED) {
                char ts[64]; chs_format_iso(c->escalated_at, ts, sizeof(ts));
                fprintf(out, " #%-4u | Escalated: %s | Reason: %s | Ack: %s\n", c->id, ts, c->escalation_reason, (c->acknowledged_at > 0) ? "YES" : "NO");
            }
        }
    } else if (type == REPORT_CUSTOMERS) {
        fprintf(out, "\n=== Registered Customers ===\n");
        for (Customer *c = state->customers; c; c = c->next) {
            char ts[64]; chs_format_iso(c->created_at, ts, sizeof(ts));
            fprintf(out, " ID: #%-3u | User: %-12s | Name: %-16s | Email: %-18s | Joined: %s\n", c->id, c->username, c->full_name, c->email, ts);
        }
    } else if (type == REPORT_HISTORY) {
        fprintf(out, "\n=== History for Complaint #%u ===\n", filter_id);
        for (HistoryEntry *h = state->history; h; h = h->next) {
            if (h->complaint_id == filter_id) {
                char ts[64]; chs_format_iso(h->timestamp, ts, sizeof(ts));
                fprintf(out, " [%s] Action: %-14s | Notes: %s\n", ts, h->event_type, h->notes);
            }
        }
    }
    pthread_mutex_unlock(&state->lock);
    return 0;
}
