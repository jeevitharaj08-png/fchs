#include "chs.h"

#if !defined(_WIN32)
extern time_t timegm(struct tm *tm);
#endif

static time_t g_mock_time = 0;
static bool g_use_mock_time = false;

time_t chs_get_time(AppState *state) {
    (void)state;
    return g_use_mock_time ? g_mock_time : time(NULL);
}

void chs_mock_time_ctl(int op, time_t val) {
    if (op == 0) { g_mock_time = val; g_use_mock_time = true; }
    else if (op == 1) { if (g_use_mock_time) g_mock_time += val; }
    else if (op == 2) { g_mock_time = 0; g_use_mock_time = false; }
}

int chs_format_iso(time_t t, char *buf, size_t len) {
    if (!buf || len < 21) return -1;
    struct tm tm_buf;
    if (!gmtime_r(&t, &tm_buf)) return -1;
    strftime(buf, len, "%Y-%m-%dT%H:%M:%SZ", &tm_buf);
    return 0;
}

time_t chs_parse_iso(const char *str) {
    if (!str || strlen(str) < 19) return 0;
    int y = 0, m = 0, d = 0, h = 0, min = 0, s = 0;
    char sep = 0;
    if (sscanf(str, "%4d-%2d-%2d%c%2d:%2d:%2d", &y, &m, &d, &sep, &h, &min, &s) != 7) return 0;
    if (sep != 'T' && sep != 't' && sep != ' ') return 0;
    if (y < 1970 || y > 2100 || m < 1 || m > 12 || h < 0 || h > 23 || min < 0 || min > 59 || s < 0 || s > 60) return 0;

    static const int dim[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    bool leap = ((y % 4 == 0 && y % 100 != 0) || (y % 400 == 0));
    int max_d = (m == 2 && leap) ? 29 : dim[m];
    if (d < 1 || d > max_d) return 0;

    struct tm tm_val;
    memset(&tm_val, 0, sizeof(tm_val));
    tm_val.tm_year = y - 1900;
    tm_val.tm_mon = m - 1;
    tm_val.tm_mday = d;
    tm_val.tm_hour = h;
    tm_val.tm_min = min;
    tm_val.tm_sec = s;
    tm_val.tm_isdst = 0;

#if defined(_WIN32)
    time_t epoch = _mkgmtime(&tm_val);
#else
    time_t epoch = timegm(&tm_val);
#endif
    if (epoch == (time_t)-1) return 0;

    const char *tz = str + 19;
    if (*tz == '+' || *tz == '-') {
        int tzh = 0, tzm = 0;
        if (sscanf(tz + 1, "%2d:%2d", &tzh, &tzm) == 2 || sscanf(tz + 1, "%2d%2d", &tzh, &tzm) == 2) {
            long off = (tzh * 3600L) + (tzm * 60L);
            epoch += (*tz == '+') ? -off : off;
        }
    }
    return epoch;
}
