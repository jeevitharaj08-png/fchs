#include "chs.h"

int chs_state_manage(AppState *state, int action, const char *data_dir) {
    if (!state) return -1;
    if (action == 0) {
        memset(state, 0, sizeof(AppState));
        strncpy(state->data_dir, (data_dir && strlen(data_dir) > 0) ? data_dir : "data", sizeof(state->data_dir) - 1);
        pthread_mutex_init(&state->lock, NULL);
        state->next_complaint_id = 1001; state->next_customer_id = 101;
        state->next_agent_id = INITIAL_AGENT_COUNT + 1; state->monitor_interval_sec = 1;
        chs_storage_sync(state, 1);
        if (strlen(state->manager.username) == 0) {
            strncpy(state->manager.username, "manager", sizeof(state->manager.username) - 1);
            strncpy(state->manager.full_name, "System Manager", sizeof(state->manager.full_name) - 1);
            state->manager.created_at = chs_get_time(state);
            chs_generate_salt(state->manager.salt, sizeof(state->manager.salt));
            chs_hash_password("ManagerPass123!", state->manager.salt, state->manager.password_hash, sizeof(state->manager.password_hash));
        }
        if (!state->agents) {
            for (unsigned int i = 1; i <= INITIAL_AGENT_COUNT; i++) {
                Agent *a = (Agent *)calloc(1, sizeof(Agent));
                if (!a) break;
                a->id = i; a->is_active = true; a->created_at = chs_get_time(state);
                snprintf(a->username, sizeof(a->username), "agent%u", i);
                snprintf(a->full_name, sizeof(a->full_name), "Agent %u", i);
                chs_generate_salt(a->salt, sizeof(a->salt));
                chs_hash_password("AgentPass123!", a->salt, a->password_hash, sizeof(a->password_hash));
                Agent **tail = &state->agents; while (*tail) tail = &(*tail)->next; *tail = a;
            }
        }
        chs_storage_sync(state, 0); return 0;
    }
    chs_escalation_monitor(state, 0);
    pthread_mutex_lock(&state->lock);
    while (state->agents) { Agent *n = state->agents->next; free(state->agents); state->agents = n; }
    while (state->customers) { Customer *n = state->customers->next; free(state->customers); state->customers = n; }
    while (state->complaints) { Complaint *n = state->complaints->next; free(state->complaints); state->complaints = n; }
    while (state->history) { HistoryEvent *n = state->history->next; free(state->history); state->history = n; }
    pthread_mutex_unlock(&state->lock);
    pthread_mutex_destroy(&state->lock);
    return 0;
}

void* chs_find_user(AppState *state, UserRole role, unsigned int id, const char *username) {
    if (!state) return NULL;
    pthread_mutex_lock(&state->lock);
    if ((role == ROLE_MANAGER || role == ROLE_NONE) && username && strcmp(state->manager.username, username) == 0) {
        pthread_mutex_unlock(&state->lock); return &state->manager;
    }
    if (role == ROLE_AGENT || role == ROLE_NONE) {
        for (Agent *a = state->agents; a; a = a->next)
            if ((id > 0 && a->id == id) || (username && strcmp(a->username, username) == 0)) { pthread_mutex_unlock(&state->lock); return a; }
    }
    if (role == ROLE_CUSTOMER || role == ROLE_NONE) {
        for (Customer *c = state->customers; c; c = c->next)
            if ((id > 0 && c->id == id) || (username && strcmp(c->username, username) == 0)) { pthread_mutex_unlock(&state->lock); return c; }
    }
    pthread_mutex_unlock(&state->lock); return NULL;
}

int chs_auth_login(AppState *state, const char *u, const char *p, UserRole *role, unsigned int *uid) {
    if (!state || !u || !p || !role || !uid) return -1;
    pthread_mutex_lock(&state->lock);
    char h[65];
    if (strcmp(state->manager.username, u) == 0) {
        chs_hash_password(p, state->manager.salt, h, sizeof(h));
        if (chs_constant_time_memcmp(h, state->manager.password_hash, 64) == 0) {
            *role = ROLE_MANAGER; *uid = 0; pthread_mutex_unlock(&state->lock); return 0;
        }
    }
    for (Agent *a = state->agents; a; a = a->next) {
        if (strcmp(a->username, u) == 0) {
            if (!a->is_active) { pthread_mutex_unlock(&state->lock); return -2; }
            chs_hash_password(p, a->salt, h, sizeof(h));
            if (chs_constant_time_memcmp(h, a->password_hash, 64) == 0) {
                *role = ROLE_AGENT; *uid = a->id; pthread_mutex_unlock(&state->lock); return 0;
            }
        }
    }
    for (Customer *c = state->customers; c; c = c->next) {
        if (strcmp(c->username, u) == 0) {
            chs_hash_password(p, c->salt, h, sizeof(h));
            if (chs_constant_time_memcmp(h, c->password_hash, 64) == 0) {
                *role = ROLE_CUSTOMER; *uid = c->id; pthread_mutex_unlock(&state->lock); return 0;
            }
        }
    }
    pthread_mutex_unlock(&state->lock); return -1;
}

int chs_auth_register_customer(AppState *state, const char *u, const char *p, const char *fn, const char *em, const char *ph, unsigned int *id) {
    if (!state || !u || !p || !fn || !em || !ph) return -1;
    size_t ulen = strlen(u), plen = strlen(p), elen = strlen(em), phlen = strlen(ph);
    if (ulen < 3 || ulen >= MAX_USERNAME_LEN || plen < 6 || elen < 5 || elen >= MAX_EMAIL_LEN || phlen < 7 || phlen >= MAX_PHONE_LEN) return -2;
    const char *at = strchr(em, '@');
    if (!at || at == em || !strchr(at + 2, '.')) return -2;
    for (size_t i = 0; i < phlen; i++)
        if (!isdigit((unsigned char)ph[i]) && ph[i] != '+' && ph[i] != '-' && ph[i] != ' ' && ph[i] != '(' && ph[i] != ')') return -2;
    if (chs_find_user(state, ROLE_NONE, 0, u) != NULL) return -3;

    pthread_mutex_lock(&state->lock);
    Customer *c = (Customer *)calloc(1, sizeof(Customer));
    if (!c) { pthread_mutex_unlock(&state->lock); return -1; }
    c->id = state->next_customer_id++;
    strncpy(c->username, u, sizeof(c->username) - 1); strncpy(c->full_name, fn, sizeof(c->full_name) - 1);
    strncpy(c->email, em, sizeof(c->email) - 1); strncpy(c->phone, ph, sizeof(c->phone) - 1);
    c->created_at = chs_get_time(state);
    chs_generate_salt(c->salt, sizeof(c->salt));
    chs_hash_password(p, c->salt, c->password_hash, sizeof(c->password_hash));
    c->next = state->customers; state->customers = c;
    if (id) *id = c->id;
    chs_storage_sync(state, 0); pthread_mutex_unlock(&state->lock); return 0;
}

int chs_manager_add_agent(AppState *state, const char *u, const char *p, const char *fn, unsigned int *new_id) {
    if (!state || !u || !p || !fn) return -1;
    if (strlen(u) < 3 || strlen(p) < 6) return -2;
    if (chs_find_user(state, ROLE_NONE, 0, u) != NULL) return -3;
    pthread_mutex_lock(&state->lock);
    Agent *a = (Agent *)calloc(1, sizeof(Agent));
    if (!a) { pthread_mutex_unlock(&state->lock); return -1; }
    a->id = state->next_agent_id++;
    strncpy(a->username, u, sizeof(a->username) - 1); strncpy(a->full_name, fn, sizeof(a->full_name) - 1);
    a->is_active = true; a->created_at = chs_get_time(state);
    chs_generate_salt(a->salt, sizeof(a->salt));
    chs_hash_password(p, a->salt, a->password_hash, sizeof(a->password_hash));
    Agent **tail = &state->agents; while (*tail) tail = &(*tail)->next; *tail = a;
    if (new_id) *new_id = a->id;
    chs_storage_sync(state, 0); pthread_mutex_unlock(&state->lock); return 0;
}

int chs_manager_set_agent_active(AppState *state, unsigned int agent_id, bool is_active) {
    if (!state) return -1;
    pthread_mutex_lock(&state->lock);
    for (Agent *a = state->agents; a; a = a->next) {
        if (a->id == agent_id) {
            a->is_active = is_active; if (!is_active) a->deactivated_at = chs_get_time(state);
            chs_storage_sync(state, 0); pthread_mutex_unlock(&state->lock); return 0;
        }
    }
    pthread_mutex_unlock(&state->lock); return -1;
}

int chs_agent_calculate_workload(AppState *state, unsigned int agent_id) {
    if (!state) return 0;
    int wl = 0;
    for (Complaint *c = state->complaints; c; c = c->next)
        if (c->assigned_agent_id == agent_id && c->status != STATUS_RESOLVED && c->status != STATUS_CLOSED) wl++;
    return wl;
}
