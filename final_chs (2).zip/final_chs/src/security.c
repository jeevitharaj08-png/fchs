#include "chs.h"

#define ROTR(x, n) (((x) >> (n)) | ((x) << (32 - (n))))
#define CH(x, y, z) (((x) & (y)) ^ (~(x) & (z)))
#define MAJ(x, y, z) (((x) & (y)) ^ ((x) & (z)) ^ ((y) & (z)))
#define EP0(x) (ROTR(x, 2) ^ ROTR(x, 13) ^ ROTR(x, 22))
#define EP1(x) (ROTR(x, 6) ^ ROTR(x, 11) ^ ROTR(x, 25))
#define SIG0(x) (ROTR(x, 7) ^ ROTR(x, 18) ^ ((x) >> 3))
#define SIG1(x) (ROTR(x, 17) ^ ROTR(x, 19) ^ ((x) >> 10))

static const uint32_t K[64] = {
    0x428a2f98UL,0x71374491UL,0xb5c0fbcfUL,0xe9b5dba5UL,0x3956c25bUL,0x59f111f1UL,0x923f82a4UL,0xab1c5ed5UL,0xd807aa98UL,0x12835b01UL,0x243185beUL,0x550c7dc3UL,0x72be5d74UL,0x80deb1feUL,0x9bdc06a7UL,0xc19bf174UL,
    0xe49b69c1UL,0xefbe4786UL,0x0fc19dc6UL,0x240ca1ccUL,0x2de92c6fUL,0x4a7484aaUL,0x5cb0a9dcUL,0x76f988daUL,0x983e5152UL,0xa831c66dUL,0xb00327c8UL,0xbf597fc7UL,0xc6e00bf3UL,0xd5a79147UL,0x06ca6351UL,0x14292967UL,
    0x27b70a85UL,0x2e1b2138UL,0x4d2c6dfcUL,0x53380d13UL,0x650a7354UL,0x766a0abbUL,0x81c2c92eUL,0x92722c85UL,0xa2bfe8a1UL,0xa81a664bUL,0xc24b8b70UL,0xc76c51a3UL,0xd192e819UL,0xd6990624UL,0xf40e3585UL,0x106aa070UL,
    0x19a4c116UL,0x1e376c08UL,0x2748774cUL,0x34b0bcb5UL,0x391c0cb3UL,0x4ed8aa4aUL,0x5b9cca4fUL,0x682e6ff3UL,0x748f82eeUL,0x78a5636fUL,0x84c87814UL,0x8cc70208UL,0x90befffaUL,0xa4506cebUL,0xbef9a3f7UL,0xc67178f2UL
};

void chs_sha256(const uint8_t *data, size_t len, uint8_t out[32]) {
    uint32_t s[8] = {0x6a09e667UL,0xbb67ae85UL,0x3c6ef372UL,0xa54ff53aUL,0x510e527fUL,0x9b05688cUL,0x1f83d9abUL,0x5be0cd19UL};
    size_t rem = len % 64, pad_len = (rem < 56) ? (56 - rem) : (120 - rem), total = len + pad_len + 8;
    uint8_t *msg = (uint8_t *)malloc(total);
    if (!msg) return;
    if (len > 0) memcpy(msg, data, len);
    msg[len] = 0x80; memset(msg + len + 1, 0, pad_len - 1);
    uint64_t bits = (uint64_t)len * 8;
    for (int i = 0; i < 8; i++) msg[total - 1 - i] = (uint8_t)(bits >> (i * 8));

    for (size_t chunk = 0; chunk < total; chunk += 64) {
        uint32_t w[64];
        for (int i = 0, j = 0; i < 16; i++, j += 4)
            w[i] = ((uint32_t)msg[chunk + j] << 24) | ((uint32_t)msg[chunk + j + 1] << 16) | ((uint32_t)msg[chunk + j + 2] << 8) | (uint32_t)msg[chunk + j + 3];
        for (int i = 16; i < 64; i++) w[i] = SIG1(w[i - 2]) + w[i - 7] + SIG0(w[i - 15]) + w[i - 16];
        uint32_t a = s[0], b = s[1], c = s[2], d = s[3], e = s[4], f = s[5], g = s[6], h = s[7];
        for (int i = 0; i < 64; i++) {
            uint32_t t1 = h + EP1(e) + CH(e, f, g) + K[i] + w[i], t2 = EP0(a) + MAJ(a, b, c);
            h = g; g = f; f = e; e = d + t1; d = c; c = b; b = a; a = t1 + t2;
        }
        s[0] += a; s[1] += b; s[2] += c; s[3] += d; s[4] += e; s[5] += f; s[6] += g; s[7] += h;
    }
    free(msg);
    for (int i = 0; i < 8; i++) {
        out[i * 4] = (uint8_t)(s[i] >> 24); out[i * 4 + 1] = (uint8_t)(s[i] >> 16);
        out[i * 4 + 2] = (uint8_t)(s[i] >> 8); out[i * 4 + 3] = (uint8_t)(s[i]);
    }
}

static void hmac_sha256(const uint8_t *k, size_t klen, const uint8_t *d, size_t dlen, uint8_t out[32]) {
    uint8_t key[64] = {0}, ipad[64 + 128], opad[64 + 32], inner[32];
    if (klen > 64) chs_sha256(k, klen, key); else memcpy(key, k, klen);
    for (int i = 0; i < 64; i++) { ipad[i] = key[i] ^ 0x36; opad[i] = key[i] ^ 0x5c; }
    memcpy(ipad + 64, d, dlen); chs_sha256(ipad, 64 + dlen, inner);
    memcpy(opad + 64, inner, 32); chs_sha256(opad, 64 + 32, out);
}

int chs_hash_password(const char *pass, const char *salt, char *hash_out, size_t max_len) {
    if (!pass || !salt || !hash_out || max_len < 65) return -1;
    size_t slen = strlen(salt);
    uint8_t swc[128];
    if (slen + 4 > sizeof(swc)) return -1;
    memcpy(swc, salt, slen);
    swc[slen] = 0; swc[slen + 1] = 0; swc[slen + 2] = 0; swc[slen + 3] = 1;
    uint8_t u[32], t[32];
    hmac_sha256((const uint8_t *)pass, strlen(pass), swc, slen + 4, u);
    memcpy(t, u, 32);
    for (int iter = 1; iter < 2000; iter++) {
        hmac_sha256((const uint8_t *)pass, strlen(pass), u, 32, u);
        for (int i = 0; i < 32; i++) t[i] ^= u[i];
    }
    static const char hex[] = "0123456789abcdef";
    for (int i = 0; i < 32; i++) { hash_out[i * 2] = hex[(t[i] >> 4) & 0x0F]; hash_out[i * 2 + 1] = hex[t[i] & 0x0F]; }
    hash_out[64] = '\0';
    return 0;
}

void chs_generate_salt(char *salt_out, size_t max_len) {
    if (!salt_out || max_len < 17) return;
    uint8_t r[16];
    FILE *f = fopen("/dev/urandom", "rb");
    if (!f || fread(r, 1, 16, f) != 16) {
        static unsigned int seed = 54321;
        seed += (unsigned int)time(NULL) * 1103515245U + 12345U;
        for (int i = 0; i < 16; i++) { seed = seed * 1103515245U + 12345U; r[i] = (uint8_t)(seed >> 16); }
    }
    if (f) fclose(f);
    static const char hex[] = "0123456789abcdef";
    for (int i = 0; i < 16 && (size_t)(i * 2 + 1) < max_len; i++) {
        salt_out[i * 2] = hex[(r[i] >> 4) & 0x0F]; salt_out[i * 2 + 1] = hex[r[i] & 0x0F];
    }
    salt_out[32 < max_len ? 32 : max_len - 1] = '\0';
}

int chs_constant_time_memcmp(const void *a, const void *b, size_t len) {
    const uint8_t *ua = (const uint8_t *)a, *ub = (const uint8_t *)b;
    uint8_t res = 0;
    for (size_t i = 0; i < len; i++) res |= (ua[i] ^ ub[i]);
    return (res != 0);
}
