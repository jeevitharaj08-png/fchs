#include "chs.h"

int chs_storage_sync(AppState *state, int mode) {
    if (!state) return -1;
    char path[160], tmp[180], line[1024];
    FILE *f;
    #define DO_SAVE(fn, code) do { \
        snprintf(path, sizeof(path), "%s/" fn, state->data_dir); snprintf(tmp, sizeof(tmp), "%s.tmp", path); \
        if ((f = fopen(tmp, "w"))) { code; fclose(f); remove(path); rename(tmp, path); } \
    } while(0)

    if (mode == 0) {
        DO_SAVE("manager.txt", fprintf(f, "%s|%s|%s\n", state->manager.username, state->manager.password_hash, state->manager.salt));
        DO_SAVE("agents.txt", for (Agent *a = state->agents; a; a = a->next)
                fprintf(f, "%u|%s|%s|%s|%s|%d|%ld|%ld\n", a->id, a->username, a->password_hash,
                        a->salt, a->full_name, a->is_active ? 1 : 0, (long)a->created_at, (long)a->deactivated_at));
        DO_SAVE("customers.txt", for (Customer *c = state->customers; c; c = c->next)
                fprintf(f, "%u|%s|%s|%s|%s|%s|%s|%ld\n", c->id, c->username, c->password_hash,
                        c->salt, c->full_name, c->email, c->phone, (long)c->created_at));
        DO_SAVE("complaints.txt", for (Complaint *c = state->complaints; c; c = c->next)
                fprintf(f, "%u|%u|%s|%s|%s|%s|%u|%ld|%ld|%ld|%d|%ld|%s|%d|%ld|%s|%s|%ld|%ld\n",
                        c->id, c->customer_id, c->category, c->description,
                        priority_to_string(c->priority), status_to_string(c->status),
                        c->assigned_agent_id, (long)c->created_at, (long)c->updated_at, (long)c->assigned_at,
                        c->is_escalated ? 1 : 0, (long)c->escalated_at, c->escalation_reason,
                        c->is_acknowledged ? 1 : 0, (long)c->acknowledged_at,
                        c->manager_notes, c->resolution_details, (long)c->resolved_at, (long)c->closed_at));
        DO_SAVE("history.txt", for (HistoryEvent *h = state->history; h; h = h->next)
                fprintf(f, "%u|%u|%ld|%s|%s|%s|%s|%s\n", h->complaint_id, h->seq_num, (long)h->timestamp,
                        h->event_type, h->prev_value, h->new_value, h->acting_user, h->notes));
        return 0;
    }

    #define OPEN_R(fn) snprintf(path, sizeof(path), "%s/" fn, state->data_dir); if ((f = fopen(path, "r")))
    OPEN_R("manager.txt") {
        if (fgets(line, sizeof(line), f))
            sscanf(line, "%31[^|]|%127[^|]|%63[^\r\n]", state->manager.username, state->manager.password_hash, state->manager.salt);
        fclose(f);
    }
    OPEN_R("agents.txt") {
        Agent **tail = &state->agents;
        while (fgets(line, sizeof(line), f)) {
            Agent *a = (Agent *)calloc(1, sizeof(Agent));
            int act = 1; long tc = 0, td = 0;
            if (sscanf(line, "%u|%31[^|]|%127[^|]|%63[^|]|%63[^|]|%d|%ld|%ld", &a->id, a->username,
                       a->password_hash, a->salt, a->full_name, &act, &tc, &td) >= 6) {
                a->is_active = (act != 0); a->created_at = (time_t)tc; a->deactivated_at = (time_t)td;
                if (a->id >= state->next_agent_id) state->next_agent_id = a->id + 1;
                *tail = a; tail = &a->next;
            } else free(a);
        }
        fclose(f);
    }
    OPEN_R("customers.txt") {
        Customer **tail = &state->customers;
        while (fgets(line, sizeof(line), f)) {
            Customer *c = (Customer *)calloc(1, sizeof(Customer));
            long tc = 0;
            if (sscanf(line, "%u|%31[^|]|%127[^|]|%63[^|]|%63[^|]|%63[^|]|%23[^|]|%ld", &c->id, c->username,
                       c->password_hash, c->salt, c->full_name, c->email, c->phone, &tc) >= 7) {
                c->created_at = (time_t)tc;
                if (c->id >= state->next_customer_id) state->next_customer_id = c->id + 1;
                *tail = c; tail = &c->next;
            } else free(c);
        }
        fclose(f);
    }
    OPEN_R("complaints.txt") {
        Complaint **tail = &state->complaints;
        while (fgets(line, sizeof(line), f)) {
            Complaint *c = (Complaint *)calloc(1, sizeof(Complaint));
            if (!c) continue;
            char *tok = strtok(line, "|\r\n"); int field = 0;
            while (tok) {
                switch (field++) {
                    case 0: c->id = (unsigned int)atoi(tok); break;
                    case 1: c->customer_id = (unsigned int)atoi(tok); break;
                    case 2: strncpy(c->category, tok, sizeof(c->category)-1); break;
                    case 3: strncpy(c->description, tok, sizeof(c->description)-1); break;
                    case 4: c->priority = string_to_priority(tok); break;
                    case 5: c->status = string_to_status(tok); break;
                    case 6: c->assigned_agent_id = (unsigned int)atoi(tok); break;
                    case 7: c->created_at = (time_t)atol(tok); break;
                    case 8: c->updated_at = (time_t)atol(tok); break;
                    case 9: c->assigned_at = (time_t)atol(tok); break;
                    case 10: c->is_escalated = (atoi(tok) != 0); break;
                    case 11: c->escalated_at = (time_t)atol(tok); break;
                    case 12: strncpy(c->escalation_reason, tok, sizeof(c->escalation_reason)-1); break;
                    case 13: c->is_acknowledged = (atoi(tok) != 0); break;
                    case 14: c->acknowledged_at = (time_t)atol(tok); break;
                    case 15: strncpy(c->manager_notes, tok, sizeof(c->manager_notes)-1); break;
                    case 16: strncpy(c->resolution_details, tok, sizeof(c->resolution_details)-1); break;
                    case 17: c->resolved_at = (time_t)atol(tok); break;
                    case 18: c->closed_at = (time_t)atol(tok); break;
                }
                tok = strtok(NULL, "|\r\n");
            }
            if (field >= 7) {
                if (c->id >= state->next_complaint_id) state->next_complaint_id = c->id + 1;
                *tail = c; tail = &c->next;
            } else free(c);
        }
        fclose(f);
    }
    OPEN_R("history.txt") {
        HistoryEvent **tail = &state->history;
        while (fgets(line, sizeof(line), f)) {
            HistoryEvent *h = (HistoryEvent *)calloc(1, sizeof(HistoryEvent));
            if (!h) continue;
            char *tok = strtok(line, "|\r\n"); int field = 0;
            while (tok) {
                switch (field++) {
                    case 0: h->complaint_id = (unsigned int)atoi(tok); break;
                    case 1: h->seq_num = (unsigned int)atoi(tok); break;
                    case 2: h->timestamp = (time_t)atol(tok); break;
                    case 3: strncpy(h->event_type, tok, sizeof(h->event_type)-1); break;
                    case 4: strncpy(h->prev_value, tok, sizeof(h->prev_value)-1); break;
                    case 5: strncpy(h->new_value, tok, sizeof(h->new_value)-1); break;
                    case 6: strncpy(h->acting_user, tok, sizeof(h->acting_user)-1); break;
                    case 7: strncpy(h->notes, tok, sizeof(h->notes)-1); break;
                }
                tok = strtok(NULL, "|\r\n");
            }
            if (field >= 4) { *tail = h; tail = &h->next; } else free(h);
        }
        fclose(f);
    }
    return 0;
}
