#include "chs.h"

const char* chs_enum_to_str(int which, int val) {
    static const char *s[] = {"OPEN", "ASSIGNED", "IN_PROGRESS", "ESCALATED", "RESOLVED", "CLOSED"};
    static const char *p[] = {"LOW", "MEDIUM", "HIGH", "CRITICAL"};
    if (which == 0) return (val >= 0 && val <= 5) ? s[val] : "UNKNOWN";
    return (val >= 0 && val <= 3) ? p[val] : "UNKNOWN";
}

int chs_str_to_enum(int which, const char *str) {
    if (!str) return -1;
    if (which == 0) {
        if (!strcmp(str, "OPEN")) return STATUS_OPEN;
        if (!strcmp(str, "ASSIGNED")) return STATUS_ASSIGNED;
        if (!strcmp(str, "IN_PROGRESS")) return STATUS_IN_PROGRESS;
        if (!strcmp(str, "ESCALATED")) return STATUS_ESCALATED;
        if (!strcmp(str, "RESOLVED")) return STATUS_RESOLVED;
        if (!strcmp(str, "CLOSED")) return STATUS_CLOSED;
    } else {
        if (!strcmp(str, "LOW")) return PRIORITY_LOW;
        if (!strcmp(str, "MEDIUM")) return PRIORITY_MEDIUM;
        if (!strcmp(str, "HIGH")) return PRIORITY_HIGH;
        if (!strcmp(str, "CRITICAL")) return PRIORITY_CRITICAL;
    }
    return -1;
}

int chs_assignment_auto_assign(AppState *state, unsigned int *agent_id_out) {
    if (!state || !agent_id_out) return -1;
    unsigned int best_aid = 0; int min_wl = 999999;
    for (Agent *a = state->agents; a; a = a->next) {
        if (!a->is_active) continue;
        int wl = chs_agent_calculate_workload(state, a->id);
        if (wl < min_wl || (wl == min_wl && (best_aid == 0 || a->id < best_aid))) { min_wl = wl; best_aid = a->id; }
    }
    *agent_id_out = best_aid;
    return 0;
}

Complaint* chs_complaint_find_by_id(AppState *state, unsigned int id) {
    if (!state) return NULL;
    pthread_mutex_lock(&state->lock);
    for (Complaint *c = state->complaints; c; c = c->next) {
        if (c->id == id) { pthread_mutex_unlock(&state->lock); return c; }
    }
    pthread_mutex_unlock(&state->lock);
    return NULL;
}

int chs_complaint_register(AppState *state, unsigned int cust_id, const char *cat, const char *desc, ComplaintPriority pr, unsigned int *new_id) {
    if (!state || !cat || !desc) return -1;
    if (chs_find_user(state, ROLE_CUSTOMER, cust_id, NULL) == NULL) return -3;
    pthread_mutex_lock(&state->lock);
    Complaint *c = (Complaint *)calloc(1, sizeof(Complaint));
    if (!c) { pthread_mutex_unlock(&state->lock); return -1; }
    c->id = state->next_complaint_id++; c->customer_id = cust_id;
    strncpy(c->category, cat, sizeof(c->category) - 1); strncpy(c->description, desc, sizeof(c->description) - 1);
    c->priority = pr;
    unsigned int aid = 0;
    chs_assignment_auto_assign(state, &aid);
    c->assigned_agent_id = aid; c->status = (aid > 0) ? STATUS_ASSIGNED : STATUS_OPEN;
    time_t now = chs_get_time(state);
    c->created_at = now; c->updated_at = now; c->assigned_at = (aid > 0) ? now : 0;
    Complaint **tail = &state->complaints; while (*tail) tail = &(*tail)->next; *tail = c;
    chs_history_append(state, c->id, "REGISTERED", "-", "-", "system", "Created");
    if (pr == PRIORITY_CRITICAL) {
        c->status = STATUS_ESCALATED; c->is_escalated = true; c->escalated_at = now; c->status_changed_at = now;
        snprintf(c->escalation_reason, sizeof(c->escalation_reason), "CRITICAL priority auto-escalation");
        chs_history_append(state, c->id, "ESCALATED", "-", "ESCALATED", "system", c->escalation_reason);
    }
    if (new_id) *new_id = c->id;
    chs_storage_sync(state, 0);
    pthread_mutex_unlock(&state->lock);
    return 0;
}

int chs_complaint_modify(AppState *state, ComplaintAction action, unsigned int cid, unsigned int actor_id, const char *detail, int val) {
    if (!state) return -1;
    pthread_mutex_lock(&state->lock);
    Complaint *c = NULL;
    for (Complaint *curr = state->complaints; curr; curr = curr->next) { if (curr->id == cid) { c = curr; break; } }
    if (!c) { pthread_mutex_unlock(&state->lock); return -1; }
    time_t now = chs_get_time(state);

    if (action == ACT_STATUS) {
        if (actor_id > 0 && c->assigned_agent_id != actor_id) { pthread_mutex_unlock(&state->lock); return -1; }
        if (!is_valid_status_transition(c->status, (ComplaintStatus)val)) { pthread_mutex_unlock(&state->lock); return -1; }
        const char *prev_s = status_to_string(c->status);
        c->status = (ComplaintStatus)val; c->status_changed_at = now; c->updated_at = now;
        chs_history_append(state, cid, "STATUS_CHANGE", prev_s, status_to_string(c->status), actor_id > 0 ? "agent" : "system", detail ? detail : "Status updated");
    } else if (action == ACT_PRIORITY) {
        if (actor_id > 0 && c->assigned_agent_id != actor_id) { pthread_mutex_unlock(&state->lock); return -1; }
        const char *prev_p = priority_to_string(c->priority);
        c->priority = (ComplaintPriority)val; c->priority_changed_at = now; c->updated_at = now;
        chs_history_append(state, cid, "PRIORITY_CHANGE", prev_p, priority_to_string(c->priority), actor_id > 0 ? "agent" : "system", "Priority changed");
        if (c->priority == PRIORITY_CRITICAL && c->status != STATUS_ESCALATED && c->status != STATUS_RESOLVED && c->status != STATUS_CLOSED) {
            c->status = STATUS_ESCALATED; c->is_escalated = true; c->escalated_at = now; c->status_changed_at = now;
            snprintf(c->escalation_reason, sizeof(c->escalation_reason), "CRITICAL priority auto-escalation");
            chs_history_append(state, cid, "ESCALATED", "-", "ESCALATED", "system", c->escalation_reason);
        }
    } else if (action == ACT_NOTE) {
        if (actor_id > 0 && c->assigned_agent_id != actor_id) { pthread_mutex_unlock(&state->lock); return -1; }
        c->updated_at = now; chs_history_append(state, cid, "NOTE_ADDED", "-", "-", "agent", detail ? detail : "");
    } else if (action == ACT_RESOLVE) {
        if (actor_id > 0 && c->assigned_agent_id != actor_id) { pthread_mutex_unlock(&state->lock); return -1; }
        if (!detail || strlen(detail) == 0) { pthread_mutex_unlock(&state->lock); return -1; }
        c->status = STATUS_RESOLVED; c->resolved_at = now; c->status_changed_at = now; c->updated_at = now;
        strncpy(c->resolution_details, detail, sizeof(c->resolution_details) - 1);
        chs_history_append(state, cid, "RESOLVED", "-", "RESOLVED", "agent", detail);
    } else if (action == ACT_REASSIGN) {
        if (!chs_find_user(state, ROLE_AGENT, (unsigned int)val, NULL)) { pthread_mutex_unlock(&state->lock); return -1; }
        c->assigned_agent_id = (unsigned int)val; c->reassigned_at = now; c->updated_at = now;
        chs_history_append(state, cid, "REASSIGNED", "-", "-", "manager", detail ? detail : "Reassigned by manager");
    } else if (action == ACT_ACKNOWLEDGE) {
        c->is_acknowledged = true; c->acknowledged_at = now; c->updated_at = now;
        if (detail) strncpy(c->manager_notes, detail, sizeof(c->manager_notes) - 1);
        chs_history_append(state, cid, "ACKNOWLEDGED", "-", "-", "manager", detail ? detail : "Acknowledged by manager");
    } else if (action == ACT_CLOSE) {
        if (c->status != STATUS_RESOLVED || strlen(c->resolution_details) == 0) { pthread_mutex_unlock(&state->lock); return -1; }
        c->status = STATUS_CLOSED; c->closed_at = now; c->status_changed_at = now; c->updated_at = now;
        chs_history_append(state, cid, "CLOSED", "RESOLVED", "CLOSED", "manager", "Complaint officially closed");
    }
    chs_storage_sync(state, 0);
    pthread_mutex_unlock(&state->lock);
    return 0;
}

int chs_search_complaints(AppState *state, int cust_id, int agent_id, int status, int priority, Complaint ***results_out, size_t *count_out) {
    if (!state || !results_out || !count_out) return -1;
    *results_out = NULL; *count_out = 0;
    pthread_mutex_lock(&state->lock);
    size_t count = 0;
    for (Complaint *c = state->complaints; c; c = c->next) {
        if ((cust_id < 0 || (int)c->customer_id == cust_id) && (agent_id < 0 || (int)c->assigned_agent_id == agent_id) &&
            (status < 0 || (int)c->status == status) && (priority < 0 || (int)c->priority == priority)) count++;
    }
    if (count == 0) { pthread_mutex_unlock(&state->lock); return 0; }
    Complaint **arr = (Complaint **)calloc(count, sizeof(Complaint *));
    if (!arr) { pthread_mutex_unlock(&state->lock); return -1; }
    size_t idx = 0;
    for (Complaint *c = state->complaints; c && idx < count; c = c->next) {
        if ((cust_id < 0 || (int)c->customer_id == cust_id) && (agent_id < 0 || (int)c->assigned_agent_id == agent_id) &&
            (status < 0 || (int)c->status == status) && (priority < 0 || (int)c->priority == priority)) arr[idx++] = c;
    }
    *results_out = arr; *count_out = count;
    pthread_mutex_unlock(&state->lock);
    return 0;
}

int chs_history_op(AppState *state, int op, unsigned int cmp_id, const char *ev, const char *pv, const char *nv, const char *u, const char *n, HistoryEvent ***results_out, size_t *count_out) {
    if (!state) return -1;
    if (op == 0) {
        HistoryEvent *h = (HistoryEvent *)calloc(1, sizeof(HistoryEvent));
        if (!h) return -1;
        h->complaint_id = cmp_id; h->timestamp = chs_get_time(state);
        unsigned int seq = 1;
        for (HistoryEvent *cur = state->history; cur; cur = cur->next) if (cur->complaint_id == cmp_id) seq++;
        h->seq_num = seq;
        if (ev) strncpy(h->event_type, ev, sizeof(h->event_type) - 1);
        if (pv) strncpy(h->prev_value, pv, sizeof(h->prev_value) - 1);
        if (nv) strncpy(h->new_value, nv, sizeof(h->new_value) - 1);
        if (u) strncpy(h->acting_user, u, sizeof(h->acting_user) - 1);
        if (n) strncpy(h->notes, n, sizeof(h->notes) - 1);
        HistoryEvent **tail = &state->history; while (*tail) tail = &(*tail)->next; *tail = h;
        return 0;
    }
    if (!results_out || !count_out) return -1;
    *results_out = NULL; *count_out = 0;
    size_t count = 0;
    for (HistoryEvent *h = state->history; h; h = h->next) if (h->complaint_id == cmp_id) count++;
    if (count == 0) return 0;
    HistoryEvent **arr = (HistoryEvent **)calloc(count, sizeof(HistoryEvent *));
    if (!arr) return -1;
    size_t idx = 0;
    for (HistoryEvent *h = state->history; h && idx < count; h = h->next) if (h->complaint_id == cmp_id) arr[idx++] = h;
    *results_out = arr; *count_out = count;
    return 0;
}
