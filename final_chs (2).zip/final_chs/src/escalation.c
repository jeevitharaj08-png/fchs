#include "chs.h"

int chs_escalation_trigger(AppState *state, unsigned int cmp_id, const char *reason, const char *acting_user) {
    if (!state) return -1;
    pthread_mutex_lock(&state->lock);
    time_t now = chs_get_time(state);
    if (cmp_id > 0) {
        for (Complaint *c = state->complaints; c; c = c->next) {
            if (c->id == cmp_id) {
                if (c->status == STATUS_ESCALATED) { pthread_mutex_unlock(&state->lock); return 0; }
                c->status = STATUS_ESCALATED; c->is_escalated = true; c->escalated_at = now; c->status_changed_at = now; c->updated_at = now;
                if (reason) snprintf(c->escalation_reason, sizeof(c->escalation_reason), "%s", reason);
                chs_history_append(state, c->id, "ESCALATED", "-", "ESCALATED", acting_user ? acting_user : "system", reason ? reason : "Escalated");
                chs_storage_sync(state, 0);
                pthread_mutex_unlock(&state->lock);
                return 0;
            }
        }
        pthread_mutex_unlock(&state->lock);
        return -1;
    }
    int count = 0;
    for (Complaint *c = state->complaints; c; c = c->next) {
        if (c->status != STATUS_RESOLVED && c->status != STATUS_CLOSED && c->status != STATUS_ESCALATED) {
            bool esc = false; const char *r = NULL;
            if (c->priority == PRIORITY_CRITICAL) { esc = true; r = "CRITICAL priority auto-escalation"; }
            else if (difftime(now, c->created_at) >= ESCALATION_TIMEOUT_SECS) { esc = true; r = "Overdue >= 24 hours SLA threshold breached"; }
            if (esc) {
                c->status = STATUS_ESCALATED; c->is_escalated = true; c->escalated_at = now; c->status_changed_at = now; c->updated_at = now;
                snprintf(c->escalation_reason, sizeof(c->escalation_reason), "%s", r);
                chs_history_append(state, c->id, "ESCALATED", "-", "ESCALATED", "system", r);
                count++;
            }
        }
    }
    if (count > 0) chs_storage_sync(state, 0);
    pthread_mutex_unlock(&state->lock);
    return count;
}

static void* escalation_thread_routine(void *arg) {
    AppState *state = (AppState *)arg;
    while (1) {
        pthread_mutex_lock(&state->lock);
        if (state->monitor_stop) { pthread_mutex_unlock(&state->lock); break; }
        pthread_mutex_unlock(&state->lock);
        chs_escalation_trigger(state, 0, NULL, NULL);
        int sec = state->monitor_interval_sec > 0 ? state->monitor_interval_sec : 1;
        for (int i = 0; i < sec * 10; i++) {
            pthread_mutex_lock(&state->lock);
            if (state->monitor_stop) { pthread_mutex_unlock(&state->lock); return NULL; }
            pthread_mutex_unlock(&state->lock);
            usleep(100000);
        }
    }
    return NULL;
}

int chs_escalation_monitor(AppState *state, int action) {
    if (!state) return -1;
    if (action == 1) {
        pthread_mutex_lock(&state->lock);
        if (state->monitor_running) { pthread_mutex_unlock(&state->lock); return 0; }
        state->monitor_stop = false; state->monitor_running = true;
        if (pthread_create(&state->monitor_thread, NULL, escalation_thread_routine, state) != 0) {
            state->monitor_running = false; pthread_mutex_unlock(&state->lock); return -1;
        }
        pthread_mutex_unlock(&state->lock);
        return 0;
    }
    pthread_mutex_lock(&state->lock);
    if (!state->monitor_running) { pthread_mutex_unlock(&state->lock); return 0; }
    state->monitor_stop = true;
    pthread_mutex_unlock(&state->lock);
    pthread_join(state->monitor_thread, NULL);
    pthread_mutex_lock(&state->lock);
    state->monitor_running = false;
    pthread_mutex_unlock(&state->lock);
    return 0;
}
