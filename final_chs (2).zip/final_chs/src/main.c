#include "chs.h"

int main(int argc, char *argv[]) {
    AppState state;
    if (chs_init(&state, (argc > 1) ? argv[1] : "data") != 0) return 1;
    chs_escalation_start_monitor(&state);
    printf("\n=== COMPLAINT HANDLING SYSTEM (CHS) ===\n");
    char b[256], u[MAX_USERNAME_LEN], p[MAX_PASSWORD_LEN];
    #define IN_L(pmt, buf) do { printf("%s", pmt); fflush(stdout); if (!fgets(buf, sizeof(buf), stdin)) goto done; (buf)[strcspn(buf, "\r\n")] = 0; } while(0)

    while (1) {
        IN_L("\n1. Customer | 2. Agent | 3. Manager | 4. Exit\nSelection: ", b);
        int opt = atoi(b);
        if (opt == 4) break;
        if (opt == 1) {
            IN_L("1. Login | 2. Register: ", b);
            if (atoi(b) == 1) {
                IN_L("Username: ", u); IN_L("Password: ", p);
                UserRole role; unsigned int cid = 0;
                if (chs_auth_login(&state, u, p, &role, &cid) == 0 && role == ROLE_CUSTOMER) {
                    while (1) {
                        IN_L("\n1. File | 2. View | 3. History | 4. Logout: ", b);
                        int m = atoi(b); if (m == 4) break;
                        if (m == 1) {
                            char cat[32], desc[256]; unsigned int nid = 0;
                            IN_L("Category: ", cat); IN_L("Description: ", desc); IN_L("Priority (0-3): ", b);
                            chs_complaint_register(&state, cid, cat, desc, (ComplaintPriority)atoi(b), &nid);
                            printf("[SUCCESS] Filed complaint #%u\n", nid);
                        } else if (m == 2) {
                            Complaint **res = NULL; size_t cnt = 0;
                            chs_customer_get_complaints(&state, cid, &res, &cnt);
                            for (size_t i = 0; i < cnt; i++) printf(" #%-4u | %-12s | %s\n", res[i]->id, status_to_string(res[i]->status), res[i]->description);
                            if (res) free(res);
                        } else if (m == 3) {
                            IN_L("Complaint ID: ", b); chs_report_print(&state, REPORT_HISTORY, atoi(b), stdout);
                        }
                    }
                } else printf("[ERROR] Login failed.\n");
            } else if (atoi(b) == 2) {
                char fn[64], em[64], ph[24]; unsigned int nid = 0;
                IN_L("User: ", u); IN_L("Pass: ", p); IN_L("Name: ", fn); IN_L("Email: ", em); IN_L("Phone: ", ph);
                int rc = chs_auth_register_customer(&state, u, p, fn, em, ph, &nid);
                if (rc == 0) printf("[SUCCESS] Registered ID: %u\n", nid); else printf("[ERROR] Registration failed (%d)\n", rc);
            }
        } else if (opt == 2) {
            IN_L("Agent User: ", u); IN_L("Password: ", p);
            UserRole role; unsigned int aid = 0;
            if (chs_auth_login(&state, u, p, &role, &aid) == 0 && role == ROLE_AGENT) {
                while (1) {
                    IN_L("\n1. View | 2. Status | 3. Note | 4. Resolve | 5. Logout: ", b);
                    int aopt = atoi(b); if (aopt == 5) break;
                    if (aopt == 1) {
                        Complaint **res = NULL; size_t cnt = 0;
                        chs_agent_get_assigned_complaints(&state, aid, &res, &cnt);
                        for (size_t i = 0; i < cnt; i++) printf(" #%-4u | %-12s | %s\n", res[i]->id, status_to_string(res[i]->status), res[i]->description);
                        if (res) free(res);
                    } else if (aopt == 2) {
                        IN_L("Complaint ID: ", b); unsigned int cid = atoi(b);
                        IN_L("Status (1-4): ", b); chs_agent_update_status(&state, aid, cid, (ComplaintStatus)atoi(b));
                    } else if (aopt == 3) {
                        IN_L("Complaint ID: ", b); unsigned int cid = atoi(b);
                        IN_L("Note: ", b); chs_agent_add_note(&state, aid, cid, b);
                    } else if (aopt == 4) {
                        IN_L("Complaint ID: ", b); unsigned int cid = atoi(b);
                        IN_L("Resolution: ", b); chs_agent_resolve(&state, aid, cid, b);
                    }
                }
            } else printf("[ERROR] Agent login failed.\n");
        } else if (opt == 3) {
            IN_L("Manager User: ", u); IN_L("Password: ", p);
            UserRole role; unsigned int mid = 0;
            if (chs_auth_login(&state, u, p, &role, &mid) == 0 && role == ROLE_MANAGER) {
                while (1) {
                    IN_L("\n1. Reports | 2. Escalations | 3. Reassign | 4. Close | 5. Agents | 6. Logout: ", b);
                    int mo = atoi(b); if (mo == 6) break;
                    if (mo == 1) { chs_report_print(&state, REPORT_SUMMARY, 0, stdout); chs_report_print(&state, REPORT_WORKLOAD, 0, stdout); }
                    else if (mo == 2) {
                        chs_report_print(&state, REPORT_ESCALATIONS, 0, stdout);
                        IN_L("Ack ID (0 to skip): ", b); if (atoi(b) > 0) chs_manager_acknowledge_escalation(&state, atoi(b), "Manager ack");
                    } else if (mo == 3) {
                        IN_L("Complaint ID: ", b); unsigned int cid = atoi(b);
                        IN_L("New Agent ID: ", b); chs_manager_reassign_complaint(&state, cid, atoi(b), "Manager reassign");
                    } else if (mo == 4) {
                        IN_L("Close Complaint ID: ", b); chs_manager_close_complaint(&state, atoi(b));
                    } else if (mo == 5) {
                        IN_L("1. Add Agent | 2. Toggle Status: ", b);
                        if (atoi(b) == 1) {
                            char fn[64]; unsigned int nid = 0;
                            IN_L("User: ", u); IN_L("Pass: ", p); IN_L("Name: ", fn);
                            chs_manager_add_agent(&state, u, p, fn, &nid);
                        } else {
                            IN_L("Agent ID: ", b); unsigned int aid = atoi(b);
                            IN_L("Active (1/0): ", b); chs_manager_set_agent_active(&state, aid, atoi(b) != 0);
                        }
                    }
                }
            } else printf("[ERROR] Manager login failed.\n");
        }
    }
done:
    chs_cleanup(&state);
    printf("Goodbye!\n");
    return 0;
}
