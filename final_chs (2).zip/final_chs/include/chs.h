#ifndef CHS_H
#define CHS_H
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include <time.h>
#include <pthread.h>
#include <ctype.h>
#include <unistd.h>

#define MAX_USERNAME_LEN 32
#define MAX_PASSWORD_LEN 64
#define MAX_HASH_LEN 128
#define MAX_SALT_LEN 64
#define MAX_NAME_LEN 64
#define MAX_EMAIL_LEN 64
#define MAX_PHONE_LEN 24
#define MAX_CATEGORY_LEN 32
#define MAX_DESC_LEN 256
#define MAX_NOTE_LEN 256
#define MAX_REASON_LEN 128
#define INITIAL_AGENT_COUNT 10
#define ESCALATION_TIMEOUT_SECS 86400

typedef enum { ROLE_NONE = 0, ROLE_CUSTOMER = 1, ROLE_AGENT = 2, ROLE_MANAGER = 3 } UserRole;
typedef enum { STATUS_OPEN = 0, STATUS_ASSIGNED = 1, STATUS_IN_PROGRESS = 2, STATUS_ESCALATED = 3, STATUS_RESOLVED = 4, STATUS_CLOSED = 5 } ComplaintStatus;
typedef enum { PRIORITY_LOW = 0, PRIORITY_MEDIUM = 1, PRIORITY_HIGH = 2, PRIORITY_CRITICAL = 3 } ComplaintPriority;
typedef enum { ACT_STATUS = 1, ACT_PRIORITY = 2, ACT_NOTE = 3, ACT_RESOLVE = 4, ACT_REASSIGN = 5, ACT_ACKNOWLEDGE = 6, ACT_CLOSE = 7 } ComplaintAction;
typedef enum { REPORT_SUMMARY = 1, REPORT_PRIORITY = 2, REPORT_WORKLOAD = 3, REPORT_ESCALATIONS = 4, REPORT_CUSTOMERS = 5, REPORT_HISTORY = 6 } ReportType;

typedef struct Customer {
    unsigned int id;
    char username[MAX_USERNAME_LEN], password_hash[MAX_HASH_LEN], salt[MAX_SALT_LEN], full_name[MAX_NAME_LEN], email[MAX_EMAIL_LEN], phone[MAX_PHONE_LEN];
    time_t created_at;
    struct Customer *next;
} Customer;

typedef struct Agent {
    unsigned int id;
    char username[MAX_USERNAME_LEN], password_hash[MAX_HASH_LEN], salt[MAX_SALT_LEN], full_name[MAX_NAME_LEN];
    bool is_active;
    time_t created_at, deactivated_at;
    struct Agent *next;
} Agent;

typedef struct Manager {
    char username[MAX_USERNAME_LEN], password_hash[MAX_HASH_LEN], salt[MAX_SALT_LEN], full_name[MAX_NAME_LEN];
    time_t created_at;
} Manager;

typedef struct Complaint {
    unsigned int id, customer_id, assigned_agent_id;
    char category[MAX_CATEGORY_LEN], description[MAX_DESC_LEN], resolution_details[MAX_NOTE_LEN], escalation_reason[MAX_REASON_LEN], manager_notes[MAX_NOTE_LEN];
    ComplaintStatus status;
    ComplaintPriority priority;
    bool is_escalated, is_acknowledged;
    time_t created_at, updated_at, assigned_at, reassigned_at, status_changed_at, priority_changed_at, escalated_at, acknowledged_at, resolved_at, closed_at;
    struct Complaint *next;
} Complaint;

typedef struct HistoryEvent {
    unsigned int complaint_id, seq_num;
    time_t timestamp;
    char event_type[32], prev_value[64], new_value[64], acting_user[MAX_USERNAME_LEN], notes[MAX_NOTE_LEN];
    struct HistoryEvent *next;
} HistoryEvent;
typedef struct HistoryEvent HistoryEntry;

typedef struct AppState {
    char data_dir[128];
    Manager manager;
    Agent *agents;
    Customer *customers;
    Complaint *complaints;
    HistoryEvent *history;
    unsigned int next_complaint_id, next_customer_id, next_agent_id;
    pthread_mutex_t lock;
    pthread_t monitor_thread;
    bool monitor_running, monitor_stop;
    int monitor_interval_sec;
} AppState;

#ifdef __cplusplus
extern "C" {
#endif
int chs_state_manage(AppState *state, int action, const char *data_dir);
time_t chs_get_time(AppState *state);
void chs_mock_time_ctl(int op, time_t val);
int chs_format_iso(time_t t, char *buf, size_t len);
time_t chs_parse_iso(const char *str);
void chs_sha256(const uint8_t *data, size_t len, uint8_t out[32]);
void chs_generate_salt(char *salt_out, size_t max_len);
int chs_hash_password(const char *pass, const char *salt, char *hash_out, size_t max_len);
int chs_constant_time_memcmp(const void *a, const void *b, size_t len);
int chs_storage_sync(AppState *state, int mode);
void* chs_find_user(AppState *state, UserRole role, unsigned int id, const char *username);
int chs_auth_login(AppState *state, const char *u, const char *p, UserRole *role, unsigned int *uid);
int chs_auth_register_customer(AppState *state, const char *u, const char *p, const char *fn, const char *em, const char *ph, unsigned int *id);
int chs_manager_add_agent(AppState *state, const char *u, const char *p, const char *fn, unsigned int *new_id);
int chs_manager_set_agent_active(AppState *state, unsigned int agent_id, bool is_active);
int chs_agent_calculate_workload(AppState *state, unsigned int agent_id);
int chs_assignment_auto_assign(AppState *state, unsigned int *agent_id_out);
int chs_complaint_register(AppState *state, unsigned int cust_id, const char *cat, const char *desc, ComplaintPriority pr, unsigned int *new_id);
Complaint* chs_complaint_find_by_id(AppState *state, unsigned int id);
int chs_complaint_modify(AppState *state, ComplaintAction action, unsigned int cid, unsigned int actor_id, const char *detail, int val);
int chs_search_complaints(AppState *state, int cust_id, int agent_id, int status, int priority, Complaint ***results_out, size_t *count_out);
int chs_history_op(AppState *state, int op, unsigned int cmp_id, const char *ev, const char *pv, const char *nv, const char *u, const char *n, HistoryEvent ***results_out, size_t *count_out);
int chs_escalation_trigger(AppState *state, unsigned int complaint_id, const char *reason, const char *acting_user);
int chs_escalation_monitor(AppState *state, int action);
int chs_report_print(AppState *state, ReportType type, unsigned int filter_id, FILE *out);
const char* chs_enum_to_str(int which, int val);
int chs_str_to_enum(int which, const char *str);
#ifdef __cplusplus
}
#endif

#define chs_init(s, dir) chs_state_manage(s, 0, dir)
#define chs_cleanup(s) chs_state_manage(s, 1, NULL)
#define chs_set_mock_time(t) chs_mock_time_ctl(0, (time_t)(t))
#define chs_advance_mock_time(s) chs_mock_time_ctl(1, (time_t)(s))
#define chs_reset_mock_time() chs_mock_time_ctl(2, 0)
#define chs_difftime(e, s) difftime(e, s)
#define chs_storage_save_all(s) chs_storage_sync(s, 0)
#define chs_storage_load_all(s) chs_storage_sync(s, 1)
#define chs_escalation_check_all(s) chs_escalation_trigger(s, 0, NULL, NULL)
#define chs_escalation_start_monitor(s) chs_escalation_monitor(s, 1)
#define chs_escalation_stop_monitor(s) chs_escalation_monitor(s, 0)
#define chs_history_append(s, cid, ev, pv, nv, u, n) chs_history_op(s, 0, cid, ev, pv, nv, u, n, NULL, NULL)
#define chs_history_get_for_complaint(s, cid, out, cnt) chs_history_op(s, 1, cid, NULL, NULL, NULL, NULL, NULL, out, cnt)
#define chs_agent_find_by_id(s, id) ((Agent*)chs_find_user(s, ROLE_AGENT, id, NULL))
#define chs_agent_find_by_username(s, u) ((Agent*)chs_find_user(s, ROLE_AGENT, 0, u))
#define chs_customer_find_by_id(s, id) ((Customer*)chs_find_user(s, ROLE_CUSTOMER, id, NULL))
#define chs_customer_find_by_username(s, u) ((Customer*)chs_find_user(s, ROLE_CUSTOMER, 0, u))
#define chs_customer_get_complaints(s, cid, out, cnt) chs_search_complaints(s, (int)(cid), -1, -1, -1, out, cnt)
#define chs_agent_get_assigned_complaints(s, aid, out, cnt) chs_search_complaints(s, -1, (int)(aid), -1, -1, out, cnt)
#define chs_agent_update_status(s, a, c, st) chs_complaint_modify(s, ACT_STATUS, c, a, NULL, (int)(st))
#define chs_agent_add_note(s, a, c, n) chs_complaint_modify(s, ACT_NOTE, c, a, n, 0)
#define chs_agent_change_priority(s, a, c, p) chs_complaint_modify(s, ACT_PRIORITY, c, a, NULL, (int)(p))
#define chs_agent_resolve(s, a, c, r) chs_complaint_modify(s, ACT_RESOLVE, c, a, r, 0)
#define chs_manager_reassign_complaint(s, c, na, r) chs_complaint_modify(s, ACT_REASSIGN, c, na, r, 0)
#define chs_manager_acknowledge_escalation(s, c, n) chs_complaint_modify(s, ACT_ACKNOWLEDGE, c, 0, n, 0)
#define chs_manager_close_complaint(s, c) chs_complaint_modify(s, ACT_CLOSE, c, 0, NULL, 0)
#define chs_complaint_update_status(s, c, st, u, n) chs_complaint_modify(s, ACT_STATUS, c, 0, n, (int)(st))
#define chs_report_complaint_summary(s, fp) chs_report_print(s, REPORT_SUMMARY, 0, fp)
#define chs_report_priority(s, fp) chs_report_print(s, REPORT_PRIORITY, 0, fp)
#define chs_report_agent_workload(s, fp) chs_report_print(s, REPORT_WORKLOAD, 0, fp)
#define chs_report_escalations(s, fp) chs_report_print(s, REPORT_ESCALATIONS, 0, fp)
#define chs_report_customer_summary(s, fp) chs_report_print(s, REPORT_CUSTOMERS, 0, fp)
#define chs_report_complaint_history(s, cid, fp) chs_report_print(s, REPORT_HISTORY, cid, fp)
#define status_to_string(s) chs_enum_to_str(0, (int)(s))
#define priority_to_string(p) chs_enum_to_str(1, (int)(p))
#define string_to_status(str) ((ComplaintStatus)chs_str_to_enum(0, str))
#define string_to_priority(str) ((ComplaintPriority)chs_str_to_enum(1, str))
#define is_valid_status_transition(f, t) (((f)==STATUS_OPEN&&(t)==STATUS_ASSIGNED)||((f)==STATUS_ASSIGNED&&((t)==STATUS_IN_PROGRESS||(t)==STATUS_ESCALATED))||((f)==STATUS_IN_PROGRESS&&((t)==STATUS_RESOLVED||(t)==STATUS_ESCALATED))||((f)==STATUS_ESCALATED&&(t)==STATUS_RESOLVED)||((f)==STATUS_RESOLVED&&(t)==STATUS_CLOSED))

static inline Complaint* chs_customer_get_complaint_by_id(AppState *s, unsigned int cid, unsigned int id) {
    Complaint *c = chs_complaint_find_by_id(s, id);
    return (c && c->customer_id == cid) ? c : NULL;
}

#endif
